
import React, { createContext, useState, useContext, useEffect } from 'react';
import { User } from '@/types';
import { supabase } from '@/integrations/supabase/client';

type AuthContextType = {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  error: string | null;
};

const AuthContext = createContext<AuthContextType>({
  user: null,
  isAuthenticated: false,
  isLoading: true,
  login: async () => {},
  logout: () => {},
  error: null,
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        setIsLoading(true);
        
        // Check if there's an active Supabase session
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();
        
        if (sessionError) {
          console.error('Error checking authentication:', sessionError);
          setIsLoading(false);
          return;
        }
        
        if (session) {
          // User is logged in
          const { user: supabaseUser } = session;
          
          // Get user profile data if needed
          const { data: profileData } = await supabase
            .from('teachers') // Assuming teachers are the primary users
            .select('*')
            .eq('email', supabaseUser.email)
            .single();
          
          const userData: User = {
            id: supabaseUser.id,
            name: profileData?.name || supabaseUser.email?.split('@')[0] || 'User',
            email: supabaseUser.email || '',
            role: profileData?.status === 'active' ? 'teacher' : 'teacher', // Default to teacher since role doesn't exist
          };
          
          setUser(userData);
        }
      } catch (error) {
        console.error('Authentication error:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    // Check authentication on component mount
    checkAuth();
    
    // Set up auth state change listener (safely)
    let subscription: { unsubscribe: () => void } | null = null;
    
    try {
      const { data } = supabase.auth.onAuthStateChange(async (event, session) => {
        console.log('Auth state changed:', event);
        
        if (event === 'SIGNED_IN' && session) {
          // User logged in
          const { user: supabaseUser } = session;
          
          const { data: profileData } = await supabase
            .from('teachers')
            .select('*')
            .eq('email', supabaseUser.email)
            .single();
          
          const userData: User = {
            id: supabaseUser.id,
            name: profileData?.name || supabaseUser.email?.split('@')[0] || 'User',
            email: supabaseUser.email || '',
            role: profileData?.status === 'active' ? 'teacher' : 'teacher', // Default to teacher since role doesn't exist
          };
          
          setUser(userData);
        } else if (event === 'SIGNED_OUT') {
          // User logged out
          setUser(null);
        }
      });
      
      subscription = data.subscription;
    } catch (error) {
      console.error('Error setting up auth state change listener:', error);
    }
    
    // Clean up the subscription when component unmounts
    return () => {
      if (subscription) {
        subscription.unsubscribe();
      }
    };
  }, []);

  const login = async (email: string, password: string) => {
    try {
      setIsLoading(true);
      setError(null);
      
      // Sign in with Supabase
      const { data, error: signInError } = await supabase.auth.signInWithPassword({
        email,
        password
      });
      
      if (signInError) {
        throw new Error(signInError.message);
      }
      
      // User will be set by the auth state change listener
    } catch (error) {
      if (error instanceof Error) {
        setError(error.message);
      } else {
        setError('An unknown error occurred');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      await supabase.auth.signOut();
      // User will be unset by the auth state change listener
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <AuthContext.Provider value={{ user, isAuthenticated: !!user, isLoading, login, logout, error }}>
      {children}
    </AuthContext.Provider>
  );
};
