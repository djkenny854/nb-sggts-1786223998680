import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { ArrowLeft, Mail, Phone, MapPin, Calendar, User, CreditCard, Heart, School, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import MainLayout from '@/components/layout/MainLayout';
import { fetchStudentById } from '@/utils/supabaseHelpers';
import StudentImageDialog from "@/components/students/StudentImageDialog";
import { supabase } from "@/integrations/supabase/client";

const StudentDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  // Image Dialog Modal State
  const [imgDialogOpen, setImgDialogOpen] = useState(false);

  const { 
    data: student, 
    isLoading, 
    isError,
    error 
  } = useQuery({
    queryKey: ['student', id],
    queryFn: () => fetchStudentById(id!),
    enabled: !!id,
  });

  // New: Fetch current fee record & recent transactions for student
  const [studentDebt, setStudentDebt] = useState<number | null>(null);
  const [recentTransactions, setRecentTransactions] = useState<any[]>([]);
  const [feeInfoLoading, setFeeInfoLoading] = useState(true);

  useEffect(() => {
    if (!id) return;

    let alive = true;
    setFeeInfoLoading(true);

    const fetchStudentFeesAndTransactions = async () => {
      try {
        // Current year and term
        const currentYear = new Date().getFullYear().toString();
        const currentTerm = "Term 1"; // TODO: Make dynamic if desired

        // Fetch balance/debt from student_fees
        const { data: fees } = await supabase
          .from("student_fees")
          .select("balance")
          .eq("student_id", id)
          .eq("academic_year", currentYear)
          .eq("academic_term", currentTerm)
          .maybeSingle();

        if (alive) {
          setStudentDebt(fees?.balance != null ? Number(fees.balance) : null);
        }
        
        // Fetch recent transactions
        const { data: txns } = await supabase
          .from("fee_transactions")
          .select("id, amount, payment_method, payment_date, notes, receipt_number")
          .eq("student_id", id)
          .order("payment_date", { ascending: false })
          .limit(3);

        if (alive) {
          setRecentTransactions(txns ?? []);
        }

      } catch (err) {
        // console.error("Failed to fetch student fee data", err);
      } finally {
        if (alive) setFeeInfoLoading(false);
      }
    };

    fetchStudentFeesAndTransactions();

    return () => { alive = false; };
  }, [id]);

  if (isLoading) {
    return (
      <MainLayout>
        <div className="flex items-center justify-center h-64">
          <div className="flex flex-col items-center space-y-4">
            <div className="h-8 w-8 rounded-full border-2 border-primary border-t-transparent animate-spin" />
            <p className="text-sm text-muted-foreground">Loading student details...</p>
          </div>
        </div>
      </MainLayout>
    );
  }

  if (isError || !student) {
    return (
      <MainLayout>
        <div className="flex flex-col items-center justify-center h-64 space-y-4">
          <User className="h-12 w-12 text-muted-foreground" />
          <div className="text-center">
            <h3 className="text-lg font-medium">Student Not Found</h3>
            <p className="text-sm text-muted-foreground mt-1">
              {error instanceof Error ? error.message : 'The student you are looking for does not exist.'}
            </p>
            <Button 
              variant="outline" 
              onClick={() => navigate('/students')}
              className="mt-4"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Students
            </Button>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      {/* Full-size Image Dialog */}
      <StudentImageDialog
        open={imgDialogOpen}
        onOpenChange={setImgDialogOpen}
        imageUrl={student.profileImage || ""}
        studentName={student.name}
      />
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => navigate('/students')}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Students
          </Button>
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Student Details</h2>
            <p className="text-muted-foreground">
              View and manage student information
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Student Profile Card */}
          <Card className="lg:col-span-1">
            <CardHeader className="text-center">
              <div
                className="inline-block cursor-pointer"
                title="Click to view full image"
                tabIndex={0}
                onClick={() => setImgDialogOpen(true)}
                onKeyDown={e => {
                  if (e.key === "Enter" || e.key === " ") setImgDialogOpen(true);
                }}
                role="button"
                aria-label="Open full profile image"
              >
                <Avatar className="h-24 w-24 mx-auto mb-4">
                  <AvatarImage 
                    src={student.profileImage} 
                    alt={student.name}
                    className="object-cover"
                  />
                  <AvatarFallback className="text-lg">
                    {student.name.substring(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
              </div>
              <CardTitle className="text-xl">{student.name}</CardTitle>
              <p className="text-sm text-muted-foreground">
                {student.enrollmentNumber}
              </p>
              <div className="flex justify-center space-x-2 mt-2 flex-wrap gap-1">
                <Badge variant="outline">
                  {student.className}
                </Badge>
                <Badge 
                  variant="outline" 
                  className={
                    student.boardingStatus === 'Boarding' 
                      ? 'bg-blue-100 text-blue-800' 
                      : 'bg-slate-100'
                  }
                >
                  {student.boardingStatus}
                </Badge>
                {student.transportUse === 'Yes' && (
                  <Badge variant="outline" className="bg-green-100 text-green-800">
                    Transport
                  </Badge>
                )}
              </div>
            </CardHeader>
          </Card>

          {/* Student Information */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center">
                <User className="mr-2 h-5 w-5" />
                Personal Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Date of Birth</label>
                  <div className="flex items-center">
                    <Calendar className="mr-2 h-4 w-4 text-muted-foreground" />
                    <span>{student.dateOfBirth || 'Not provided'}</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Gender</label>
                  <span>{student.gender || 'Not provided'}</span>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Join Date</label>
                  <span>{student.joinDate || 'Not provided'}</span>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Blood Group</label>
                  <div className="flex items-center">
                    <Heart className="mr-2 h-4 w-4 text-muted-foreground" />
                    <span>{student.bloodGroup || 'Not provided'}</span>
                  </div>
                </div>
              </div>
              
              {student.address && (
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Address</label>
                  <div className="flex items-center">
                    <MapPin className="mr-2 h-4 w-4 text-muted-foreground" />
                    <span>{student.address}</span>
                  </div>
                </div>
              )}

              {student.email && (
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Email</label>
                  <div className="flex items-center">
                    <Mail className="mr-2 h-4 w-4 text-muted-foreground" />
                    <span>{student.email}</span>
                  </div>
                </div>
              )}

              {student.bestColor && (
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Favorite Color</label>
                  <div className="flex items-center">
                    <div 
                      className="mr-2 h-4 w-4 rounded-full border"
                      style={{ backgroundColor: student.bestColor }}
                    />
                    <span>{student.bestColor}</span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Parent Information */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle>Parent/Guardian</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <label className="text-sm font-medium text-muted-foreground">Name</label>
                <p className="font-medium">{student.parentName || 'Not provided'}</p>
              </div>
              {student.parentContact && (
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Contact</label>
                  <div className="flex items-center">
                    <Phone className="mr-2 h-4 w-4 text-muted-foreground" />
                    <span>{student.parentContact}</span>
                  </div>
                </div>
              )}
              {student.emergencyContact && (
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Emergency Contact</label>
                  <div className="flex items-center">
                    <Phone className="mr-2 h-4 w-4 text-muted-foreground" />
                    <span>{student.emergencyContact}</span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Fee Information & Last Transactions */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center">
                <CreditCard className="mr-2 h-5 w-5" />
                Fee Information
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Total Paid */}
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <p className="text-sm text-muted-foreground">Total Paid</p>
                  <p className="text-2xl font-bold text-green-600">
                    UGX {student.fees.paid.toLocaleString()}
                  </p>
                </div>
                {/* Debt / Balance */}
                <div className="text-center p-4 bg-orange-50 rounded-lg">
                  <p className="text-sm text-muted-foreground">Debt (Outstanding Balance)</p>
                  <p className="text-2xl font-bold text-orange-600">
                    {feeInfoLoading
                      ? "Loading..."
                      : (studentDebt !== null
                          ? `UGX ${Number(studentDebt).toLocaleString()}`
                          : "No fee info")
                    }
                  </p>
                </div>
              </div>
              
              {/* Last Payment */}
              <div className="mt-4">
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  Recent Transactions
                </h4>
                {feeInfoLoading ? (
                  <div className="text-muted-foreground">Loading...</div>
                ) : (recentTransactions.length > 0 ? (
                  <div className="space-y-2">
                    {recentTransactions.map(txn => (
                      <div key={txn.id} className="flex flex-col md:flex-row md:justify-between md:items-center p-2 bg-gray-50 rounded">
                        <div className="text-sm font-medium">UGX {Number(txn.amount).toLocaleString()}</div>
                        <div className="text-xs text-muted-foreground">
                          {txn.payment_date ? new Date(txn.payment_date).toLocaleDateString() : ""}
                          {txn.payment_method ? ` • ${txn.payment_method}` : ""}
                        </div>
                        {txn.receipt_number && (
                          <span className="text-xs ml-1 font-mono">{txn.receipt_number}</span>
                        )}
                        {txn.notes && (
                          <span className="text-xs text-gray-700 mt-1">{txn.notes}</span>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-2 text-muted-foreground text-sm bg-yellow-50 rounded">
                    No payments found for this student.
                  </div>
                )
                )}
              </div>
            </CardContent>
          </Card>

          {/* Additional Information */}
          <Card className="lg:col-span-3">
            <CardHeader>
              <CardTitle>Additional Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {student.medicalConditions && (
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Medical Conditions</label>
                  <p className="mt-1 p-3 bg-yellow-50 rounded-lg">{student.medicalConditions}</p>
                </div>
              )}
              
              {student.clubsActivities && student.clubsActivities.length > 0 && (
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Clubs & Activities</label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {student.clubsActivities.map((activity, index) => (
                      <Badge key={index} variant="outline" className="bg-purple-50">
                        {activity}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Academic Information */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                <div className="flex items-center p-3 bg-blue-50 rounded-lg">
                  <School className="mr-3 h-8 w-8 text-blue-600" />
                  <div>
                    <p className="text-sm text-muted-foreground">Class</p>
                    <p className="font-medium">{student.className}</p>
                  </div>
                </div>
                <div className="flex items-center p-3 bg-green-50 rounded-lg">
                  <Calendar className="mr-3 h-8 w-8 text-green-600" />
                  <div>
                    <p className="text-sm text-muted-foreground">Enrollment</p>
                    <p className="font-medium">{student.enrollmentNumber}</p>
                  </div>
                </div>
                <div className="flex items-center p-3 bg-purple-50 rounded-lg">
                  <User className="mr-3 h-8 w-8 text-purple-600" />
                  <div>
                    <p className="text-sm text-muted-foreground">Status</p>
                    <p className="font-medium">{student.boardingStatus} Student</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
};

export default StudentDetail;
