
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import MainLayout from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { ArrowLeft, Edit2, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Subject } from '@/types/subjects';
import AddEditSubjectDialog from '@/components/subjects/AddEditSubjectDialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

// In a real app, this would be fetched from an API
const mockSubjects: Subject[] = [
  { id: '1', name: 'Mathematics', code: 'MAT101', category: 'Core', credits: 4, description: 'Basic mathematics including algebra, trigonometry, and calculus' },
  { id: '2', name: 'English Language', code: 'ENG101', category: 'Core', credits: 3, description: 'Grammar, composition, and literature studies' },
  { id: '3', name: 'Physics', code: 'PHY101', category: 'Science', credits: 4, description: 'Introduction to mechanics, thermodynamics, and waves' },
  { id: '4', name: 'Chemistry', code: 'CHE101', category: 'Science', credits: 4, description: 'Study of matter, its properties, and the changes it undergoes' },
  { id: '5', name: 'History', code: 'HIS101', category: 'Humanities', credits: 3, description: 'Study of past events and human affairs' },
  { id: '6', name: 'Geography', code: 'GEO101', category: 'Humanities', credits: 3, description: 'Study of places and the relationships between people and their environments' },
  { id: '7', name: 'Computer Science', code: 'CS101', category: 'Technology', credits: 4, description: 'Introduction to programming and computer systems' },
  { id: '8', name: 'Physical Education', code: 'PE101', category: 'Non-academic', credits: 2, description: 'Physical fitness and sports' },
];

const SubjectDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [subject, setSubject] = useState<Subject | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  useEffect(() => {
    // In a real app, fetch from an API
    const foundSubject = mockSubjects.find(s => s.id === id);
    if (foundSubject) {
      setSubject(foundSubject);
    } else {
      toast({
        title: "Subject not found",
        description: "The requested subject could not be found.",
        variant: "destructive"
      });
      navigate('/subjects');
    }
  }, [id, navigate, toast]);
  
  const handleEditSubject = () => {
    setIsDialogOpen(true);
  };
  
  const handleSaveSubject = (updatedSubject: Subject) => {
    setSubject(updatedSubject);
    setIsDialogOpen(false);
    toast({
      title: "Subject updated",
      description: `${updatedSubject.name} has been updated successfully.`
    });
  };
  
  const handleDeleteSubject = () => {
    toast({
      title: "Subject deleted",
      description: `${subject?.name} has been deleted successfully.`
    });
    navigate('/subjects');
  };
  
  if (!subject) {
    return (
      <MainLayout>
        <div className="container mx-auto p-6">
          <p>Loading subject details...</p>
        </div>
      </MainLayout>
    );
  }
  
  return (
    <MainLayout>
      <div className="container mx-auto p-6">
        <div className="mb-6">
          <Button variant="ghost" onClick={() => navigate('/subjects')}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Subjects
          </Button>
        </div>
        
        <div className="flex justify-between items-start mb-6">
          <div>
            <h1 className="text-3xl font-bold">{subject.name}</h1>
            <p className="text-muted-foreground">Subject Code: {subject.code}</p>
          </div>
          
          <div className="flex gap-2">
            <Button variant="outline" onClick={handleEditSubject}>
              <Edit2 className="mr-2 h-4 w-4" />
              Edit Subject
            </Button>
            
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive">
                  <Trash2 className="mr-2 h-4 w-4" />
                  Delete
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete Subject</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to delete "{subject.name}"? This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleDeleteSubject}>Delete</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
        
        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Subject Information</CardTitle>
              <CardDescription>Basic details about the subject</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="text-sm font-medium text-muted-foreground mb-1">Subject Name</h4>
                <p>{subject.name}</p>
              </div>
              <div>
                <h4 className="text-sm font-medium text-muted-foreground mb-1">Subject Code</h4>
                <p>{subject.code}</p>
              </div>
              <div>
                <h4 className="text-sm font-medium text-muted-foreground mb-1">Category</h4>
                <p>{subject.category}</p>
              </div>
              <div>
                <h4 className="text-sm font-medium text-muted-foreground mb-1">Credits</h4>
                <p>{subject.credits}</p>
              </div>
              <div>
                <h4 className="text-sm font-medium text-muted-foreground mb-1">Description</h4>
                <p>{subject.description}</p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Assigned Teachers</CardTitle>
              <CardDescription>Teachers currently teaching this subject</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">No teachers currently assigned to this subject.</p>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">Assign Teachers</Button>
            </CardFooter>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Classes</CardTitle>
              <CardDescription>Classes where this subject is taught</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">No classes currently using this subject.</p>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">Assign to Classes</Button>
            </CardFooter>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Subject Materials</CardTitle>
              <CardDescription>Books, resources, and materials for this subject</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">No materials currently linked to this subject.</p>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">Add Materials</Button>
            </CardFooter>
          </Card>
        </div>
      </div>
      
      {subject && (
        <AddEditSubjectDialog 
          open={isDialogOpen}
          onOpenChange={setIsDialogOpen}
          subject={subject}
          onSave={handleSaveSubject}
          categories={['Core', 'Science', 'Humanities', 'Technology', 'Arts', 'Non-academic']}
        />
      )}
    </MainLayout>
  );
};

export default SubjectDetail;
