import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import MainLayout from '@/components/layout/MainLayout';
import StudentForm from '@/components/students/StudentForm';
import StudentTable from '@/components/students/StudentTable';
import StudentBulkActions from '@/components/students/StudentBulkActions';
import StudentFeeAlerts from '@/components/messaging/StudentFeeAlerts';
import StudentAIInsights from '@/components/students/StudentAIInsights';
import { fetchStudents, subscribeToStudents } from '@/utils/supabaseHelpers';
import { supabase } from '@/integrations/supabase/client';
import { Student } from '@/types';
import { transformToBulkActionStudent, BulkActionStudent } from '@/utils/studentTypes';

const Students = () => {
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [selectedStudents, setSelectedStudents] = useState<Student[]>([]);
  const navigate = useNavigate();

  // Setup query to fetch students
  const { 
    data: students = [], 
    isLoading, 
    isError, 
    error,
    refetch
  } = useQuery({
    queryKey: ['students'],
    queryFn: fetchStudents,
  });

  // Setup real-time subscription
  useEffect(() => {
    const subscription = subscribeToStudents(async (payload) => {
      console.log('Student change detected:', payload);
      // Refetch students when there's a change
      await refetch();
      setRefreshTrigger(prev => prev + 1);
      
      // Show notification based on the type of change
      if (payload.eventType === 'INSERT') {
        toast.info('New student added', {
          description: 'A new student has been added to the system.'
        });
      } else if (payload.eventType === 'UPDATE') {
        toast.info('Student information updated', {
          description: 'Student information has been updated.'
        });
      } else if (payload.eventType === 'DELETE') {
        toast.info('Student removed', {
          description: 'A student has been removed from the system.'
        });
      }
    });
    
    // Cleanup subscription
    return () => {
      subscription.unsubscribe();
    };
  }, [refetch]);

  // Show error if any
  if (isError) {
    console.error('Error fetching students:', error);
    toast.error('Failed to load students', {
      description: error instanceof Error ? error.message : 'Unknown error occurred',
    });
  }

  const handleViewStudent = (student: Student) => {
    navigate(`/students/${student.id}`);
  };

  const handleEditStudent = (student: Student) => {
    navigate(`/students/${student.id}/edit`);
  };

  const handleDeleteStudent = async (studentId: string) => {
    if (window.confirm('Are you sure you want to delete this student? This action cannot be undone.')) {
      try {
        const { error } = await supabase
          .from('students')
          .delete()
          .eq('id', studentId);

        if (error) throw error;

        toast.success('Student deleted successfully');
        setRefreshTrigger(prev => prev + 1);
      } catch (error) {
        console.error('Error deleting student:', error);
        toast.error('Failed to delete student');
      }
    }
  };

  const handleSendFeeReminder = (studentIds: string[]) => {
    // Navigate to messaging with pre-selected students
    navigate('/messaging', { 
      state: { 
        preSelectStudents: studentIds,
        messageType: 'fee_reminder'
      }
    });
  };

  // Transform selected students for bulk actions
  const bulkActionStudents: BulkActionStudent[] = transformToBulkActionStudent(selectedStudents);

  return (
    <MainLayout>
      <div className="space-y-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Students</h2>
          <p className="text-muted-foreground">
            Manage student registrations and view student information.
          </p>
        </div>

        {/* AI Insights */}
        <StudentAIInsights />

        {/* Fee Alerts */}
        <StudentFeeAlerts onSendReminder={handleSendFeeReminder} />

        <Tabs defaultValue="list" className="space-y-4">
          <TabsList>
            <TabsTrigger value="list">Students List</TabsTrigger>
            <TabsTrigger value="add">Add Student</TabsTrigger>
          </TabsList>
          
          <TabsContent value="list" className="space-y-4">
            <StudentTable 
              onViewStudent={handleViewStudent}
              onEditStudent={handleEditStudent}
              onDeleteStudent={handleDeleteStudent}
              refreshTrigger={refreshTrigger}
              selectedStudents={selectedStudents}
              onStudentSelect={setSelectedStudents}
            />
          </TabsContent>
          
          <TabsContent value="add" className="space-y-4">
            <StudentForm />
          </TabsContent>
        </Tabs>

        {/* Bulk Actions */}
        <StudentBulkActions
          selectedStudents={bulkActionStudents}
          onClearSelection={() => setSelectedStudents([])}
        />
      </div>
    </MainLayout>
  );
};

export default Students;
