
import React, { useState } from 'react';
import MainLayout from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ClipboardList, Calendar, BarChart3 } from 'lucide-react';
import ExamSchedule from '@/components/examinations/ExamSchedule';
import ExamResults from '@/components/examinations/ExamResults';
import ExamReports from '@/components/examinations/ExamReports';

const Examinations = () => {
  const [activeTab, setActiveTab] = useState('schedule');

  return (
    <MainLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Examinations</h1>
          <p className="text-muted-foreground mt-2">
            Manage exam schedules, results, and performance analysis.
          </p>
        </div>

        <Tabs defaultValue="schedule" value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="schedule">
              <Calendar className="mr-2 h-4 w-4" />
              Exam Schedule
            </TabsTrigger>
            <TabsTrigger value="results">
              <ClipboardList className="mr-2 h-4 w-4" />
              Results
            </TabsTrigger>
            <TabsTrigger value="reports">
              <BarChart3 className="mr-2 h-4 w-4" />
              Analysis
            </TabsTrigger>
          </TabsList>
          <TabsContent value="schedule" className="mt-6">
            <ExamSchedule />
          </TabsContent>
          <TabsContent value="results" className="mt-6">
            <ExamResults />
          </TabsContent>
          <TabsContent value="reports" className="mt-6">
            <ExamReports />
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
};

export default Examinations;
