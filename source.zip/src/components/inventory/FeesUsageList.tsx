
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CalendarDays, DollarSign, Search, Package, AlertCircle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';

interface FeesUsage {
  id: string;
  title: string;
  amount: number;
  date: string;
  category: string;
  notes?: string;
  inventory_item_id?: string;
  created_at: string;
}

const FeesUsageList = () => {
  const [usageRecords, setUsageRecords] = useState<FeesUsage[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [availableFees, setAvailableFees] = useState(0);
  const { toast } = useToast();

  useEffect(() => {
    fetchUsageRecords();
    fetchAvailableFees();
  }, []);

  const fetchUsageRecords = async () => {
    try {
      const { data, error } = await supabase
        .from('fees_usage')
        .select('*')
        .order('date', { ascending: false });

      if (error) throw error;
      setUsageRecords(data || []);
    } catch (error) {
      console.error('Error fetching fees usage:', error);
      toast({
        title: "Error",
        description: "Failed to fetch fees usage records",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchAvailableFees = async () => {
    try {
      // Get total fees collected
      const { data: paymentsData, error: paymentsError } = await supabase
        .from('fee_transactions')
        .select('amount')
        .eq('status', 'completed');

      if (paymentsError) throw paymentsError;

      const totalCollected = paymentsData?.reduce((sum, payment) => sum + Number(payment.amount), 0) || 0;

      // Get total fees used
      const { data: usageData, error: usageError } = await supabase
        .from('fees_usage')
        .select('amount');

      if (usageError) throw usageError;

      const totalUsed = usageData?.reduce((sum, usage) => sum + Number(usage.amount), 0) || 0;

      setAvailableFees(totalCollected - totalUsed);
    } catch (error) {
      console.error('Error fetching available fees:', error);
    }
  };

  const filteredRecords = usageRecords.filter(record => {
    const matchesSearch = record.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         record.notes?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || record.category === categoryFilter;
    
    return matchesSearch && matchesCategory;
  });

  const totalUsed = usageRecords.reduce((sum, record) => sum + record.amount, 0);
  const categoryBreakdown = usageRecords.reduce((acc, record) => {
    acc[record.category] = (acc[record.category] || 0) + record.amount;
    return acc;
  }, {} as Record<string, number>);

  if (loading) {
    return <div className="flex justify-center p-8">Loading fees usage data...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Fees Usage Tracker</h2>
          <p className="text-muted-foreground">Track how collected student fees are being used</p>
        </div>
        
        {/* Available Fees Alert */}
        {availableFees < 10000 && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
            <div className="flex items-center">
              <AlertCircle className="h-5 w-5 text-yellow-600 mr-2" />
              <div>
                <p className="text-sm font-medium text-yellow-800">Low Available Fees</p>
                <p className="text-sm text-yellow-700">UGX {availableFees.toLocaleString()} remaining</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Available Fees</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">UGX {availableFees.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              Remaining for purchases
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Used</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">UGX {totalUsed.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              From {usageRecords.length} transactions
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Categories</CardTitle>
            <CalendarDays className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{Object.keys(categoryBreakdown).length}</div>
            <p className="text-xs text-muted-foreground">
              Usage categories
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex space-x-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Search usage records..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Filter by category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {Object.keys(categoryBreakdown).map((category) => (
              <SelectItem key={category} value={category}>
                {category}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Usage Records List */}
      <Card>
        <CardHeader>
          <CardTitle>Purchase Transactions</CardTitle>
          <CardDescription>All items purchased using student fees</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredRecords.map((record) => (
              <div key={record.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2">
                      <h3 className="font-medium">{record.title}</h3>
                      <Badge variant="outline">{record.category}</Badge>
                    </div>
                    {record.notes && (
                      <p className="text-sm text-muted-foreground mt-1">{record.notes}</p>
                    )}
                    <p className="text-sm text-muted-foreground mt-1">
                      {format(new Date(record.date), 'MMM dd, yyyy')}
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-semibold text-red-600">
                      -UGX {record.amount.toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredRecords.length === 0 && (
            <div className="text-center py-8">
              <Package className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium text-muted-foreground">No usage records found</h3>
              <p className="text-muted-foreground">Try adjusting your filters or add some inventory items.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default FeesUsageList;
