
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DollarSign, Search, Plus, Download } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import PayrollDialog from './PayrollDialog';

interface PayrollRecord {
  id: string;
  teacher_id: string;
  pay_period_start: string;
  pay_period_end: string;
  basic_salary: number;
  allowances: number;
  overtime_pay: number;
  deductions: number;
  tax_deductions: number;
  net_pay: number;
  pay_date: string;
  status: string;
  notes: string;
  teachers: {
    name: string;
    employee_id: string;
  };
}

const PayrollManagement = () => {
  const [payrollRecords, setPayrollRecords] = useState<PayrollRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedMonth, setSelectedMonth] = useState(new Date().toISOString().slice(0, 7));
  const [dialogOpen, setDialogOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchPayrollRecords();
  }, [selectedMonth]);

  const fetchPayrollRecords = async () => {
    try {
      const startOfMonth = `${selectedMonth}-01`;
      const endOfMonth = new Date(selectedMonth + '-01');
      endOfMonth.setMonth(endOfMonth.getMonth() + 1);
      endOfMonth.setDate(0);
      const endDate = endOfMonth.toISOString().slice(0, 10);

      const { data, error } = await supabase
        .from('payroll_records')
        .select(`
          *,
          teachers (
            name,
            employee_id
          )
        `)
        .gte('pay_period_start', startOfMonth)
        .lte('pay_period_end', endDate)
        .order('pay_period_start', { ascending: false });

      if (error) throw error;
      setPayrollRecords(data || []);
    } catch (error) {
      console.error('Error fetching payroll records:', error);
      toast({
        title: "Error",
        description: "Failed to fetch payroll records",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleMarkAsPaid = async (recordId: string) => {
    try {
      const { error } = await supabase
        .from('payroll_records')
        .update({
          status: 'paid',
          pay_date: new Date().toISOString().slice(0, 10)
        })
        .eq('id', recordId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Payroll record marked as paid"
      });

      fetchPayrollRecords();
    } catch (error: any) {
      console.error('Error updating payroll record:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to update payroll record",
        variant: "destructive"
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'paid': return 'bg-green-100 text-green-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatCurrency = (amount: number) => {
    return `UGX ${amount.toLocaleString()}`;
  };

  const filteredRecords = payrollRecords.filter(record => {
    const matchesSearch = record.teachers?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         record.teachers?.employee_id?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || record.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const totalPending = filteredRecords
    .filter(record => record.status === 'pending')
    .reduce((sum, record) => sum + record.net_pay, 0);

  const totalPaid = filteredRecords
    .filter(record => record.status === 'paid')
    .reduce((sum, record) => sum + record.net_pay, 0);

  if (loading) {
    return <div className="flex justify-center p-8">Loading payroll records...</div>;
  }

  return (
    <div className="space-y-4">
      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Pending</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{formatCurrency(totalPending)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Paid</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{formatCurrency(totalPaid)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Records</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{filteredRecords.length}</div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-between items-center">
        <div className="flex space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search staff..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
          
          <Input
            type="month"
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="w-48"
          />

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="paid">Paid</SelectItem>
              <SelectItem value="cancelled">Cancelled</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex space-x-2">
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button onClick={() => setDialogOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Generate Payroll
          </Button>
        </div>
      </div>

      <div className="space-y-4">
        {filteredRecords.map((record) => (
          <Card key={record.id}>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-lg">{record.teachers?.name || 'Unknown Staff'}</CardTitle>
                  <CardDescription>
                    Employee ID: {record.teachers?.employee_id || 'N/A'} • 
                    {new Date(record.pay_period_start).toLocaleDateString()} - {new Date(record.pay_period_end).toLocaleDateString()}
                  </CardDescription>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge className={getStatusColor(record.status)}>
                    {record.status.toUpperCase()}
                  </Badge>
                  <div className="text-right">
                    <div className="text-lg font-bold">{formatCurrency(record.net_pay)}</div>
                    <div className="text-sm text-muted-foreground">Net Pay</div>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Basic Salary:</span>
                  <div className="font-medium">{formatCurrency(record.basic_salary)}</div>
                </div>
                <div>
                  <span className="text-muted-foreground">Allowances:</span>
                  <div className="font-medium text-green-600">+{formatCurrency(record.allowances)}</div>
                </div>
                <div>
                  <span className="text-muted-foreground">Deductions:</span>
                  <div className="font-medium text-red-600">-{formatCurrency(record.deductions + record.tax_deductions)}</div>
                </div>
                <div>
                  <span className="text-muted-foreground">Overtime:</span>
                  <div className="font-medium text-blue-600">+{formatCurrency(record.overtime_pay)}</div>
                </div>
              </div>

              {record.notes && (
                <div className="text-sm">
                  <span className="text-muted-foreground">Notes:</span>
                  <p className="mt-1">{record.notes}</p>
                </div>
              )}

              <div className="flex justify-between items-center">
                <div className="text-sm text-muted-foreground">
                  {record.status === 'paid' && record.pay_date && 
                    `Paid on ${new Date(record.pay_date).toLocaleDateString()}`
                  }
                </div>
                
                {record.status === 'pending' && (
                  <Button 
                    size="sm" 
                    onClick={() => handleMarkAsPaid(record.id)}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    Mark as Paid
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredRecords.length === 0 && (
        <div className="text-center py-8">
          <DollarSign className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium text-muted-foreground">No payroll records found</h3>
          <p className="text-muted-foreground">No payroll records found for the selected period and filters.</p>
        </div>
      )}

      <PayrollDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        selectedMonth={selectedMonth}
        onSuccess={fetchPayrollRecords}
      />
    </div>
  );
};

export default PayrollManagement;
