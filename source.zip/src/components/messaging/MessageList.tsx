
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MessageSquare, Clock, Users, Check } from 'lucide-react';
import { Message } from '@/types/messaging';

interface MessageListProps {
  messages?: Message[];
  onRefresh?: () => void;
}

const MessageList: React.FC<MessageListProps> = ({ messages = [], onRefresh }) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'sent': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'failed': return 'bg-red-100 text-red-800';
      case 'delivered': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getChannelIcon = (channel: string) => {
    switch (channel) {
      case 'sms': return '📱';
      case 'email': return '📧';
      case 'whatsapp': return '💬';
      default: return '📬';
    }
  };

  if (messages.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Recent Messages</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <MessageSquare className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Messages Yet</h3>
            <p className="text-muted-foreground">
              Messages will appear here once you start sending them.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Messages</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {messages.map((message) => (
            <div key={message.id} className="border rounded-lg p-4">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-lg">{getChannelIcon(message.channel)}</span>
                  <h4 className="font-medium">{message.title}</h4>
                </div>
                <Badge className={getStatusColor(message.status)}>
                  {message.status}
                </Badge>
              </div>
              
              <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                {message.content}
              </p>
              
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1">
                    <Users className="h-3 w-3" />
                    <span>{message.recipient_ids?.length || 0} recipients</span>
                  </div>
                  
                  <div className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    <span>{new Date(message.created_at).toLocaleDateString()}</span>
                  </div>
                  
                  <Badge variant="outline" className="text-xs">
                    {message.recipient_type}
                  </Badge>
                </div>
                
                {message.sent_at && (
                  <div className="flex items-center gap-1">
                    <Check className="h-3 w-3" />
                    <span>Sent {new Date(message.sent_at).toLocaleString()}</span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default MessageList;
