import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Send, Calendar as CalendarIcon, Users, MessageSquare, Mail, Smartphone } from 'lucide-react';
import { format } from 'date-fns';
import { MessagingService } from '@/utils/messagingService';
import { MessageTemplate, ContactGroup } from '@/types/messaging';
import { useToast } from '@/hooks/use-toast';

interface MessageComposerProps {
  templates: MessageTemplate[];
  groups: ContactGroup[];
  onMessageSent: () => void;
}

const MessageComposer: React.FC<MessageComposerProps> = ({ templates, groups, onMessageSent }) => {
  const [selectedChannel, setSelectedChannel] = useState<'sms' | 'email' | 'whatsapp'>('sms');
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState<string>('none');
  const [selectedGroups, setSelectedGroups] = useState<string[]>([]);
  const [isScheduled, setIsScheduled] = useState(false);
  const [scheduledDate, setScheduledDate] = useState<Date>();
  const [scheduledTime, setScheduledTime] = useState('');
  const [recipientType, setRecipientType] = useState<'group' | 'individual'>('group');
  const [individualRecipients, setIndividualRecipients] = useState('');
  const { toast } = useToast();

  const handleTemplateSelect = (templateId: string) => {
    setSelectedTemplate(templateId);
    if (templateId !== 'none') {
      const template = templates.find(t => t.id === templateId);
      if (template) {
        setTitle(template.title);
        setContent(template.content);
      }
    } else {
      setTitle('');
      setContent('');
    }
  };

  const handleGroupToggle = (groupId: string) => {
    setSelectedGroups(prev => 
      prev.includes(groupId) 
        ? prev.filter(id => id !== groupId)
        : [...prev, groupId]
    );
  };

  const handleSendMessage = async () => {
    if (!title.trim() || !content.trim()) {
      toast({
        title: "Validation Error",
        description: "Please provide both title and content for the message.",
        variant: "destructive",
      });
      return;
    }

    if (recipientType === 'group' && selectedGroups.length === 0) {
      toast({
        title: "Validation Error",
        description: "Please select at least one group.",
        variant: "destructive",
      });
      return;
    }

    if (recipientType === 'individual' && !individualRecipients.trim()) {
      toast({
        title: "Validation Error",
        description: "Please provide recipient contact information.",
        variant: "destructive",
      });
      return;
    }

    try {
      const recipientIds = recipientType === 'group' 
        ? selectedGroups 
        : individualRecipients.split(',').map(r => r.trim()).filter(r => r);

      const messageData = {
        title,
        content,
        channel: selectedChannel,
        recipient_type: recipientType,
        recipient_ids: recipientIds,
        scheduled_at: isScheduled && scheduledDate && scheduledTime 
          ? new Date(`${format(scheduledDate, 'yyyy-MM-dd')}T${scheduledTime}:00.000Z`).toISOString()
          : undefined,
        metadata: {
          template_id: selectedTemplate !== 'none' ? selectedTemplate : null,
        },
      };

      const result = await MessagingService.sendMessage(messageData);
      if (result) {
        toast({
          title: "Success",
          description: isScheduled ? "Message scheduled successfully!" : "Message sent successfully!",
        });
        
        // Reset form
        setTitle('');
        setContent('');
        setSelectedTemplate('none');
        setSelectedGroups([]);
        setIndividualRecipients('');
        setIsScheduled(false);
        setScheduledDate(undefined);
        setScheduledTime('');
        
        onMessageSent();
      }
    } catch (error) {
      console.error('Error sending message:', error);
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    }
  };

  const getChannelIcon = (channel: string) => {
    switch (channel) {
      case 'sms': return <Smartphone className="h-4 w-4" />;
      case 'email': return <Mail className="h-4 w-4" />;
      case 'whatsapp': return <MessageSquare className="h-4 w-4" />;
      default: return <MessageSquare className="h-4 w-4" />;
    }
  };

  const estimatedRecipients = recipientType === 'group' 
    ? selectedGroups.reduce((total, groupId) => {
        const group = groups.find(g => g.id === groupId);
        return total + (group ? group.member_ids.length : 0);
      }, 0)
    : individualRecipients.split(',').filter(r => r.trim()).length;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Send className="h-5 w-5" />
          Compose Message
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Channel Selection */}
        <div className="space-y-2">
          <Label>Channel</Label>
          <div className="flex gap-2">
            {(['sms', 'email', 'whatsapp'] as const).map((channel) => (
              <Badge
                key={channel}
                variant={selectedChannel === channel ? "default" : "outline"}
                className="cursor-pointer flex items-center gap-1"
                onClick={() => setSelectedChannel(channel)}
              >
                {getChannelIcon(channel)}
                {channel.toUpperCase()}
              </Badge>
            ))}
          </div>
        </div>

        {/* Template Selection */}
        <div className="space-y-2">
          <Label>Use Template (Optional)</Label>
          <Select value={selectedTemplate} onValueChange={handleTemplateSelect}>
            <SelectTrigger>
              <SelectValue placeholder="Select a template" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="none">No Template</SelectItem>
              {templates
                .filter(template => template.channels.includes(selectedChannel))
                .map((template) => (
                  <SelectItem key={template.id} value={template.id}>
                    {template.name}
                  </SelectItem>
                ))}
            </SelectContent>
          </Select>
        </div>

        {/* Message Content */}
        <div className="grid grid-cols-1 gap-4">
          <div className="space-y-2">
            <Label>Message Title</Label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter message title"
            />
          </div>
          <div className="space-y-2">
            <Label>Message Content</Label>
            <Textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Enter your message content..."
              rows={6}
            />
            <div className="text-xs text-muted-foreground">
              Character count: {content.length} | Estimated {selectedChannel === 'sms' ? 'SMS' : 'message'} parts: {Math.ceil(content.length / (selectedChannel === 'sms' ? 160 : 1000))}
            </div>
          </div>
        </div>

        {/* Recipient Selection */}
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Recipients</Label>
            <div className="flex gap-2">
              <Badge
                variant={recipientType === 'group' ? "default" : "outline"}
                className="cursor-pointer"
                onClick={() => setRecipientType('group')}
              >
                <Users className="h-3 w-3 mr-1" />
                Groups
              </Badge>
              <Badge
                variant={recipientType === 'individual' ? "default" : "outline"}
                className="cursor-pointer"
                onClick={() => setRecipientType('individual')}
              >
                <MessageSquare className="h-3 w-3 mr-1" />
                Individual
              </Badge>
            </div>
          </div>

          {recipientType === 'group' ? (
            <div className="space-y-2">
              <Label>Select Contact Groups</Label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {groups.map((group) => (
                  <div
                    key={group.id}
                    className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                      selectedGroups.includes(group.id)
                        ? 'border-primary bg-primary/5'
                        : 'border-border hover:border-primary/50'
                    }`}
                    onClick={() => handleGroupToggle(group.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-sm">{group.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {group.is_dynamic ? 'Dynamic' : `${group.member_ids.length} members`}
                        </p>
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {group.group_type.replace('_', ' ').toUpperCase()}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              <Label>Individual Recipients</Label>
              <Textarea
                value={individualRecipients}
                onChange={(e) => setIndividualRecipients(e.target.value)}
                placeholder={`Enter ${selectedChannel === 'email' ? 'email addresses' : 'phone numbers'} separated by commas`}
                rows={3}
              />
            </div>
          )}
        </div>

        {/* Scheduling */}
        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            <Switch
              checked={isScheduled}
              onCheckedChange={setIsScheduled}
            />
            <Label>Schedule Message</Label>
          </div>

          {isScheduled && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {scheduledDate ? format(scheduledDate, "PPP") : "Pick a date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={scheduledDate}
                      onSelect={setScheduledDate}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
              <div className="space-y-2">
                <Label>Time</Label>
                <Input
                  type="time"
                  value={scheduledTime}
                  onChange={(e) => setScheduledTime(e.target.value)}
                />
              </div>
            </div>
          )}
        </div>

        {/* Message Summary */}
        <div className="bg-muted p-4 rounded-lg">
          <h4 className="font-medium mb-2">Message Summary</h4>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">Channel:</span>
              <div className="flex items-center gap-1 mt-1">
                {getChannelIcon(selectedChannel)}
                {selectedChannel.toUpperCase()}
              </div>
            </div>
            <div>
              <span className="text-muted-foreground">Recipients:</span>
              <p className="mt-1">{estimatedRecipients} estimated</p>
            </div>
            <div>
              <span className="text-muted-foreground">Delivery:</span>
              <p className="mt-1">{isScheduled ? 'Scheduled' : 'Immediate'}</p>
            </div>
            <div>
              <span className="text-muted-foreground">Cost Estimate:</span>
              <p className="mt-1">
                {selectedChannel === 'sms' 
                  ? `UGX ${(estimatedRecipients * Math.ceil(content.length / 160) * 50).toLocaleString()}`
                  : 'Free'
                }
              </p>
            </div>
          </div>
        </div>

        {/* Send Button */}
        <Button 
          onClick={handleSendMessage} 
          className="w-full" 
          size="lg"
          disabled={!title.trim() || !content.trim() || (recipientType === 'group' && selectedGroups.length === 0) || (recipientType === 'individual' && !individualRecipients.trim())}
        >
          <Send className="h-4 w-4 mr-2" />
          {isScheduled ? 'Schedule Message' : 'Send Message'}
        </Button>
      </CardContent>
    </Card>
  );
};

export default MessageComposer;
