
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Sparkles, RefreshCw, ThumbsUp, ThumbsDown, Copy } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface AISuggestion {
  id: string;
  category: string;
  suggestion_type: 'subject' | 'content';
  content: string;
  context: Record<string, any>;
  rating: number;
  usage_count: number;
}

interface AIMessageAssistantProps {
  category?: string;
  onSuggestionApply: (type: 'subject' | 'content', content: string) => void;
}

const AIMessageAssistant: React.FC<AIMessageAssistantProps> = ({ 
  category = 'custom', 
  onSuggestionApply 
}) => {
  const [suggestions, setSuggestions] = useState<AISuggestion[]>([]);
  const [loading, setLoading] = useState(false);
  const [customPrompt, setCustomPrompt] = useState('');
  const [generatedContent, setGeneratedContent] = useState<{
    subject?: string;
    content?: string;
  }>({});
  const { toast } = useToast();

  useEffect(() => {
    loadSuggestions();
  }, [category]);

  const loadSuggestions = async () => {
    try {
      // Mock suggestions for now
      setSuggestions([
        {
          id: '1',
          category: 'fee_reminder',
          suggestion_type: 'subject',
          content: 'Fee Payment Reminder - {{student_name}}',
          context: { variables: ['student_name'] },
          rating: 4.5,
          usage_count: 15
        },
        {
          id: '2',
          category: 'fee_reminder',
          suggestion_type: 'content',
          content: 'Dear {{parent_name}}, this is a friendly reminder that {{student_name}}\'s school fees of UGX {{amount}} are due.',
          context: { variables: ['parent_name', 'student_name', 'amount'] },
          rating: 4.2,
          usage_count: 12
        },
        {
          id: '3',
          category: 'attendance_alert',
          suggestion_type: 'subject',
          content: 'Attendance Alert - {{student_name}}',
          context: { variables: ['student_name'] },
          rating: 4.0,
          usage_count: 8
        },
        {
          id: '4',
          category: 'attendance_alert',
          suggestion_type: 'content',
          content: 'Dear {{parent_name}}, {{student_name}} was absent from school today ({{date}}). Please contact us if this is unexpected.',
          context: { variables: ['parent_name', 'student_name', 'date'] },
          rating: 4.3,
          usage_count: 10
        }
      ]);
    } catch (error) {
      console.error('Error loading AI suggestions:', error);
      setSuggestions([]);
    }
  };

  const generateContent = async (prompt: string, type: 'subject' | 'content') => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('generate-ai-message', {
        body: {
          prompt: prompt || `Generate a ${type} for ${category.replace('_', ' ')}`,
          type,
          category
        }
      });

      if (error) throw error;

      if (data?.success && data?.generatedText) {
        setGeneratedContent(prev => ({
          ...prev,
          [type]: data.generatedText
        }));

        toast({
          title: "Content Generated",
          description: `AI has generated a ${type} for you.`,
        });
      } else {
        throw new Error(data?.error || 'Failed to generate content');
      }

    } catch (error) {
      console.error('Error generating content:', error);
      toast({
        title: "Generation Failed",
        description: "Failed to generate AI content. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const applySuggestion = async (suggestion: AISuggestion) => {
    onSuggestionApply(suggestion.suggestion_type, suggestion.content);
    
    toast({
      title: "Applied!",
      description: `Suggestion applied to your message.`,
    });
  };

  const rateSuggestion = async (suggestionId: string, rating: number) => {
    toast({
      title: "Thank you!",
      description: "Your feedback helps improve our AI suggestions.",
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: "Content copied to clipboard.",
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-purple-500" />
          AI Message Assistant
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Custom Content Generation */}
        <div className="space-y-3">
          <div className="flex gap-2">
            <Input
              placeholder="Describe what you want to write about..."
              value={customPrompt}
              onChange={(e) => setCustomPrompt(e.target.value)}
            />
            <Button
              onClick={() => generateContent(customPrompt, 'content')}
              disabled={loading}
              size="sm"
            >
              {loading ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
              Generate
            </Button>
          </div>
          
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => generateContent('Generate a professional subject line', 'subject')}
              disabled={loading}
            >
              Generate Subject
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => generateContent('Generate professional message content', 'content')}
              disabled={loading}
            >
              Generate Content
            </Button>
          </div>
        </div>

        {/* Generated Content Display */}
        {(generatedContent.subject || generatedContent.content) && (
          <div className="space-y-3 p-3 bg-muted rounded-lg">
            {generatedContent.subject && (
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-medium">Generated Subject:</h4>
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => copyToClipboard(generatedContent.subject!)}
                    >
                      <Copy className="h-3 w-3" />
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => onSuggestionApply('subject', generatedContent.subject!)}
                    >
                      Apply
                    </Button>
                  </div>
                </div>
                <p className="text-sm bg-background p-2 rounded border">
                  {generatedContent.subject}
                </p>
              </div>
            )}
            
            {generatedContent.content && (
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-medium">Generated Content:</h4>
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => copyToClipboard(generatedContent.content!)}
                    >
                      <Copy className="h-3 w-3" />
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => onSuggestionApply('content', generatedContent.content!)}
                    >
                      Apply
                    </Button>
                  </div>
                </div>
                <Textarea
                  value={generatedContent.content}
                  readOnly
                  className="text-sm"
                  rows={4}
                />
              </div>
            )}
          </div>
        )}

        {/* Pre-built Suggestions */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium">Suggestions for {category.replace('_', ' ')}:</h4>
          <div className="grid gap-2">
            {suggestions.filter(s => s.category === category || category === 'custom').map((suggestion) => (
              <div key={suggestion.id} className="p-3 border rounded-lg">
                <div className="flex items-start justify-between mb-2">
                  <Badge variant="secondary" className="text-xs">
                    {suggestion.suggestion_type}
                  </Badge>
                  <div className="flex items-center gap-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => rateSuggestion(suggestion.id, 5)}
                    >
                      <ThumbsUp className="h-3 w-3" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => rateSuggestion(suggestion.id, 1)}
                    >
                      <ThumbsDown className="h-3 w-3" />
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => applySuggestion(suggestion)}
                    >
                      Use
                    </Button>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mb-2">
                  {suggestion.content}
                </p>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span>Used {suggestion.usage_count} times</span>
                  <span>•</span>
                  <span>Rating: {suggestion.rating.toFixed(1)}/5</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AIMessageAssistant;
