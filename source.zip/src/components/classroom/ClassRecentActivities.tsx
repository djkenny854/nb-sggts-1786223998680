
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Clock, 
  DollarSign, 
  UserPlus, 
  Calendar,
  MessageCircle,
  FileText
} from 'lucide-react';

interface Activity {
  id: string;
  type: 'payment' | 'enrollment' | 'attendance' | 'message' | 'report';
  description: string;
  timestamp: string;
  user?: string;
  amount?: number;
}

interface ClassRecentActivitiesProps {
  className: string;
}

const ClassRecentActivities: React.FC<ClassRecentActivitiesProps> = ({ className }) => {
  // Mock recent activities - in real app, this would come from database
  const activities: Activity[] = [
    {
      id: '1',
      type: 'payment',
      description: 'Fee payment received from John Doe',
      timestamp: '2 hours ago',
      user: 'John Doe',
      amount: 500
    },
    {
      id: '2',
      type: 'enrollment',
      description: 'New student enrolled in class',
      timestamp: '1 day ago',
      user: 'Jane Smith'
    },
    {
      id: '3',
      type: 'attendance',
      description: 'Attendance marked for today',
      timestamp: '2 days ago',
      user: 'Teacher'
    },
    {
      id: '4',
      type: 'message',
      description: 'Parent meeting reminder sent',
      timestamp: '3 days ago',
      user: 'System'
    },
    {
      id: '5',
      type: 'report',
      description: 'Monthly progress report generated',
      timestamp: '1 week ago',
      user: 'Admin'
    }
  ];

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'payment': return DollarSign;
      case 'enrollment': return UserPlus;
      case 'attendance': return Calendar;
      case 'message': return MessageCircle;
      case 'report': return FileText;
      default: return Clock;
    }
  };

  const getActivityColor = (type: string) => {
    switch (type) {
      case 'payment': return 'text-green-500';
      case 'enrollment': return 'text-blue-500';
      case 'attendance': return 'text-purple-500';
      case 'message': return 'text-orange-500';
      case 'report': return 'text-indigo-500';
      default: return 'text-gray-500';
    }
  };

  const getActivityBadge = (type: string) => {
    const colors = {
      payment: 'bg-green-100 text-green-800',
      enrollment: 'bg-blue-100 text-blue-800',
      attendance: 'bg-purple-100 text-purple-800',
      message: 'bg-orange-100 text-orange-800',
      report: 'bg-indigo-100 text-indigo-800'
    };
    return colors[type as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="w-5 h-5" />
          Recent Activities
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity) => {
            const IconComponent = getActivityIcon(activity.type);
            return (
              <div key={activity.id} className="flex items-start gap-3 p-3 rounded-lg border-l-4 border-l-gray-200 bg-gray-50">
                <IconComponent className={`w-4 h-4 mt-0.5 ${getActivityColor(activity.type)}`} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge 
                      variant="outline" 
                      className={`text-xs capitalize ${getActivityBadge(activity.type)}`}
                    >
                      {activity.type}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {activity.timestamp}
                    </span>
                  </div>
                  <p className="text-sm text-gray-700">
                    {activity.description}
                    {activity.amount && (
                      <span className="font-medium text-green-600 ml-1">
                        (${activity.amount})
                      </span>
                    )}
                  </p>
                  {activity.user && (
                    <p className="text-xs text-muted-foreground mt-1">
                      by {activity.user}
                    </p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};

export default ClassRecentActivities;
