
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { DollarSign, TrendingUp, AlertCircle } from 'lucide-react';

interface ClassFeeStatsProps {
  totalExpected: number;
  totalCollected: number;
  averageBalance: number;
  defaultersCount: number;
}

const ClassFeeStats: React.FC<ClassFeeStatsProps> = ({
  totalExpected,
  totalCollected,
  averageBalance,
  defaultersCount
}) => {
  const collectionRate = totalExpected > 0 ? (totalCollected / totalExpected) * 100 : 0;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <DollarSign className="w-5 h-5" />
          Fee Collection Summary
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">
              ${totalCollected.toLocaleString()}
            </div>
            <div className="text-sm text-muted-foreground">Collected</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-600">
              ${totalExpected.toLocaleString()}
            </div>
            <div className="text-sm text-muted-foreground">Expected</div>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Collection Rate</span>
            <span className="font-medium">{collectionRate.toFixed(1)}%</span>
          </div>
          <Progress value={collectionRate} className="h-2" />
        </div>

        <div className="grid grid-cols-2 gap-4 pt-2 border-t">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-blue-500" />
            <div>
              <div className="text-sm font-medium">${averageBalance.toFixed(2)}</div>
              <div className="text-xs text-muted-foreground">Avg Balance</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-500" />
            <div>
              <div className="text-sm font-medium">{defaultersCount}</div>
              <div className="text-xs text-muted-foreground">Defaulters</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ClassFeeStats;
