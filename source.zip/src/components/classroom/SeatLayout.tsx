
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';
import { Plus, User, Settings, Phone, MapPin, CreditCard } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface Student {
  id: string;
  full_name: string;
  student_id: string;
  class: string;
  parent_name: string;
  parent_contact: string;
  fee_status: string;
  boarding_status: string;
  transport: string;
  profile_image_url: string;
  address: string;
}

interface SeatLayout {
  id: string;
  class_name: string;
  rows: number;
  columns: number;
}

interface SeatAssignment {
  id: string;
  seat_position: string;
  student_id: string;
  student?: Student;
}

interface SeatLayoutProps {
  className: string;
}

const SeatLayout: React.FC<SeatLayoutProps> = ({ className }) => {
  const [layout, setLayout] = useState<SeatLayout | null>(null);
  const [assignments, setAssignments] = useState<SeatAssignment[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [selectedSeat, setSelectedSeat] = useState<string | null>(null);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [showStudentDialog, setShowStudentDialog] = useState(false);
  const [showAssignDialog, setShowAssignDialog] = useState(false);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  // Generate seat position (A1, B2, etc.)
  const generateSeatPosition = (row: number, col: number) => {
    const rowLetter = String.fromCharCode(65 + row); // A, B, C, etc.
    return `${rowLetter}${col + 1}`;
  };

  // Get fee status color
  const getFeeStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'paid':
        return 'border-green-500';
      case 'partial':
        return 'border-yellow-500';
      case 'unpaid':
        return 'border-red-500';
      default:
        return 'border-gray-300';
    }
  };

  // Fetch layout and assignments
  const fetchLayoutData = async () => {
    try {
      setLoading(true);
      
      // Get or create layout
      let { data: layoutData, error: layoutError } = await supabase
        .from('seat_layouts')
        .select('*')
        .eq('class_name', className)
        .single();

      if (layoutError && layoutError.code === 'PGRST116') {
        // Create default layout
        const { data: newLayout, error: createError } = await supabase
          .from('seat_layouts')
          .insert({
            class_name: className,
            rows: 6,
            columns: 10
          })
          .select()
          .single();

        if (createError) throw createError;
        layoutData = newLayout;
      } else if (layoutError) {
        throw layoutError;
      }

      setLayout(layoutData);

      // Get assignments with student data
      const { data: assignmentData, error: assignmentError } = await supabase
        .from('seat_assignments')
        .select(`
          *,
          students (*)
        `)
        .eq('seat_layout_id', layoutData.id);

      if (assignmentError) throw assignmentError;

      const assignmentsWithStudents = assignmentData.map(assignment => ({
        ...assignment,
        student: assignment.students
      }));

      setAssignments(assignmentsWithStudents);

      // Get all students in this class
      const { data: studentsData, error: studentsError } = await supabase
        .from('students')
        .select('*')
        .eq('class', className);

      if (studentsError) throw studentsError;
      setStudents(studentsData || []);

    } catch (error) {
      console.error('Error fetching layout data:', error);
      toast({
        title: "Error",
        description: "Failed to load seat layout",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  // Assign student to seat
  const assignStudentToSeat = async (studentId: string) => {
    if (!layout || !selectedSeat) return;

    try {
      // Remove existing assignment for this seat
      await supabase
        .from('seat_assignments')
        .delete()
        .eq('seat_layout_id', layout.id)
        .eq('seat_position', selectedSeat);

      // Remove existing assignment for this student (one student per layout)
      await supabase
        .from('seat_assignments')
        .delete()
        .eq('seat_layout_id', layout.id)
        .eq('student_id', studentId);

      // Create new assignment
      const { error } = await supabase
        .from('seat_assignments')
        .insert({
          seat_layout_id: layout.id,
          seat_position: selectedSeat,
          student_id: studentId
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Student assigned to seat successfully"
      });

      setShowAssignDialog(false);
      setSelectedSeat(null);
      fetchLayoutData();

    } catch (error) {
      console.error('Error assigning student:', error);
      toast({
        title: "Error",
        description: "Failed to assign student to seat",
        variant: "destructive"
      });
    }
  };

  // Update layout dimensions
  const updateLayout = async (rows: number, columns: number) => {
    if (!layout) return;

    try {
      const { error } = await supabase
        .from('seat_layouts')
        .update({ rows, columns })
        .eq('id', layout.id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Layout updated successfully"
      });

      fetchLayoutData();

    } catch (error) {
      console.error('Error updating layout:', error);
      toast({
        title: "Error",
        description: "Failed to update layout",
        variant: "destructive"
      });
    }
  };

  // Get student for seat position
  const getStudentForSeat = (seatPosition: string) => {
    return assignments.find(a => a.seat_position === seatPosition)?.student;
  };

  // Get available students (not assigned to any seat in this layout)
  const getAvailableStudents = () => {
    const assignedStudentIds = assignments.map(a => a.student_id);
    return students.filter(s => !assignedStudentIds.includes(s.id));
  };

  useEffect(() => {
    fetchLayoutData();
  }, [className]);

  if (loading) {
    return <div className="flex justify-center p-8">Loading seat layout...</div>;
  }

  if (!layout) {
    return <div className="text-center p-8">Failed to load seat layout</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Seat Layout - {className}</h2>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => updateLayout(layout.rows + 1, layout.columns)}
          >
            + Add Row
          </Button>
          <Button
            variant="outline"
            onClick={() => updateLayout(layout.rows, layout.columns + 1)}
          >
            + Add Column
          </Button>
        </div>
      </div>

      {/* Layout Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Layout Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="flex gap-4 items-end">
          <div>
            <Label>Rows: {layout.rows}</Label>
            <Input
              type="number"
              min="1"
              max="20"
              value={layout.rows}
              onChange={(e) => updateLayout(parseInt(e.target.value), layout.columns)}
              className="w-20"
            />
          </div>
          <div>
            <Label>Columns: {layout.columns}</Label>
            <Input
              type="number"
              min="1"
              max="20"
              value={layout.columns}
              onChange={(e) => updateLayout(layout.rows, parseInt(e.target.value))}
              className="w-20"
            />
          </div>
        </CardContent>
      </Card>

      {/* Seat Grid */}
      <Card>
        <CardContent className="p-6">
          <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${layout.columns}, 1fr)` }}>
            {Array.from({ length: layout.rows }, (_, rowIndex) =>
              Array.from({ length: layout.columns }, (_, colIndex) => {
                const seatPosition = generateSeatPosition(rowIndex, colIndex);
                const student = getStudentForSeat(seatPosition);

                return (
                  <TooltipProvider key={seatPosition}>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <div
                          className={`
                            aspect-square border-2 rounded-lg p-2 cursor-pointer
                            transition-all hover:shadow-md
                            ${student ? getFeeStatusColor(student.fee_status) : 'border-gray-300'}
                            ${student ? 'bg-white' : 'bg-gray-50'}
                            flex flex-col items-center justify-center
                            min-h-[80px]
                          `}
                          onClick={() => {
                            if (student) {
                              setSelectedStudent(student);
                              setShowStudentDialog(true);
                            } else {
                              setSelectedSeat(seatPosition);
                              setShowAssignDialog(true);
                            }
                          }}
                        >
                          <div className="text-xs font-mono text-gray-500 mb-1">
                            {seatPosition}
                          </div>
                          {student ? (
                            <>
                              <Avatar className="w-8 h-8 mb-1">
                                <AvatarImage src={student.profile_image_url} />
                                <AvatarFallback className="text-xs">
                                  {student.full_name.split(' ').map(n => n[0]).join('')}
                                </AvatarFallback>
                              </Avatar>
                              <div className="text-xs text-center font-medium truncate w-full">
                                {student.full_name.split(' ')[0]}
                              </div>
                            </>
                          ) : (
                            <Plus className="w-6 h-6 text-gray-400" />
                          )}
                        </div>
                      </TooltipTrigger>
                      <TooltipContent>
                        {student ? (
                          <div>
                            <p className="font-medium">{student.full_name}</p>
                            <p className="text-sm">ID: {student.student_id}</p>
                            <p className="text-sm">Fee: {student.fee_status}</p>
                          </div>
                        ) : (
                          <p>Click to assign student</p>
                        )}
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                );
              })
            )}
          </div>
        </CardContent>
      </Card>

      {/* Student Details Dialog */}
      <Dialog open={showStudentDialog} onOpenChange={setShowStudentDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Student Details</DialogTitle>
          </DialogHeader>
          {selectedStudent && (
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <Avatar className="w-16 h-16">
                  <AvatarImage src={selectedStudent.profile_image_url} />
                  <AvatarFallback>
                    {selectedStudent.full_name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-semibold">{selectedStudent.full_name}</h3>
                  <p className="text-sm text-gray-600">ID: {selectedStudent.student_id}</p>
                  <Badge variant="outline">{selectedStudent.class}</Badge>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4" />
                  <div>
                    <p className="font-medium">Parent</p>
                    <p>{selectedStudent.parent_name}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  <div>
                    <p className="font-medium">Contact</p>
                    <p>{selectedStudent.parent_contact}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <CreditCard className="w-4 h-4" />
                  <div>
                    <p className="font-medium">Fee Status</p>
                    <Badge variant={selectedStudent.fee_status === 'paid' ? 'default' : 'destructive'}>
                      {selectedStudent.fee_status}
                    </Badge>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  <div>
                    <p className="font-medium">Transport</p>
                    <p>{selectedStudent.transport}</p>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center gap-2 text-sm">
                <MapPin className="w-4 h-4" />
                <div>
                  <p className="font-medium">Address</p>
                  <p>{selectedStudent.address}</p>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Assign Student Dialog */}
      <Dialog open={showAssignDialog} onOpenChange={setShowAssignDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Assign Student to Seat {selectedSeat}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="max-h-60 overflow-y-auto">
              {getAvailableStudents().map((student) => (
                <div
                  key={student.id}
                  className="flex items-center gap-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50"
                  onClick={() => assignStudentToSeat(student.id)}
                >
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={student.profile_image_url} />
                    <AvatarFallback>
                      {student.full_name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{student.full_name}</p>
                    <p className="text-sm text-gray-600">ID: {student.student_id}</p>
                  </div>
                </div>
              ))}
            </div>
            {getAvailableStudents().length === 0 && (
              <p className="text-center text-gray-500 py-4">
                All students are already assigned to seats
              </p>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default SeatLayout;
