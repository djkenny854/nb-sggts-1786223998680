import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Search, DollarSign, Users, AlertCircle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import TodayCollections from './TodayCollections';
import StudentFeesList from './StudentFeesList';

const FeeManagementDashboard = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const { data: dashboardStats, isLoading: statsLoading } = useQuery({
    queryKey: ['fee-dashboard-stats'],
    queryFn: async () => {
      const { data: transactions, error: transError } = await supabase
        .from('fee_transactions')
        .select('amount');
      
      if (transError) throw transError;

      const totalCollections = transactions?.reduce((sum, t) => sum + (t.amount || 0), 0) || 0;

      const { data: studentFees, error: feesError } = await supabase
        .from('student_fees')
        .select('total_assigned_fees, total_paid');

      if (feesError) throw feesError;

      const totalStudents = studentFees?.length || 0;
      
      const paidStudents = studentFees?.filter(s => 
        (s.total_paid || 0) >= (s.total_assigned_fees || 0) && (s.total_assigned_fees || 0) > 0
      ).length || 0;
      
      const partialStudents = studentFees?.filter(s => 
        (s.total_paid || 0) > 0 && (s.total_paid || 0) < (s.total_assigned_fees || 0)
      ).length || 0;
      
      const unpaidStudents = studentFees?.filter(s => 
        (s.total_paid || 0) === 0 && (s.total_assigned_fees || 0) > 0
      ).length || 0;
      
      const totalOutstanding = studentFees?.reduce((sum, s) => 
        sum + ((s.total_assigned_fees || 0) - (s.total_paid || 0)), 0
      ) || 0;

      return {
        totalCollections,
        totalStudents,
        paidStudents,
        partialStudents,
        unpaidStudents,
        totalOutstanding
      };
    }
  });

  const StatCard = ({ title, value, icon: Icon, color, subtitle }: any) => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className={`h-4 w-4 ${color}`} />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold truncate">{value}</div>
        {subtitle && <p className="text-xs text-muted-foreground mt-1 truncate">{subtitle}</p>}
      </CardContent>
    </Card>
  );

  if (statsLoading) {
    return (
      <div className="space-y-6">
        <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardHeader>
                <div className="h-4 bg-muted rounded animate-pulse"></div>
              </CardHeader>
              <CardContent>
                <div className="h-8 bg-muted rounded animate-pulse"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Statistics Cards */}
      <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
        <TodayCollections />
        
        <StatCard
          title="Total Collections"
          value={`UGX ${(dashboardStats?.totalCollections || 0).toLocaleString()}`}
          icon={DollarSign}
          color="text-green-500"
          subtitle="All time collections"
        />
        
        <StatCard
          title="Students with Fees"
          value={dashboardStats?.totalStudents || 0}
          icon={Users}
          color="text-primary"
          subtitle={`${dashboardStats?.paidStudents || 0} fully paid`}
        />
        
        <StatCard
          title="Outstanding Amount"
          value={`UGX ${(dashboardStats?.totalOutstanding || 0).toLocaleString()}`}
          icon={AlertCircle}
          color="text-destructive"
          subtitle={`${dashboardStats?.unpaidStudents || 0} unpaid students`}
        />
      </div>

      {/* Payment Status Overview */}
      <Card>
        <CardHeader>
          <CardTitle>Payment Status Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-green-500/10 rounded-lg border border-green-500/20">
              <div className="text-2xl font-bold text-green-500">
                {dashboardStats?.paidStudents || 0}
              </div>
              <div className="text-sm text-green-600 dark:text-green-400">Fully Paid</div>
            </div>
            <div className="text-center p-4 bg-primary/10 rounded-lg border border-primary/20">
              <div className="text-2xl font-bold text-primary">
                {dashboardStats?.partialStudents || 0}
              </div>
              <div className="text-sm text-primary">Partial Payment</div>
            </div>
            <div className="text-center p-4 bg-destructive/10 rounded-lg border border-destructive/20">
              <div className="text-2xl font-bold text-destructive">
                {dashboardStats?.unpaidStudents || 0}
              </div>
              <div className="text-sm text-destructive">Unpaid</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Student Fees Management */}
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <CardTitle>Student Fees Management</CardTitle>
            <div className="relative w-full sm:w-auto">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search students..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-full sm:w-64 bg-secondary border-border"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <StudentFeesList searchTerm={searchTerm} />
        </CardContent>
      </Card>
    </div>
  );
};

export default FeeManagementDashboard;
