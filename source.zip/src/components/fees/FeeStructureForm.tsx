
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';

interface ClassOption {
  id: string;
  full_name: string;
  class_level: string;
  stream_name: string;
}

interface FeeStructureFormProps {
  formData: any;
  setFormData: (data: any) => void;
  selectedClasses: string[];
  setSelectedClasses: (classes: string[]) => void;
  classOptions: ClassOption[];
  editingId: string | null;
  calculateTotal: () => number;
  handleSubmit: (e: React.FormEvent) => Promise<void>;
  resetForm: () => void;
}

const FeeStructureForm: React.FC<FeeStructureFormProps> = ({
  formData,
  setFormData,
  selectedClasses,
  setSelectedClasses,
  classOptions,
  editingId,
  calculateTotal,
  handleSubmit,
  resetForm,
}) => {
  const handleClassToggle = (className: string) => {
    setSelectedClasses(
      selectedClasses.includes(className)
        ? selectedClasses.filter(c => c !== className)
        : [...selectedClasses, className]
    );
  };

  const feeFields = [
    { key: 'tuition_fee', label: 'Tuition Fee', required: true },
    { key: 'boarding_fee', label: 'Boarding Fee' },
    { key: 'transport_fee', label: 'Transport Fee' },
    { key: 'meals_fee', label: 'Meals Fee' },
    { key: 'activities_fee', label: 'Activities Fee' },
    { key: 'library_fee', label: 'Library Fee' },
    { key: 'computer_fee', label: 'Computer Fee' },
    { key: 'laboratory_fee', label: 'Laboratory Fee' },
    { key: 'sports_fee', label: 'Sports Fee' },
    { key: 'medical_fee', label: 'Medical Fee' },
    { key: 'development_fee', label: 'Development Fee' },
    { key: 'exam_fee', label: 'Exam Fee' },
    { key: 'uniform_fee', label: 'Uniform Fee' },
    { key: 'miscellaneous_fee', label: 'Miscellaneous Fee' }
  ];

  return (
    <Card className="bg-white border-gray-200">
      <CardHeader className="bg-gray-50 border-b">
        <CardTitle className="text-gray-900">
          {editingId ? 'Edit Fee Structure' : 'Create New Fee Structure'}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name" className="text-gray-700">Structure Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="e.g., Primary School Term 1 Fees"
                required
                className="bg-white border-gray-300"
              />
            </div>
            <div>
              <Label htmlFor="class_level" className="text-gray-700">Class Level</Label>
              <Input
                id="class_level"
                value={formData.class_level}
                onChange={(e) => setFormData({...formData, class_level: e.target.value})}
                placeholder="e.g., Primary 1-3, Secondary 1-4"
                className="bg-white border-gray-300"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="description" className="text-gray-700">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              placeholder="Brief description of this fee structure"
              className="bg-white border-gray-300"
            />
          </div>

          {/* Academic Period */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="academic_year" className="text-gray-700">Academic Year *</Label>
              <Input
                id="academic_year"
                value={formData.academic_year}
                onChange={(e) => setFormData({...formData, academic_year: e.target.value})}
                required
                className="bg-white border-gray-300"
              />
            </div>
            <div>
              <Label htmlFor="academic_term" className="text-gray-700">Academic Term *</Label>
              <Select 
                value={formData.academic_term} 
                onValueChange={(value) => setFormData({...formData, academic_term: value})}
              >
                <SelectTrigger className="bg-white border-gray-300">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-white border-gray-300">
                  <SelectItem value="Term 1">Term 1</SelectItem>
                  <SelectItem value="Term 2">Term 2</SelectItem>
                  <SelectItem value="Term 3">Term 3</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="boarding_status" className="text-gray-700">Boarding Status</Label>
              <Select 
                value={formData.boarding_status} 
                onValueChange={(value) => setFormData({...formData, boarding_status: value})}
              >
                <SelectTrigger className="bg-white border-gray-300">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-white border-gray-300">
                  <SelectItem value="Both">Both Day & Boarding</SelectItem>
                  <SelectItem value="Day">Day Students Only</SelectItem>
                  <SelectItem value="Boarding">Boarding Students Only</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Class Selection */}
          <div>
            <Label className="text-gray-700 block mb-3">Assign to Classes</Label>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 max-h-48 overflow-y-auto p-4 border border-gray-300 rounded-md bg-gray-50">
              {classOptions.map((classOption) => (
                <label key={classOption.id} className="flex items-center space-x-2 cursor-pointer">
                  <Checkbox
                    checked={selectedClasses.includes(classOption.full_name)}
                    onCheckedChange={() => handleClassToggle(classOption.full_name)}
                  />
                  <span className="text-sm text-gray-700">{classOption.full_name}</span>
                </label>
              ))}
            </div>
            {selectedClasses.length > 0 && (
              <p className="text-sm text-gray-600 mt-2">
                Selected: {selectedClasses.join(', ')}
              </p>
            )}
          </div>

          {/* Fee Components */}
          <div>
            <Label className="text-gray-700 text-lg font-semibold block mb-4">Fee Components (UGX)</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {feeFields.map((field) => (
                <div key={field.key}>
                  <Label htmlFor={field.key} className="text-gray-700">
                    {field.label} {field.required && '*'}
                  </Label>
                  <Input
                    id={field.key}
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData[field.key]}
                    onChange={(e) => setFormData({
                      ...formData, 
                      [field.key]: parseFloat(e.target.value) || 0
                    })}
                    required={field.required}
                    className="bg-white border-gray-300"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Status Switches */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center space-x-2">
              <Switch
                id="is_active"
                checked={formData.is_active}
                onCheckedChange={(checked) => setFormData({...formData, is_active: checked})}
              />
              <Label htmlFor="is_active" className="text-gray-700">Active Structure</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="is_default"
                checked={formData.is_default}
                onCheckedChange={(checked) => setFormData({...formData, is_default: checked})}
              />
              <Label htmlFor="is_default" className="text-gray-700">Set as Default</Label>
            </div>
          </div>

          {/* Total Display */}
          <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
            <div className="flex justify-between items-center">
              <span className="text-lg font-semibold text-gray-700">Total Fee Structure:</span>
              <span className="text-2xl font-bold text-blue-600">
                UGX {calculateTotal().toLocaleString()}
              </span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4">
            <Button 
              type="submit" 
              className="bg-blue-600 hover:bg-blue-700 text-white px-6"
            >
              {editingId ? 'Update Structure' : 'Create Structure'}
            </Button>
            <Button 
              type="button" 
              variant="outline" 
              onClick={resetForm}
              className="border-gray-300 text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default FeeStructureForm;
