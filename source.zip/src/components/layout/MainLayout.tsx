import React from 'react';
import Sidebar from './Sidebar';
import TopBar from './TopBar';
import MobileNav from './MobileNav';
import RightSidebar from './RightSidebar';
import GeminiChatPanel from '@/components/ai/GeminiChatPanel';
import { useSiteSettings } from '@/context/SiteSettingsContext';
import { useIsMobile } from '@/hooks/use-mobile';

interface MainLayoutProps {
  children: React.ReactNode;
}

const MainLayout: React.FC<MainLayoutProps> = ({ children }) => {
  const { isSidebarOpen, isRightSidebarOpen, isGeminiPanelOpen, toggleGeminiPanel, toggleSidebar } = useSiteSettings();
  const isMobile = useIsMobile();

  const sidebarWidth = isMobile ? 0 : (isSidebarOpen ? 256 : 64);
  const rightSidebarWidth = isMobile ? 0 : (isRightSidebarOpen ? 320 : 0);

  return (
    <div className="min-h-screen bg-background">
      {/* Desktop Sidebar */}
      {!isMobile && <Sidebar />}
      
      {/* Mobile Sidebar Overlay */}
      {isMobile && isSidebarOpen && (
        <>
          <div 
            className="fixed inset-0 bg-black/60 z-40 backdrop-blur-sm"
            onClick={toggleSidebar}
          />
          <div className="fixed left-0 top-0 h-full w-64 bg-background z-50 animate-in slide-in-from-left duration-200">
            <Sidebar />
          </div>
        </>
      )}
      
      <div 
        className="flex flex-col min-h-screen transition-all duration-300"
        style={{ 
          marginLeft: sidebarWidth,
          marginRight: rightSidebarWidth
        }}
      >
        <TopBar />
        
        <main className="flex-1 p-4 md:p-6 overflow-auto pb-20 md:pb-6">
          {children}
        </main>
      </div>
      
      {/* Right Sidebar - Desktop only */}
      {!isMobile && <RightSidebar />}
      
      {/* Mobile Bottom Navigation */}
      {isMobile && <MobileNav />}
      
      <GeminiChatPanel isOpen={isGeminiPanelOpen} onClose={toggleGeminiPanel} />
    </div>
  );
};

export default MainLayout;
