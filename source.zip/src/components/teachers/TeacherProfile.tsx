
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { School, Mail, Phone, MapPin, Calendar, Clock, User, GraduationCap, BookOpen } from 'lucide-react';

interface Subject {
  id: string;
  name: string;
  code: string;
  credits: number;
}

interface TeacherProfileProps {
  teacher: {
    id: string;
    name: string;
    email: string;
    phone: string;
    address: string;
    dateJoined: string;
    qualification: string;
    department: string;
    subjects: Subject[];
    classes: string[];
    avatar?: string;
    profileImage?: string;
    profile_image_url?: string;
    specialization?: string;
    status: 'active' | 'on leave' | 'former';
    biography?: string;
  }
}

const TeacherProfile = ({ teacher }: TeacherProfileProps) => {
  // Generate initials for avatar fallback
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase();
  };

  // Status badge color
  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'active':
        return 'success';
      case 'on leave':
        return 'warning';
      case 'former':
        return 'secondary';
      default:
        return 'default';
    }
  };

  // Get the profile image URL from various possible sources
  const getProfileImageUrl = () => {
    return teacher.profile_image_url || teacher.profileImage || teacher.avatar;
  };

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card className="backdrop-blur-sm bg-white/50 border border-white/20 shadow-lg">
        <CardHeader className="flex flex-row items-center gap-4 pb-2">
          <Avatar className="h-16 w-16">
            {getProfileImageUrl() ? (
              <AvatarImage src={getProfileImageUrl()} alt={teacher.name} />
            ) : (
              <AvatarFallback className="bg-primary/10 text-primary text-xl">
                {getInitials(teacher.name)}
              </AvatarFallback>
            )}
          </Avatar>
          <div>
            <CardTitle className="text-2xl font-bold">{teacher.name}</CardTitle>
            <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
              <GraduationCap className="h-4 w-4" />
              <span>{teacher.qualification}</span>
              <Badge variant={getStatusBadge(teacher.status) as any}>{teacher.status}</Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm">
              <School className="h-4 w-4 text-primary" />
              <span className="font-medium">Department:</span>
              <span>{teacher.department}</span>
            </div>
            
            {teacher.specialization && (
              <div className="flex items-center gap-2 text-sm">
                <BookOpen className="h-4 w-4 text-primary" />
                <span className="font-medium">Specialization:</span>
                <span>{teacher.specialization}</span>
              </div>
            )}
            
            <div className="flex items-center gap-2 text-sm">
              <Mail className="h-4 w-4 text-primary" />
              <span className="font-medium">Email:</span>
              <span>{teacher.email}</span>
            </div>
            
            <div className="flex items-center gap-2 text-sm">
              <Phone className="h-4 w-4 text-primary" />
              <span className="font-medium">Phone:</span>
              <span>{teacher.phone}</span>
            </div>
            
            <div className="flex items-center gap-2 text-sm">
              <MapPin className="h-4 w-4 text-primary" />
              <span className="font-medium">Address:</span>
              <span>{teacher.address}</span>
            </div>
            
            <div className="flex items-center gap-2 text-sm">
              <Calendar className="h-4 w-4 text-primary" />
              <span className="font-medium">Date Joined:</span>
              <span>{teacher.dateJoined}</span>
            </div>
          </div>
          
          {teacher.biography && (
            <div className="mt-4 pt-4 border-t">
              <h4 className="font-medium mb-2">Biography</h4>
              <p className="text-sm text-muted-foreground">{teacher.biography}</p>
            </div>
          )}
        </CardContent>
      </Card>
      
      <div className="space-y-6">
        <Card className="backdrop-blur-sm bg-white/50 border border-white/20 shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg font-medium">Assigned Subjects</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-2">
              {teacher.subjects.map((subject) => (
                <div key={subject.id} className="flex items-center justify-between p-3 bg-primary/5 rounded-lg">
                  <div>
                    <p className="font-medium">{subject.name}</p>
                    <p className="text-xs text-muted-foreground">{subject.code}</p>
                  </div>
                  <Badge variant="outline">{subject.credits} credits</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        
        <Card className="backdrop-blur-sm bg-white/50 border border-white/20 shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg font-medium">Assigned Classes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {teacher.classes.map((cls, index) => (
                <Badge key={index} variant="outline" className="px-3 py-1">
                  {cls}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default TeacherProfile;
