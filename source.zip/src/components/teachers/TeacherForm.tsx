
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import TeacherImageUpload from './TeacherImageUpload';

interface Teacher {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  subjects?: string[];
  class_teacher_for?: string;
  qualification?: string;
  specialization?: string;
  biography?: string;
  gender?: string;
  date_of_birth?: string;
  employee_id?: string;
  salary?: number;
  hire_date?: string;
  address?: string;
  emergency_contact?: string;
  profile_image_url?: string;
  status?: string;
  join_date?: string;
}

interface TeacherFormProps {
  teacher?: Teacher | null;
  onSuccess: () => void;
  onCancel: () => void;
}

const TeacherForm = ({ teacher, onSuccess, onCancel }: TeacherFormProps) => {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    employee_id: '',
    email: '',
    phone: '',
    gender: '',
    date_of_birth: '',
    address: '',
    emergency_contact: '',
    qualification: '',
    specialization: '',
    subjects: [] as string[],
    class_teacher_for: '',
    salary: '',
    hire_date: '',
    status: 'active',
    biography: '',
    profile_image_url: ''
  });
  const { toast } = useToast();

  useEffect(() => {
    if (teacher) {
      setFormData({
        name: teacher.name || '',
        employee_id: teacher.employee_id || '',
        email: teacher.email || '',
        phone: teacher.phone || '',
        gender: teacher.gender || '',
        date_of_birth: teacher.date_of_birth || '',
        address: teacher.address || '',
        emergency_contact: teacher.emergency_contact || '',
        qualification: teacher.qualification || '',
        specialization: teacher.specialization || '',
        subjects: teacher.subjects || [],
        class_teacher_for: teacher.class_teacher_for || '',
        salary: teacher.salary?.toString() || '',
        hire_date: teacher.hire_date || '',
        status: teacher.status || 'active',
        biography: teacher.biography || '',
        profile_image_url: teacher.profile_image_url || ''
      });
    }
  }, [teacher]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      toast({
        title: "Error",
        description: "Teacher name is required",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      const teacherData = {
        ...formData,
        salary: formData.salary ? parseFloat(formData.salary) : null,
        subjects: formData.subjects.length > 0 ? formData.subjects : null,
        updated_at: new Date().toISOString()
      };

      let result;
      if (teacher) {
        result = await supabase
          .from('teachers')
          .update(teacherData)
          .eq('id', teacher.id);
      } else {
        result = await supabase
          .from('teachers')
          .insert([teacherData]);
      }

      if (result.error) throw result.error;

      toast({
        title: "Success",
        description: `Teacher ${teacher ? 'updated' : 'created'} successfully`
      });
      onSuccess();
    } catch (error: any) {
      console.error('Error saving teacher:', error);
      toast({
        title: "Error",
        description: error.message || `Failed to ${teacher ? 'update' : 'create'} teacher`,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubjectChange = (value: string) => {
    const subjects = value.split(',').map(s => s.trim()).filter(s => s);
    setFormData({ ...formData, subjects });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">
          {teacher ? 'Edit Teacher' : 'Add New Teacher'}
        </h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Personal Information */}
        <Card>
          <CardHeader>
            <CardTitle>Personal Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <TeacherImageUpload
              teacherId={teacher?.id || ''}
              currentImage={formData.profile_image_url}
              teacherName={formData.name}
              onImageUpdate={(url) => setFormData({ ...formData, profile_image_url: url })}
            />
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Full Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="employee_id">Employee ID</Label>
                <Input
                  id="employee_id"
                  value={formData.employee_id}
                  onChange={(e) => setFormData({ ...formData, employee_id: e.target.value })}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="gender">Gender</Label>
                <Select value={formData.gender} onValueChange={(value) => setFormData({ ...formData, gender: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select gender" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Male">Male</SelectItem>
                    <SelectItem value="Female">Female</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="date_of_birth">Date of Birth</Label>
                <Input
                  id="date_of_birth"
                  type="date"
                  value={formData.date_of_birth}
                  onChange={(e) => setFormData({ ...formData, date_of_birth: e.target.value })}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="address">Address</Label>
              <Textarea
                id="address"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                rows={3}
              />
            </div>

            <div>
              <Label htmlFor="emergency_contact">Emergency Contact</Label>
              <Input
                id="emergency_contact"
                value={formData.emergency_contact}
                onChange={(e) => setFormData({ ...formData, emergency_contact: e.target.value })}
              />
            </div>
          </CardContent>
        </Card>

        {/* Contact & Professional */}
        <Card>
          <CardHeader>
            <CardTitle>Contact & Professional</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
            </div>

            <div>
              <Label htmlFor="phone">Phone</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              />
            </div>

            <div>
              <Label htmlFor="qualification">Qualification</Label>
              <Input
                id="qualification"
                value={formData.qualification}
                onChange={(e) => setFormData({ ...formData, qualification: e.target.value })}
              />
            </div>

            <div>
              <Label htmlFor="specialization">Specialization</Label>
              <Input
                id="specialization"
                value={formData.specialization}
                onChange={(e) => setFormData({ ...formData, specialization: e.target.value })}
              />
            </div>

            <div>
              <Label htmlFor="subjects">Subjects (comma-separated)</Label>
              <Input
                id="subjects"
                value={formData.subjects.join(', ')}
                onChange={(e) => handleSubjectChange(e.target.value)}
                placeholder="e.g., Mathematics, Science, English"
              />
            </div>

            <div>
              <Label htmlFor="class_teacher_for">Class Teacher For</Label>
              <Input
                id="class_teacher_for"
                value={formData.class_teacher_for}
                onChange={(e) => setFormData({ ...formData, class_teacher_for: e.target.value })}
              />
            </div>
          </CardContent>
        </Card>

        {/* Employment Details */}
        <Card>
          <CardHeader>
            <CardTitle>Employment Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="hire_date">Hire Date</Label>
              <Input
                id="hire_date"
                type="date"
                value={formData.hire_date}
                onChange={(e) => setFormData({ ...formData, hire_date: e.target.value })}
              />
            </div>

            <div>
              <Label htmlFor="salary">Monthly Salary (UGX)</Label>
              <Input
                id="salary"
                type="number"
                step="0.01"
                value={formData.salary}
                onChange={(e) => setFormData({ ...formData, salary: e.target.value })}
              />
            </div>

            <div>
              <Label htmlFor="status">Status</Label>
              <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="on leave">On Leave</SelectItem>
                  <SelectItem value="retired">Retired</SelectItem>
                  <SelectItem value="former">Former</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="biography">Biography</Label>
              <Textarea
                id="biography"
                value={formData.biography}
                onChange={(e) => setFormData({ ...formData, biography: e.target.value })}
                rows={4}
                placeholder="Brief biography about the teacher..."
              />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={loading}>
          {loading ? 'Saving...' : (teacher ? 'Update Teacher' : 'Add Teacher')}
        </Button>
      </div>
    </form>
  );
};

export default TeacherForm;
