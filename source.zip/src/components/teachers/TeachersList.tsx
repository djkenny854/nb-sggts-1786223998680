
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Search, Plus, Eye, Edit, MoreHorizontal, Users, GraduationCap, Phone, Mail } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import TeacherForm from './TeacherForm';
import TeacherDetailView from './TeacherDetailView';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface Teacher {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  subjects?: string[];
  class_teacher_for?: string;
  qualification?: string;
  specialization?: string;
  biography?: string;
  gender?: string;
  date_of_birth?: string;
  employee_id?: string;
  salary?: number;
  hire_date?: string;
  address?: string;
  emergency_contact?: string;
  profile_image_url?: string;
  status?: string;
  join_date?: string;
}

const TeachersList = () => {
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [filteredTeachers, setFilteredTeachers] = useState<Teacher[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTeacher, setSelectedTeacher] = useState<Teacher | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchTeachers();
  }, []);

  useEffect(() => {
    filterTeachers();
  }, [teachers, searchQuery]);

  const fetchTeachers = async () => {
    try {
      const { data, error } = await supabase
        .from('teachers')
        .select('*')
        .order('name');

      if (error) throw error;
      setTeachers(data || []);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching teachers:', error);
      toast({
        title: "Error",
        description: "Failed to fetch teachers",
        variant: "destructive"
      });
      setLoading(false);
    }
  };

  const filterTeachers = () => {
    if (!searchQuery) {
      setFilteredTeachers(teachers);
      return;
    }

    const filtered = teachers.filter(teacher =>
      teacher.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      teacher.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      teacher.employee_id?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      teacher.subjects?.some(subject => subject.toLowerCase().includes(searchQuery.toLowerCase())) ||
      teacher.class_teacher_for?.toLowerCase().includes(searchQuery.toLowerCase())
    );

    setFilteredTeachers(filtered);
  };

  const handleDelete = async (teacherId: string) => {
    if (!confirm('Are you sure you want to delete this teacher?')) return;

    try {
      const { error } = await supabase
        .from('teachers')
        .delete()
        .eq('id', teacherId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Teacher deleted successfully"
      });
      
      fetchTeachers();
    } catch (error: any) {
      console.error('Error deleting teacher:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to delete teacher",
        variant: "destructive"
      });
    }
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const formatSalary = (salary?: number) => {
    if (!salary) return null;
    return new Intl.NumberFormat('en-UG', {
      style: 'currency',
      currency: 'UGX',
      maximumFractionDigits: 0
    }).format(salary);
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-bold">Teachers</h2>
        </div>
        <div className="space-y-1">
          {[1, 2, 3, 4, 5].map(i => (
            <div key={i} className="h-16 bg-card/50 rounded animate-pulse border-b border-border"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header - X.com style */}
      <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-md border-b border-border pb-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-xl font-bold">Teachers</h1>
            <p className="text-sm text-muted-foreground">{teachers.length} staff members</p>
          </div>
          <Button 
            onClick={() => { setSelectedTeacher(null); setIsFormOpen(true); }}
            className="rounded-full"
            size="sm"
          >
            <Plus className="h-4 w-4 mr-1" />
            Add
          </Button>
        </div>

        {/* Search - X.com style */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            placeholder="Search teachers..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-secondary border-0 rounded-full focus-visible:ring-1 focus-visible:ring-primary"
          />
        </div>
      </div>

      {/* Teachers List - X.com style feed */}
      <div className="divide-y divide-border">
        {filteredTeachers.map((teacher) => (
          <div 
            key={teacher.id} 
            className="py-3 px-2 hover:bg-secondary/50 transition-colors cursor-pointer"
            onClick={() => {
              setSelectedTeacher(teacher);
              setIsDetailOpen(true);
            }}
          >
            <div className="flex gap-3">
              {/* Avatar */}
              <Avatar className="h-12 w-12 flex-shrink-0">
                <AvatarImage src={teacher.profile_image_url || ''} />
                <AvatarFallback className="bg-primary/10 text-primary text-sm font-medium">
                  {getInitials(teacher.name)}
                </AvatarFallback>
              </Avatar>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    {/* Name and ID */}
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-foreground truncate">{teacher.name}</span>
                      {teacher.status === 'active' && (
                        <span className="w-2 h-2 bg-green-500 rounded-full flex-shrink-0" />
                      )}
                    </div>
                    
                    {/* Meta info */}
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      {teacher.employee_id && <span>@{teacher.employee_id}</span>}
                      {teacher.qualification && (
                        <>
                          <span>·</span>
                          <span className="truncate">{teacher.qualification}</span>
                        </>
                      )}
                    </div>

                    {/* Subjects/Class */}
                    <div className="mt-1.5 flex flex-wrap gap-1.5">
                      {teacher.class_teacher_for && (
                        <Badge variant="secondary" className="text-xs rounded-full px-2 py-0.5">
                          <Users className="h-3 w-3 mr-1" />
                          {teacher.class_teacher_for}
                        </Badge>
                      )}
                      {teacher.subjects?.slice(0, 2).map((subject, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs rounded-full px-2 py-0.5">
                          {subject}
                        </Badge>
                      ))}
                      {teacher.subjects && teacher.subjects.length > 2 && (
                        <Badge variant="outline" className="text-xs rounded-full px-2 py-0.5">
                          +{teacher.subjects.length - 2}
                        </Badge>
                      )}
                    </div>

                    {/* Contact info */}
                    <div className="mt-2 flex items-center gap-4 text-xs text-muted-foreground">
                      {teacher.phone && (
                        <span className="flex items-center gap-1">
                          <Phone className="h-3 w-3" />
                          {teacher.phone}
                        </span>
                      )}
                      {teacher.salary && (
                        <span className="text-primary font-medium">
                          {formatSalary(teacher.salary)}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Actions */}
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                      <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full hover:bg-primary/10 hover:text-primary">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-48">
                      <DropdownMenuItem onClick={(e) => {
                        e.stopPropagation();
                        setSelectedTeacher(teacher);
                        setIsDetailOpen(true);
                      }}>
                        <Eye className="h-4 w-4 mr-2" />
                        View Profile
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={(e) => {
                        e.stopPropagation();
                        setSelectedTeacher(teacher);
                        setIsFormOpen(true);
                      }}>
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {filteredTeachers.length === 0 && (
        <div className="text-center py-12">
          <GraduationCap className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
          <h3 className="font-semibold text-foreground mb-1">No teachers found</h3>
          <p className="text-sm text-muted-foreground">
            {searchQuery ? 'Try a different search term' : 'Add your first teacher to get started'}
          </p>
        </div>
      )}

      {/* Add/Edit Teacher Dialog */}
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <TeacherForm
            teacher={selectedTeacher}
            onSuccess={() => {
              setIsFormOpen(false);
              setSelectedTeacher(null);
              fetchTeachers();
            }}
            onCancel={() => {
              setIsFormOpen(false);
              setSelectedTeacher(null);
            }}
          />
        </DialogContent>
      </Dialog>

      {/* View Teacher Details Dialog */}
      <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          {selectedTeacher && (
            <TeacherDetailView
              teacher={selectedTeacher}
              onEdit={() => {
                setIsDetailOpen(false);
                setIsFormOpen(true);
              }}
              onClose={() => {
                setIsDetailOpen(false);
                setSelectedTeacher(null);
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default TeachersList;
