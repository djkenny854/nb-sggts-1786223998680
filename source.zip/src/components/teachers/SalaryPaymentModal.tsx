
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface SalaryPaymentModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  teacherId: string;
  teacherName: string;
  baseSalary?: number;
  onSuccess: () => void;
}

const SalaryPaymentModal = ({ 
  open, 
  onOpenChange, 
  teacherId, 
  teacherName, 
  baseSalary = 0,
  onSuccess 
}: SalaryPaymentModalProps) => {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    amount: baseSalary.toString(),
    month: new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' }),
    method: 'Cash',
    notes: ''
  });
  const { toast } = useToast();

  const paymentMethods = [
    'Cash',
    'Mobile Money',
    'Bank Transfer',
    'Cheque',
    'Direct Deposit'
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.amount || !formData.month) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase
        .from('teacher_salaries')
        .insert({
          teacher_id: teacherId,
          amount: parseFloat(formData.amount),
          month: formData.month,
          method: formData.method,
          status: 'Paid',
          notes: formData.notes || null
        });

      if (error) throw error;

      onSuccess();
      onOpenChange(false);
      
      // Reset form
      setFormData({
        amount: baseSalary.toString(),
        month: new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' }),
        method: 'Cash',
        notes: ''
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to record salary payment",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Record Salary Payment</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label>Teacher</Label>
            <Input value={teacherName} readOnly className="bg-gray-50" />
          </div>
          
          <div>
            <Label htmlFor="amount">Amount (UGX) *</Label>
            <Input
              id="amount"
              type="number"
              step="0.01"
              value={formData.amount}
              onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
              required
            />
          </div>
          
          <div>
            <Label htmlFor="month">Month *</Label>
            <Input
              id="month"
              value={formData.month}
              onChange={(e) => setFormData({ ...formData, month: e.target.value })}
              placeholder="e.g., January 2025"
              required
            />
          </div>
          
          <div>
            <Label>Payment Method *</Label>
            <Select value={formData.method} onValueChange={(value) => setFormData({ ...formData, method: value })}>
              <SelectTrigger>
                <SelectValue placeholder="Select payment method" />
              </SelectTrigger>
              <SelectContent>
                {paymentMethods.map((method) => (
                  <SelectItem key={method} value={method}>
                    {method}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="notes">Notes (optional)</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              rows={3}
              placeholder="Additional notes about this payment..."
            />
          </div>
          
          <div className="flex justify-end space-x-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? 'Recording...' : 'Record Payment'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default SalaryPaymentModal;
