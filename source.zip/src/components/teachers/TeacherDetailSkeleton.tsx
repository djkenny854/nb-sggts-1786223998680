
import React from 'react';
import { Skeleton } from "@/components/ui/skeleton";
import MainLayout from '@/components/layout/MainLayout';

const TeacherDetailSkeleton = () => {
  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Skeleton className="h-6 w-6 rounded-full" />
          <Skeleton className="h-8 w-48" />
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <div className="space-y-6">
            <Skeleton className="h-64 rounded-lg" />
            
            <div className="space-y-4">
              <Skeleton className="h-8 w-40" />
              <div className="space-y-2">
                {[...Array(6)].map((_, i) => (
                  <Skeleton key={i} className="h-6 w-full" />
                ))}
              </div>
            </div>
          </div>
          
          <div className="space-y-6">
            <Skeleton className="h-8 w-40" />
            <div className="grid gap-4 grid-cols-1 md:grid-cols-2">
              {[...Array(4)].map((_, i) => (
                <Skeleton key={i} className="h-32 rounded-lg" />
              ))}
            </div>
            
            <Skeleton className="h-8 w-40 mt-6" />
            <div className="space-y-2">
              {[...Array(3)].map((_, i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default TeacherDetailSkeleton;
