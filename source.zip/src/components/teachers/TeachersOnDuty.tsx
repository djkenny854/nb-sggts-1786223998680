
import React, { useState } from 'react';
import { Calendar, Clock, User, UserCheck } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Teacher } from '@/types';

// Mock data for teachers on duty
const DUTY_SCHEDULE = [
  {
    day: 'Monday',
    teachers: [
      { id: 't1', name: 'Sarah Johnson', area: 'Main Entrance', time: '7:30 AM - 8:30 AM', profileImage: '' },
      { id: 't2', name: 'Robert Smith', area: 'Playground', time: '10:30 AM - 11:30 AM', profileImage: '' },
      { id: 't3', name: 'Emily Davis', area: 'Cafeteria', time: '12:00 PM - 1:00 PM', profileImage: '' }
    ]
  },
  {
    day: 'Tuesday',
    teachers: [
      { id: 't4', name: 'James Wilson', area: 'Main Entrance', time: '7:30 AM - 8:30 AM', profileImage: '' },
      { id: 't5', name: 'Michael Brown', area: 'Playground', time: '10:30 AM - 11:30 AM', profileImage: '' },
      { id: 't6', name: 'Lisa Garcia', area: 'Cafeteria', time: '12:00 PM - 1:00 PM', profileImage: '' }
    ]
  },
  {
    day: 'Wednesday',
    teachers: [
      { id: 't7', name: 'David Clark', area: 'Main Entrance', time: '7:30 AM - 8:30 AM', profileImage: '' },
      { id: 't1', name: 'Sarah Johnson', area: 'Playground', time: '10:30 AM - 11:30 AM', profileImage: '' },
      { id: 't8', name: 'Anna Miller', area: 'Cafeteria', time: '12:00 PM - 1:00 PM', profileImage: '' }
    ]
  },
  {
    day: 'Thursday',
    teachers: [
      { id: 't2', name: 'Robert Smith', area: 'Main Entrance', time: '7:30 AM - 8:30 AM', profileImage: '' },
      { id: 't4', name: 'James Wilson', area: 'Playground', time: '10:30 AM - 11:30 AM', profileImage: '' },
      { id: 't3', name: 'Emily Davis', area: 'Cafeteria', time: '12:00 PM - 1:00 PM', profileImage: '' }
    ]
  },
  {
    day: 'Friday',
    teachers: [
      { id: 't7', name: 'David Clark', area: 'Main Entrance', time: '7:30 AM - 8:30 AM', profileImage: '' },
      { id: 't6', name: 'Lisa Garcia', area: 'Playground', time: '10:30 AM - 11:30 AM', profileImage: '' },
      { id: 't5', name: 'Michael Brown', area: 'Cafeteria', time: '12:00 PM - 1:00 PM', profileImage: '' }
    ]
  }
];

interface DutyTeacher {
  id: string;
  name: string;
  area: string;
  time: string;
  profileImage: string;
}

interface TeachersOnDutyProps {
  teachers: Teacher[];
}

const TeachersOnDuty: React.FC<TeachersOnDutyProps> = ({ teachers }) => {
  const currentDay = new Date().toLocaleString('en-US', { weekday: 'long' });
  const [selectedDay, setSelectedDay] = useState<string>(currentDay);

  // Get current duty schedule based on selected day
  const currentDutySchedule = DUTY_SCHEDULE.find(schedule => 
    schedule.day.toLowerCase() === selectedDay.toLowerCase()
  ) || DUTY_SCHEDULE[0];

  // Get initials for avatar fallback
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-medium flex items-center gap-2">
            <UserCheck className="h-5 w-5" />
            Teachers on Duty
          </CardTitle>
          <Badge variant="outline" className="font-normal flex items-center gap-1">
            <Calendar className="h-3 w-3" />
            <span>{new Date().toLocaleDateString()}</span>
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue={currentDay.toLowerCase()} className="w-full">
          <TabsList className="grid grid-cols-5 mb-4">
            {DUTY_SCHEDULE.map(schedule => (
              <TabsTrigger 
                key={schedule.day} 
                value={schedule.day.toLowerCase()}
                onClick={() => setSelectedDay(schedule.day)}
                className={schedule.day === currentDay ? "border-primary" : ""}
              >
                {schedule.day.substring(0, 3)}
              </TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value={selectedDay.toLowerCase()} className="pt-2">
            <div className="space-y-4">
              {currentDutySchedule.teachers.map((teacher) => (
                <div key={teacher.id} className="flex justify-between items-center border-b pb-3 last:border-0 last:pb-0">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={teacher.profileImage} alt={teacher.name} />
                      <AvatarFallback>{getInitials(teacher.name)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{teacher.name}</p>
                      <p className="text-sm text-muted-foreground">{teacher.area}</p>
                    </div>
                  </div>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Clock className="h-3 w-3 mr-1" />
                    {teacher.time}
                  </div>
                </div>
              ))}
            </div>
            <Button variant="outline" size="sm" className="w-full mt-3">
              <User className="h-4 w-4 mr-1" />
              View All Teachers
            </Button>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default TeachersOnDuty;
