
import React, { useState, useEffect } from 'react';
import { Brain, TrendingUp, AlertTriangle, CheckCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { StudentFormValues } from './form-sections/StudentFormSchema';

interface StudentAIAnalysisProps {
  formData: Partial<StudentFormValues>;
}

interface StudentInsight {
  type: 'success' | 'warning' | 'info' | 'error';
  title: string;
  description: string;
  suggestion?: string;
}

const StudentAIAnalysis: React.FC<StudentAIAnalysisProps> = ({ formData }) => {
  const [insights, setInsights] = useState<StudentInsight[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  useEffect(() => {
    if (formData.name && formData.className) {
      analyzeStudent();
    }
  }, [formData]);

  const analyzeStudent = async () => {
    setIsAnalyzing(true);
    
    // Simulate AI analysis
    setTimeout(() => {
      const generatedInsights: StudentInsight[] = [];

      // Fee structure analysis
      if (formData.boardingStatus === 'Boarding') {
        generatedInsights.push({
          type: 'info',
          title: 'Boarding Student Detected',
          description: 'Additional boarding fees will apply',
          suggestion: 'Ensure boarding facilities and meal plans are arranged'
        });
      }

      if (formData.transportUse === 'Yes') {
        generatedInsights.push({
          type: 'info',
          title: 'Transport Required',
          description: 'Student will use school transport',
          suggestion: 'Verify transport route availability for student address'
        });
      }

      // Medical conditions check
      if (formData.medicalConditions && formData.medicalConditions.length > 0) {
        generatedInsights.push({
          type: 'warning',
          title: 'Medical Attention Required',
          description: 'Student has reported medical conditions',
          suggestion: 'Inform school nurse and prepare emergency protocols'
        });
      }

      // Emergency contact validation
      if (!formData.emergencyContact) {
        generatedInsights.push({
          type: 'error',
          title: 'Missing Emergency Contact',
          description: 'No emergency contact provided',
          suggestion: 'Emergency contact is required for student safety'
        });
      }

      // Blood group importance
      if (!formData.bloodGroup) {
        generatedInsights.push({
          type: 'warning',
          title: 'Blood Group Not Specified',
          description: 'Blood group information missing',
          suggestion: 'Consider collecting blood group for medical emergencies'
        });
      }

      // Positive insights
      if (formData.email) {
        generatedInsights.push({
          type: 'success',
          title: 'Digital Communication Ready',
          description: 'Student email provided for digital communications'
        });
      }

      if (formData.clubsActivities && formData.clubsActivities.length > 0) {
        generatedInsights.push({
          type: 'success',
          title: 'Extracurricular Interest',
          description: 'Student shows interest in clubs and activities',
          suggestion: 'Encourage participation in school activities'
        });
      }

      setInsights(generatedInsights);
      setIsAnalyzing(false);
    }, 2000);
  };

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'success': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
      case 'error': return <AlertTriangle className="w-4 h-4 text-red-600" />;
      default: return <TrendingUp className="w-4 h-4 text-blue-600" />;
    }
  };

  const getInsightBadgeVariant = (type: string) => {
    switch (type) {
      case 'success': return 'default';
      case 'warning': return 'secondary';
      case 'error': return 'destructive';
      default: return 'outline';
    }
  };

  if (!formData.name) {
    return null;
  }

  return (
    <Card className="mt-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="w-5 h-5 text-purple-600" />
          AI Student Analysis
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isAnalyzing ? (
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
            <span className="ml-3 text-muted-foreground">Analyzing student profile...</span>
          </div>
        ) : (
          <div className="space-y-3">
            {insights.length === 0 ? (
              <p className="text-muted-foreground text-center py-4">
                Fill in more details to get AI insights
              </p>
            ) : (
              insights.map((insight, index) => (
                <div key={index} className="flex items-start gap-3 p-3 rounded-lg border bg-muted/20">
                  {getInsightIcon(insight.type)}
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-medium text-sm">{insight.title}</h4>
                      <Badge variant={getInsightBadgeVariant(insight.type)} className="text-xs">
                        {insight.type}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-1">{insight.description}</p>
                    {insight.suggestion && (
                      <p className="text-xs text-blue-600 font-medium">💡 {insight.suggestion}</p>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default StudentAIAnalysis;
