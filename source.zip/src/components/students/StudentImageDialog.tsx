
import React from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download, Share } from "lucide-react";

interface StudentImageDialogProps {
  open: boolean;
  onOpenChange: (val: boolean) => void;
  imageUrl?: string | null;
  studentName: string;
}

const StudentImageDialog: React.FC<StudentImageDialogProps> = ({
  open,
  onOpenChange,
  imageUrl,
  studentName,
}) => {
  if (!imageUrl) return null;

  const handleDownload = () => {
    // Download the image by creating a temporary anchor
    const link = document.createElement("a");
    link.href = imageUrl;
    link.download = `${studentName || "student"}-profile.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${studentName} - Profile Image`,
          url: imageUrl,
        });
      } catch (e) {
        // Handle share canceled or failed
      }
    } else {
      await navigator.clipboard.writeText(imageUrl);
      alert("Image URL copied to clipboard!");
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md flex flex-col items-center gap-4">
        <img
          src={imageUrl}
          alt={studentName}
          className="max-h-[60vh] w-auto rounded-lg border object-contain"
          draggable={false}
        />
        <div className="flex gap-2 w-full justify-center">
          <Button
            variant="outline"
            className="flex items-center gap-2"
            onClick={handleDownload}
          >
            <Download className="h-4 w-4" />
            Download
          </Button>
          <Button
            variant="outline"
            className="flex items-center gap-2"
            onClick={handleShare}
          >
            <Share className="h-4 w-4" />
            Share
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default StudentImageDialog;
