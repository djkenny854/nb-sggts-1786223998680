import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { BookOpen, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { getStudentAssessmentSummary, getStudentGrades } from '@/utils/gradingService';
import { supabase } from '@/integrations/supabase/client';
import type { StudentAssessmentSummary, AssessmentGrade } from '@/types/grading';

const StudentGradebook = () => {
  const [students, setStudents] = useState<any[]>([]);
  const [selectedStudent, setSelectedStudent] = useState<string>('');
  const [summary, setSummary] = useState<StudentAssessmentSummary[]>([]);
  const [grades, setGrades] = useState<AssessmentGrade[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadStudents();
  }, []);

  useEffect(() => {
    if (selectedStudent) {
      loadStudentData();
    }
  }, [selectedStudent]);

  const loadStudents = async () => {
    try {
      const { data } = await supabase
        .from('students')
        .select('id, full_name, student_id, class')
        .order('full_name');
      
      setStudents(data || []);
    } catch (error) {
      console.error('Error loading students:', error);
    }
  };

  const loadStudentData = async () => {
    if (!selectedStudent) return;
    
    setLoading(true);
    try {
      // Load assessment summary
      const summaryData = await getStudentAssessmentSummary({
        student_id: selectedStudent,
        academic_year: '2024',
        academic_term: 'Term 1'
      });
      setSummary(summaryData);

      // Load detailed grades
      const gradesData = await getStudentGrades(selectedStudent, {
        academic_year: '2024',
        academic_term: 'Term 1'
      });
      setGrades(gradesData);
    } catch (error) {
      console.error('Error loading student data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getGradeColor = (grade: string) => {
    const colors = {
      A: 'bg-green-100 text-green-800',
      B: 'bg-blue-100 text-blue-800',
      C: 'bg-yellow-100 text-yellow-800',
      D: 'bg-orange-100 text-orange-800',
      F: 'bg-red-100 text-red-800'
    };
    return colors[grade as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const getTrendIcon = (percentage: number) => {
    if (percentage >= 75) return <TrendingUp className="h-4 w-4 text-green-600" />;
    if (percentage <= 50) return <TrendingDown className="h-4 w-4 text-red-600" />;
    return <Minus className="h-4 w-4 text-gray-600" />;
  };

  const selectedStudentData = students.find(s => s.id === selectedStudent);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Student Gradebook</h2>
        <p className="text-muted-foreground">View detailed academic performance for individual students</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Select Student</CardTitle>
        </CardHeader>
        <CardContent>
          <Select value={selectedStudent} onValueChange={setSelectedStudent}>
            <SelectTrigger>
              <SelectValue placeholder="Choose a student to view grades" />
            </SelectTrigger>
            <SelectContent>
              {students.map(student => (
                <SelectItem key={student.id} value={student.id}>
                  {student.full_name} ({student.student_id}) - {student.class}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {selectedStudent && selectedStudentData && (
        <>
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Student Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Name</label>
                  <p className="text-lg font-semibold">{selectedStudentData.full_name}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Student ID</label>
                  <p>{selectedStudentData.student_id}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Class</label>
                  <p>{selectedStudentData.class}</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Overall Performance</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {summary.length > 0 ? (
                  <>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Overall Average</label>
                      <p className="text-2xl font-bold">
                        {Math.round(summary.reduce((acc, s) => acc + s.average_percentage, 0) / summary.length)}%
                      </p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Subjects</label>
                      <p>{summary.length} subjects</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Total Assessments</label>
                      <p>{summary.reduce((acc, s) => acc + s.completed_assessments, 0)} completed</p>
                    </div>
                  </>
                ) : (
                  <p className="text-muted-foreground">No performance data available</p>
                )}
              </CardContent>
            </Card>
          </div>

          {loading ? (
            <Card>
              <CardContent className="p-8">
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="animate-pulse">
                      <div className="h-4 bg-muted rounded w-1/4 mb-2"></div>
                      <div className="h-8 bg-muted rounded"></div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ) : (
            <>
              <Card>
                <CardHeader>
                  <CardTitle>Subject Performance Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  {summary.length > 0 ? (
                    <div className="space-y-4">
                      {summary.map(subjectSummary => (
                        <div key={subjectSummary.id} className="border rounded-lg p-4">
                          <div className="flex justify-between items-center mb-3">
                            <div>
                              <h4 className="font-semibold">{subjectSummary.subject_name}</h4>
                              <p className="text-sm text-muted-foreground">
                                {subjectSummary.completed_assessments} / {subjectSummary.total_assessments} assessments completed
                              </p>
                            </div>
                            <div className="flex items-center gap-3">
                              {getTrendIcon(subjectSummary.average_percentage)}
                              <Badge className={getGradeColor(subjectSummary.current_grade || 'F')}>
                                {subjectSummary.current_grade || 'N/A'}
                              </Badge>
                              <span className="text-lg font-bold">
                                {Math.round(subjectSummary.average_percentage)}%
                              </span>
                            </div>
                          </div>
                          <Progress 
                            value={subjectSummary.average_percentage} 
                            className="h-2"
                          />
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">No subject performance data available</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Assessment Results</CardTitle>
                </CardHeader>
                <CardContent>
                  {grades.length > 0 ? (
                    <div className="space-y-3">
                      {grades.slice(0, 10).map(grade => (
                        <div key={grade.id} className="border rounded-lg p-4">
                          <div className="flex justify-between items-center">
                            <div>
                              <h4 className="font-medium">{grade.assessment_title}</h4>
                              <p className="text-sm text-muted-foreground">
                                {grade.subject_name} • {new Date(grade.graded_at || '').toLocaleDateString()}
                              </p>
                              {grade.teacher_comment && (
                                <p className="text-sm mt-1 italic text-muted-foreground">
                                  "{grade.teacher_comment}"
                                </p>
                              )}
                            </div>
                            <div className="text-right">
                              <div className="flex items-center gap-2 mb-1">
                                <Badge className={getGradeColor(grade.grade || 'F')}>
                                  {grade.grade || 'N/A'}
                                </Badge>
                                {grade.late_submission && (
                                  <Badge variant="outline">Late</Badge>
                                )}
                              </div>
                              <p className="text-lg font-bold">
                                {grade.is_absent ? 'Absent' : `${grade.marks_obtained}/${grade.total_marks}`}
                              </p>
                              <p className="text-sm text-muted-foreground">
                                {grade.is_absent ? '' : `${Math.round(grade.percentage)}%`}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">No assessment results available</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </>
          )}
        </>
      )}

      {!selectedStudent && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <BookOpen className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">Select a Student</h3>
            <p className="text-muted-foreground text-center max-w-sm">
              Choose a student from the dropdown above to view their detailed academic performance and grades.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default StudentGradebook;