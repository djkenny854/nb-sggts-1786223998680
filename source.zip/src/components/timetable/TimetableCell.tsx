
import React, { useState } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Clock, Edit, User, BookOpen, Radio } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import TimeEditor from './TimeEditor';

interface Subject {
  id: string;
  name: string;
  code: string;
}

interface Teacher {
  id: string;
  name: string;
}

interface TimetableEntry {
  id: string;
  class_name: string;
  day_of_week: number;
  period_number: number;
  subject_id: string | null;
  teacher_id: string | null;
  start_time: string;
  end_time: string;
  room?: string;
  subjects: Subject | null;
  teachers: Teacher | null;
}

interface TimetableCellProps {
  entry: TimetableEntry | null;
  dayIndex: number;
  period: number;
  subjects: Subject[];
  teachers: Teacher[];
  onSubjectChange: (dayIndex: number, period: number, subjectId: string | null) => void;
  onTeacherChange: (dayIndex: number, period: number, teacherId: string | null) => void;
  onTimeEdit: (dayIndex: number, period: number, startTime: string, endTime: string) => void;
  isLive?: boolean;
}

const TimetableCell: React.FC<TimetableCellProps> = ({
  entry,
  dayIndex,
  period,
  subjects,
  teachers,
  onSubjectChange,
  onTeacherChange,
  onTimeEdit,
  isLive = false
}) => {
  const [editingSubject, setEditingSubject] = useState(false);
  const [editingTeacher, setEditingTeacher] = useState(false);
  const [editingTime, setEditingTime] = useState(false);

  const handleSubjectChange = (value: string) => {
    onSubjectChange(dayIndex, period, value === "null" ? null : value);
    setEditingSubject(false);
  };

  const handleTeacherChange = (value: string) => {
    onTeacherChange(dayIndex, period, value === "null" ? null : value);
    setEditingTeacher(false);
  };

  const handleTimeEdit = (startTime: string, endTime: string) => {
    onTimeEdit(dayIndex, period, startTime, endTime);
    setEditingTime(false);
  };

  return (
    <div className={`
      relative h-24 border border-border rounded-lg p-2 bg-card transition-all duration-300 hover:shadow-md group cursor-pointer
      ${isLive ? 'ring-2 ring-red-500 bg-red-50 dark:bg-red-950/20 animate-pulse shadow-lg' : ''}
    `}>
      {isLive && (
        <Badge className="absolute -top-2 -right-2 bg-red-500 animate-bounce">
          <Radio className="h-3 w-3 mr-1" />
          LIVE
        </Badge>
      )}

      {/* Time Slot */}
      <div className="flex items-center justify-between mb-1">
        {editingTime ? (
          <TimeEditor
            startTime={entry?.start_time || '08:00'}
            endTime={entry?.end_time || '09:00'}
            onSave={handleTimeEdit}
            onCancel={() => setEditingTime(false)}
          />
        ) : (
          <>
            <span className="text-xs text-muted-foreground flex items-center">
              <Clock className="h-3 w-3 mr-1" />
              {entry?.start_time || '--:--'} - {entry?.end_time || '--:--'}
            </span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setEditingTime(true)}
              className="h-4 w-4 p-0 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-accent"
            >
              <Edit className="h-3 w-3" />
            </Button>
          </>
        )}
      </div>

      {/* Subject */}
      <div className="mb-1">
        {editingSubject ? (
          <Select onValueChange={handleSubjectChange} defaultValue={entry?.subject_id || "null"}>
            <SelectTrigger className="h-6 text-xs">
              <SelectValue placeholder="Select Subject" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="null">Clear Subject</SelectItem>
              {subjects.map(subject => (
                <SelectItem key={subject.id} value={subject.id}>{subject.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        ) : (
          <button
            className="w-full text-left text-xs hover:bg-accent hover:text-accent-foreground p-1 rounded flex items-center transition-colors"
            onClick={() => setEditingSubject(true)}
          >
            <BookOpen className="h-3 w-3 mr-1" />
            <span className="truncate">{entry?.subjects?.name || 'Add Subject'}</span>
          </button>
        )}
      </div>

      {/* Teacher */}
      <div>
        {editingTeacher ? (
          <Select onValueChange={handleTeacherChange} defaultValue={entry?.teacher_id || "null"}>
            <SelectTrigger className="h-6 text-xs">
              <SelectValue placeholder="Select Teacher" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="null">Clear Teacher</SelectItem>
              {teachers.map(teacher => (
                <SelectItem key={teacher.id} value={teacher.id}>{teacher.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        ) : (
          <button
            className="w-full text-left text-xs hover:bg-accent hover:text-accent-foreground p-1 rounded flex items-center transition-colors"
            onClick={() => setEditingTeacher(true)}
          >
            <User className="h-3 w-3 mr-1" />
            <span className="truncate">{entry?.teachers?.name || 'Assign Teacher'}</span>
          </button>
        )}
      </div>
    </div>
  );
};

export default TimetableCell;
