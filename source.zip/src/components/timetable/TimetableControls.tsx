
import React from 'react';
import { Button } from '@/components/ui/button';
import { Edit, Save, X } from 'lucide-react';

interface TimetableControlsProps {
  isEditMode: boolean;
  setIsEditMode: (editMode: boolean) => void;
  selectedClass: string;
}

const TimetableControls = ({ isEditMode, setIsEditMode, selectedClass }: TimetableControlsProps) => {
  const handleSave = () => {
    if (window && (window as any).saveTimetable) {
      (window as any).saveTimetable();
    }
    setIsEditMode(false);
  };

  const handleCancel = () => {
    setIsEditMode(false);
    // Optionally reload the page to reset any unsaved changes
    window.location.reload();
  };

  return (
    <div className="flex gap-2">
      {!isEditMode ? (
        <Button 
          onClick={() => setIsEditMode(true)}
          variant="outline"
        >
          <Edit className="h-4 w-4 mr-2" />
          Edit Timetable
        </Button>
      ) : (
        <>
          <Button 
            onClick={handleSave}
            variant="default"
          >
            <Save className="h-4 w-4 mr-2" />
            Save Changes
          </Button>
          <Button 
            onClick={handleCancel}
            variant="outline"
          >
            <X className="h-4 w-4 mr-2" />
            Cancel
          </Button>
        </>
      )}
    </div>
  );
};

export default TimetableControls;
