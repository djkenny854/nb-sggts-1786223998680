
import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Badge } from '@/components/ui/badge';
import { Radio, Clock, Users } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface LiveLesson {
  id: string;
  class_name: string;
  subject_name: string;
  teacher_name: string;
  start_time: string;
  end_time: string;
  student_count: number;
}

const LiveLessonsIndicator: React.FC = () => {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 30000); // Update every 30 seconds

    return () => clearInterval(timer);
  }, []);

  const { data: liveLessons = [], isLoading } = useQuery({
    queryKey: ['live-lessons'],
    queryFn: async (): Promise<LiveLesson[]> => {
      const now = new Date();
      const dayOfWeek = now.getDay();
      const currentTime = now.toTimeString().slice(0, 5); // HH:MM format

      const { data, error } = await supabase
        .from('timetable')
        .select(`
          id,
          class_name,
          start_time,
          end_time,
          subjects(name),
          teachers(name)
        `)
        .eq('day_of_week', dayOfWeek)
        .lte('start_time', currentTime)
        .gte('end_time', currentTime);

      if (error) throw error;

      return (data || []).map(item => ({
        id: item.id,
        class_name: item.class_name,
        subject_name: item.subjects?.name || 'Unknown Subject',
        teacher_name: item.teachers?.name || 'Unknown Teacher',
        start_time: item.start_time,
        end_time: item.end_time,
        student_count: Math.floor(Math.random() * 30) + 15 // Mock student count
      }));
    },
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  if (isLoading) {
    return (
      <div className="flex items-center space-x-2 animate-pulse">
        <div className="h-6 w-6 bg-muted rounded-full"></div>
        <div className="h-4 w-24 bg-muted rounded"></div>
      </div>
    );
  }

  if (liveLessons.length === 0) {
    return (
      <Badge variant="outline" className="animate-fade-in">
        <Clock className="h-3 w-3 mr-1" />
        No live lessons
      </Badge>
    );
  }

  return (
    <div className="flex flex-wrap gap-2 animate-fade-in">
      {liveLessons.map((lesson) => (
        <Badge
          key={lesson.id}
          className="bg-red-500 hover:bg-red-600 text-white animate-pulse"
        >
          <Radio className="h-3 w-3 mr-1" />
          {lesson.class_name} - {lesson.subject_name}
          <Users className="h-3 w-3 ml-1" />
          {lesson.student_count}
        </Badge>
      ))}
    </div>
  );
};

export default LiveLessonsIndicator;
