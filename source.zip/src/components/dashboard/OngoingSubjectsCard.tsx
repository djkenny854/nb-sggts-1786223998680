import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Clock, User, MapPin, Calendar, Radio, Users } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { Skeleton } from '@/components/ui/skeleton';

interface TimetableEntry {
  id: string;
  class_name: string;
  day_of_week: number;
  period_number: number;
  start_time: string;
  end_time: string;
  room?: string;
  subjects: {
    name: string;
    code: string;
  } | null;
  teachers: {
    name: string;
  } | null;
}

const OngoingSubjectsCard = () => {
  const [currentSubjects, setCurrentSubjects] = useState<TimetableEntry[]>([]);
  const [upcomingSubjects, setUpcomingSubjects] = useState<TimetableEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTodaysTimetable();
    const interval = setInterval(fetchTodaysTimetable, 30000); // Update every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const fetchTodaysTimetable = async () => {
    try {
      const now = new Date();
      const dayOfWeek = now.getDay(); // 0=Sunday, 1=Monday, etc.
      const currentTime = now.toTimeString().slice(0, 5); // HH:MM format

      const { data, error } = await supabase
        .from('timetable')
        .select(`
          *,
          subjects(name, code),
          teachers(name)
        `)
        .eq('day_of_week', dayOfWeek)
        .order('start_time');

      if (error) throw error;

      const timetableEntries: TimetableEntry[] = (data || []).map(entry => ({
        id: entry.id,
        class_name: entry.class_name,
        day_of_week: entry.day_of_week,
        period_number: entry.period_number,
        start_time: entry.start_time,
        end_time: entry.end_time,
        room: entry.room,
        subjects: entry.subjects,
        teachers: entry.teachers
      }));
      
      // Find current ongoing subjects
      const ongoing = timetableEntries.filter(entry => 
        entry.start_time <= currentTime && entry.end_time > currentTime
      );

      // Find upcoming subjects for today
      const upcoming = timetableEntries.filter(entry => 
        entry.start_time > currentTime
      ).slice(0, 3);

      setCurrentSubjects(ongoing);
      setUpcomingSubjects(upcoming);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching timetable:', error);
      setLoading(false);
    }
  };

  const formatTime = (time: string) => {
    return new Date(`2000-01-01T${time}`).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  const getDayName = () => {
    return new Date().toLocaleDateString('en-US', { weekday: 'long' });
  };

  // Mock student count for demo purposes
  const getStudentCount = () => Math.floor(Math.random() * 30) + 15;

  if (loading) {
    return (
      <Card className="animate-fade-in">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Radio className="h-5 w-5" />
            Live Lessons
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="animate-fade-in">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Radio className="h-5 w-5 text-destructive" />
          Live Lessons - {getDayName()}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {currentSubjects.length > 0 ? (
          <div className="space-y-3">
            {currentSubjects.map((subject) => (
              <div key={subject.id} className="p-4 bg-green-500/10 dark:bg-green-500/20 border border-green-500/30 rounded-lg animate-pulse">
                <div className="flex items-center justify-between mb-2">
                  <Badge className="bg-destructive hover:bg-destructive/90 text-destructive-foreground animate-bounce">
                    <Radio className="h-3 w-3 mr-1" />
                    LIVE NOW
                  </Badge>
                  <span className="text-sm text-green-700 dark:text-green-400 font-medium flex items-center">
                    <Clock className="h-3 w-3 mr-1" />
                    {formatTime(subject.start_time)} - {formatTime(subject.end_time)}
                  </span>
                </div>
                <h3 className="font-semibold text-lg text-green-800 dark:text-green-300 mb-2">
                  {subject.subjects?.name || 'Unknown Subject'}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm text-green-700 dark:text-green-400">
                  <div className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" />
                    {subject.class_name}
                  </div>
                  <div className="flex items-center gap-1">
                    <User className="h-4 w-4" />
                    {subject.teachers?.name || 'Unknown Teacher'}
                  </div>
                  <div className="flex items-center gap-1">
                    <Users className="h-4 w-4" />
                    {getStudentCount()} students
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-4 bg-muted/50 border border-border rounded-lg text-center">
            <Clock className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
            <p className="text-muted-foreground">
              No live lessons at the moment.
            </p>
            <p className="text-sm text-muted-foreground mt-1">
              Check back during school hours.
            </p>
          </div>
        )}

        {upcomingSubjects.length > 0 && (
          <div className="animate-fade-in">
            <h4 className="font-medium text-foreground mb-3 flex items-center">
              <Clock className="h-4 w-4 mr-2" />
              Coming Up Today
            </h4>
            <div className="space-y-2">
              {upcomingSubjects.map((subject, index) => (
                <div key={subject.id} className={`flex items-center justify-between p-3 bg-card border border-border rounded-lg transition-all duration-300 hover:shadow-md animate-fade-in`} style={{ animationDelay: `${index * 100}ms` }}>
                  <div>
                    <p className="font-medium text-card-foreground">{subject.subjects?.name || 'Unknown Subject'}</p>
                    <p className="text-sm text-muted-foreground">
                      {subject.class_name} • {subject.teachers?.name || 'Unknown Teacher'}
                    </p>
                  </div>
                  <Badge variant="outline" className="text-primary border-primary">
                    {formatTime(subject.start_time)}
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        )}

        {currentSubjects.length === 0 && upcomingSubjects.length === 0 && (
          <div className="text-center text-muted-foreground py-8">
            <Calendar className="h-12 w-12 mx-auto mb-4 text-muted-foreground/50" />
            <p className="text-lg font-medium">No more classes scheduled for today.</p>
            <p className="text-sm mt-1">Enjoy your break!</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default OngoingSubjectsCard;
