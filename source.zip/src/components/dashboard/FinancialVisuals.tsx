import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { DollarSign, TrendingUp, Users, Calendar } from 'lucide-react';

interface FinancialVisualsProps {
  stats: {
    todayPayments: {
      studentsCount: number;
      totalAmount: number;
      transactions: number;
    };
    monthlyPayments: {
      studentsCount: number;
      totalAmount: number;
      transactions: number;
    };
    feeStatus: {
      paid: number;
      partial: number;
      unpaid: number;
    };
    weeklyTrend: Array<{
      day: string;
      amount: number;
      students: number;
    }>;
  };
}

const FinancialVisuals: React.FC<FinancialVisualsProps> = ({ stats }) => {
  if (!stats) {
    return (
      <div className="space-y-6">
        <Card>
          <CardContent className="p-6">
            <div className="text-center text-muted-foreground">Loading financial data...</div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const {
    todayPayments = { studentsCount: 0, totalAmount: 0, transactions: 0 },
    monthlyPayments = { studentsCount: 0, totalAmount: 0, transactions: 0 },
    feeStatus = { paid: 0, partial: 0, unpaid: 0 },
    weeklyTrend = []
  } = stats;

  const formatCurrency = (amount: number) => `UGX ${amount.toLocaleString()}`;
  
  const feeStatusData = [
    { name: 'Paid', value: feeStatus.paid, color: 'hsl(var(--chart-2))' },
    { name: 'Partial', value: feeStatus.partial, color: 'hsl(var(--chart-1))' },
    { name: 'Unpaid', value: feeStatus.unpaid, color: 'hsl(var(--destructive))' }
  ];

  const totalStudents = feeStatus.paid + feeStatus.partial + feeStatus.unpaid;

  return (
    <div className="space-y-6">
      {/* Today's Payment Summary */}
      <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Students Paid Today</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{todayPayments.studentsCount}</div>
            <p className="text-xs text-muted-foreground">
              {todayPayments.transactions} transactions
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Today's Collection</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold truncate">{formatCurrency(todayPayments.totalAmount)}</div>
            <p className="text-xs text-muted-foreground truncate">
              Avg: {formatCurrency(todayPayments.studentsCount > 0 ? todayPayments.totalAmount / todayPayments.studentsCount : 0)}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Collection</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold truncate">{formatCurrency(monthlyPayments.totalAmount)}</div>
            <p className="text-xs text-muted-foreground">
              {monthlyPayments.studentsCount} students paid
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Payment Rate</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {totalStudents > 0 ? (feeStatus.paid / totalStudents * 100).toFixed(1) : 0}%
            </div>
            <p className="text-xs text-muted-foreground">
              Fully paid students
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Fee Status Pie Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Fee Payment Status</CardTitle>
            <CardDescription>Distribution of student payment status</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[250px] md:h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={feeStatusData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value, percent }) => `${name}: ${value}`}
                    outerRadius="70%"
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {feeStatusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                      color: 'hsl(var(--foreground))'
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Weekly Trend Bar Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Weekly Payment Trend</CardTitle>
            <CardDescription>Daily collection amounts this week</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[250px] md:h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={weeklyTrend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="day" 
                    tick={{ fill: 'hsl(var(--muted-foreground))' }}
                    axisLine={{ stroke: 'hsl(var(--border))' }}
                  />
                  <YAxis 
                    tick={{ fill: 'hsl(var(--muted-foreground))' }}
                    axisLine={{ stroke: 'hsl(var(--border))' }}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                      color: 'hsl(var(--foreground))'
                    }}
                    formatter={(value, name) => [
                      name === 'amount' ? formatCurrency(Number(value)) : value,
                      name === 'amount' ? 'Amount' : 'Students'
                    ]} 
                  />
                  <Legend wrapperStyle={{ color: 'hsl(var(--foreground))' }} />
                  <Bar dataKey="amount" fill="hsl(var(--chart-1))" name="Amount (UGX)" />
                  <Bar dataKey="students" fill="hsl(var(--chart-2))" name="Students" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default FinancialVisuals;
