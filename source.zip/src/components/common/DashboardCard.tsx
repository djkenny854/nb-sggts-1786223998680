import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface DashboardCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  description?: string;
  trend?: {
    value: number;
    isPositive: boolean;
  } | 'up' | 'down' | 'neutral';
  className?: string;
}

const DashboardCard: React.FC<DashboardCardProps> = ({
  title,
  value,
  icon,
  description,
  trend,
  className
}) => {
  let trendDisplay: { value: number; isPositive: boolean } | null = null;
  
  if (trend) {
    if (typeof trend === 'object') {
      trendDisplay = trend;
    } else {
      switch(trend) {
        case 'up':
          trendDisplay = { value: 5, isPositive: true };
          break;
        case 'down':
          trendDisplay = { value: 5, isPositive: false };
          break;
        case 'neutral':
          trendDisplay = null;
          break;
      }
    }
  }

  return (
    <Card className={cn("hover:bg-accent/50 transition-colors", className)}>
      <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0 p-4">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center text-foreground">
          {icon}
        </div>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <div className="text-2xl font-bold text-foreground">
          {value}
        </div>
        {description && (
          <p className="text-xs text-muted-foreground mt-1">
            {description}
          </p>
        )}
        {trendDisplay && (
          <div className="flex items-center gap-1 mt-2">
            <span className={cn(
              "text-xs font-medium",
              trendDisplay.isPositive ? "text-primary" : "text-destructive"
            )}>
              {trendDisplay.isPositive ? '↑' : '↓'} {Math.abs(trendDisplay.value)}%
            </span>
            <span className="text-xs text-muted-foreground">
              vs last month
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default DashboardCard;
