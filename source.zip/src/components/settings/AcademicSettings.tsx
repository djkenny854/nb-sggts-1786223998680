
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import ClassConfigCard from './academic/ClassConfigCard';
import SubjectSettingsCard from './academic/SubjectSettingsCard';
import GradingSystemCard from './academic/GradingSystemCard';

const AcademicSettings = () => {
  const [gradingSystem, setGradingSystem] = useState('percentage');
  const [passMark, setPassMark] = useState('50');
  const { toast } = useToast();

  const handleSaveSettings = () => {
    toast({
      title: "Settings saved",
      description: "Academic settings have been updated successfully."
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Academic Settings</h2>
        <p className="text-muted-foreground">Configure classes, subjects, and grading systems.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <ClassConfigCard />
        <SubjectSettingsCard />
        <GradingSystemCard 
          gradingSystem={gradingSystem}
          setGradingSystem={setGradingSystem}
          passMark={passMark}
          setPassMark={setPassMark}
        />
      </div>

      <div className="flex justify-end pt-4">
        <Button onClick={handleSaveSettings}>Save All Settings</Button>
      </div>
    </div>
  );
};

export default AcademicSettings;
