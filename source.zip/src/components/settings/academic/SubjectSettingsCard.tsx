
import React from 'react';
import { BookOpen } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';

const SubjectSettingsCard = () => {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <BookOpen className="mr-2 h-5 w-5" />
          Subject Settings
        </CardTitle>
        <CardDescription>Configure subjects and categories</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <label className="text-sm font-medium">Subject Categories</label>
          <Select defaultValue="standard">
            <SelectTrigger>
              <SelectValue placeholder="Select categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="standard">Standard Categories</SelectItem>
              <SelectItem value="custom">Custom Categories</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium">Allow Subject Aliases</label>
            <Switch defaultChecked />
          </div>
          <p className="text-xs text-muted-foreground">
            Enables alternative names for subjects (e.g., "Maths" vs "Mathematics")
          </p>
        </div>
        
        <Button variant="outline" className="w-full">
          Manage Subject List
        </Button>
      </CardContent>
    </Card>
  );
};

export default SubjectSettingsCard;
