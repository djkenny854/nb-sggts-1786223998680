export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.3 (519615d)"
  }
  public: {
    Tables: {
      assessment_categories: {
        Row: {
          created_at: string | null
          description: string | null
          id: string
          is_active: boolean | null
          name: string
          updated_at: string | null
          weight: number | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          name: string
          updated_at?: string | null
          weight?: number | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          name?: string
          updated_at?: string | null
          weight?: number | null
        }
        Relationships: []
      }
      assessment_grades: {
        Row: {
          assessment_id: string
          created_at: string | null
          grade: string | null
          graded_at: string | null
          graded_by: string | null
          id: string
          is_absent: boolean | null
          late_submission: boolean | null
          marks_obtained: number
          percentage: number
          student_id: string
          submitted_at: string | null
          teacher_comment: string | null
          total_marks: number
          updated_at: string | null
        }
        Insert: {
          assessment_id: string
          created_at?: string | null
          grade?: string | null
          graded_at?: string | null
          graded_by?: string | null
          id?: string
          is_absent?: boolean | null
          late_submission?: boolean | null
          marks_obtained?: number
          percentage?: number
          student_id: string
          submitted_at?: string | null
          teacher_comment?: string | null
          total_marks: number
          updated_at?: string | null
        }
        Update: {
          assessment_id?: string
          created_at?: string | null
          grade?: string | null
          graded_at?: string | null
          graded_by?: string | null
          id?: string
          is_absent?: boolean | null
          late_submission?: boolean | null
          marks_obtained?: number
          percentage?: number
          student_id?: string
          submitted_at?: string | null
          teacher_comment?: string | null
          total_marks?: number
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "assessment_grades_assessment_id_fkey"
            columns: ["assessment_id"]
            isOneToOne: false
            referencedRelation: "assessments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "assessment_grades_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      assessments: {
        Row: {
          academic_term: string
          academic_year: string
          assessment_date: string
          assessment_type: Database["public"]["Enums"]["assessment_type"]
          category_id: string | null
          class_name: string
          created_at: string | null
          created_by: string | null
          description: string | null
          due_date: string | null
          id: string
          instructions: string | null
          is_published: boolean | null
          subject_id: string | null
          title: string
          total_marks: number
          updated_at: string | null
        }
        Insert: {
          academic_term: string
          academic_year: string
          assessment_date: string
          assessment_type: Database["public"]["Enums"]["assessment_type"]
          category_id?: string | null
          class_name: string
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          due_date?: string | null
          id?: string
          instructions?: string | null
          is_published?: boolean | null
          subject_id?: string | null
          title: string
          total_marks?: number
          updated_at?: string | null
        }
        Update: {
          academic_term?: string
          academic_year?: string
          assessment_date?: string
          assessment_type?: Database["public"]["Enums"]["assessment_type"]
          category_id?: string | null
          class_name?: string
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          due_date?: string | null
          id?: string
          instructions?: string | null
          is_published?: boolean | null
          subject_id?: string | null
          title?: string
          total_marks?: number
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "assessments_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "assessment_categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "assessments_subject_id_fkey"
            columns: ["subject_id"]
            isOneToOne: false
            referencedRelation: "enhanced_subjects"
            referencedColumns: ["id"]
          },
        ]
      }
      attendance: {
        Row: {
          created_at: string | null
          created_by: string | null
          date: string
          id: string
          notes: string | null
          status: string
          student_id: string
          updated_at: string | null
          updated_by: string | null
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          date: string
          id?: string
          notes?: string | null
          status: string
          student_id: string
          updated_at?: string | null
          updated_by?: string | null
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          date?: string
          id?: string
          notes?: string | null
          status?: string
          student_id?: string
          updated_at?: string | null
          updated_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "attendance_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      attendance_policies: {
        Row: {
          absent_threshold_minutes: number | null
          auto_mark_absent: boolean | null
          created_at: string | null
          id: string
          late_threshold_minutes: number | null
          notification_settings: Json | null
          policy_type:
            | Database["public"]["Enums"]["attendance_policy_type"]
            | null
          require_reason: boolean | null
          updated_at: string | null
        }
        Insert: {
          absent_threshold_minutes?: number | null
          auto_mark_absent?: boolean | null
          created_at?: string | null
          id?: string
          late_threshold_minutes?: number | null
          notification_settings?: Json | null
          policy_type?:
            | Database["public"]["Enums"]["attendance_policy_type"]
            | null
          require_reason?: boolean | null
          updated_at?: string | null
        }
        Update: {
          absent_threshold_minutes?: number | null
          auto_mark_absent?: boolean | null
          created_at?: string | null
          id?: string
          late_threshold_minutes?: number | null
          notification_settings?: Json | null
          policy_type?:
            | Database["public"]["Enums"]["attendance_policy_type"]
            | null
          require_reason?: boolean | null
          updated_at?: string | null
        }
        Relationships: []
      }
      attendance_records: {
        Row: {
          created_at: string | null
          created_by: string | null
          date: string
          id: string
          notes: string | null
          status: string
          student_id: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          date: string
          id?: string
          notes?: string | null
          status: string
          student_id: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          date?: string
          id?: string
          notes?: string | null
          status?: string
          student_id?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "attendance_records_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      boarding_facilities: {
        Row: {
          capacity: number | null
          created_at: string | null
          facility_name: string
          facility_type: string | null
          fee_amount: number | null
          id: string
          rules: Json | null
          supervisor_name: string | null
          supervisor_phone: string | null
          updated_at: string | null
        }
        Insert: {
          capacity?: number | null
          created_at?: string | null
          facility_name: string
          facility_type?: string | null
          fee_amount?: number | null
          id?: string
          rules?: Json | null
          supervisor_name?: string | null
          supervisor_phone?: string | null
          updated_at?: string | null
        }
        Update: {
          capacity?: number | null
          created_at?: string | null
          facility_name?: string
          facility_type?: string | null
          fee_amount?: number | null
          id?: string
          rules?: Json | null
          supervisor_name?: string | null
          supervisor_phone?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      class_fee_mappings: {
        Row: {
          class_name: string
          created_at: string | null
          id: string
          structure_group: string
          updated_at: string | null
        }
        Insert: {
          class_name: string
          created_at?: string | null
          id?: string
          structure_group: string
          updated_at?: string | null
        }
        Update: {
          class_name?: string
          created_at?: string | null
          id?: string
          structure_group?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      class_rules: {
        Row: {
          class_name: string
          created_at: string
          description: string
          id: string
          is_mandatory: boolean | null
          rule_type: string
          title: string
          updated_at: string
        }
        Insert: {
          class_name: string
          created_at?: string
          description: string
          id?: string
          is_mandatory?: boolean | null
          rule_type: string
          title: string
          updated_at?: string
        }
        Update: {
          class_name?: string
          created_at?: string
          description?: string
          id?: string
          is_mandatory?: boolean | null
          rule_type?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      class_streams: {
        Row: {
          class_level: string
          class_teacher_id: string | null
          created_at: string | null
          full_name: string
          id: string
          stream_name: string
          updated_at: string | null
        }
        Insert: {
          class_level: string
          class_teacher_id?: string | null
          created_at?: string | null
          full_name: string
          id?: string
          stream_name: string
          updated_at?: string | null
        }
        Update: {
          class_level?: string
          class_teacher_id?: string | null
          created_at?: string | null
          full_name?: string
          id?: string
          stream_name?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "class_streams_class_teacher_id_fkey"
            columns: ["class_teacher_id"]
            isOneToOne: false
            referencedRelation: "teachers"
            referencedColumns: ["id"]
          },
        ]
      }
      class_teachers: {
        Row: {
          class_name: string
          created_at: string
          id: string
          notes: string | null
          role: string
          subjects: string[] | null
          teacher_id: string
          updated_at: string
        }
        Insert: {
          class_name: string
          created_at?: string
          id?: string
          notes?: string | null
          role: string
          subjects?: string[] | null
          teacher_id: string
          updated_at?: string
        }
        Update: {
          class_name?: string
          created_at?: string
          id?: string
          notes?: string | null
          role?: string
          subjects?: string[] | null
          teacher_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      communication_preferences: {
        Row: {
          created_at: string | null
          email_config: Json | null
          email_provider: string | null
          id: string
          notification_categories: Json | null
          notification_frequency: string | null
          sms_config: Json | null
          sms_provider: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          email_config?: Json | null
          email_provider?: string | null
          id?: string
          notification_categories?: Json | null
          notification_frequency?: string | null
          sms_config?: Json | null
          sms_provider?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          email_config?: Json | null
          email_provider?: string | null
          id?: string
          notification_categories?: Json | null
          notification_frequency?: string | null
          sms_config?: Json | null
          sms_provider?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      communication_settings: {
        Row: {
          configuration: Json
          created_at: string
          id: string
          is_active: boolean | null
          provider_name: string | null
          setting_type: string
          updated_at: string
        }
        Insert: {
          configuration?: Json
          created_at?: string
          id?: string
          is_active?: boolean | null
          provider_name?: string | null
          setting_type: string
          updated_at?: string
        }
        Update: {
          configuration?: Json
          created_at?: string
          id?: string
          is_active?: boolean | null
          provider_name?: string | null
          setting_type?: string
          updated_at?: string
        }
        Relationships: []
      }
      contact_groups: {
        Row: {
          created_at: string
          criteria: Json | null
          description: string | null
          group_type: string
          id: string
          is_dynamic: boolean | null
          member_ids: string[] | null
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          criteria?: Json | null
          description?: string | null
          group_type: string
          id?: string
          is_dynamic?: boolean | null
          member_ids?: string[] | null
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          criteria?: Json | null
          description?: string | null
          group_type?: string
          id?: string
          is_dynamic?: boolean | null
          member_ids?: string[] | null
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      customization_themes: {
        Row: {
          created_at: string | null
          custom_css: string | null
          id: string
          is_active: boolean | null
          logo_url: string | null
          primary_color: string | null
          secondary_color: string | null
          theme_name: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          custom_css?: string | null
          id?: string
          is_active?: boolean | null
          logo_url?: string | null
          primary_color?: string | null
          secondary_color?: string | null
          theme_name: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          custom_css?: string | null
          id?: string
          is_active?: boolean | null
          logo_url?: string | null
          primary_color?: string | null
          secondary_color?: string | null
          theme_name?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      enhanced_subjects: {
        Row: {
          category: string
          class_levels: string[] | null
          code: string
          created_at: string | null
          credits: number | null
          description: string | null
          id: string
          is_active: boolean | null
          name: string
          updated_at: string | null
        }
        Insert: {
          category?: string
          class_levels?: string[] | null
          code: string
          created_at?: string | null
          credits?: number | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          name: string
          updated_at?: string | null
        }
        Update: {
          category?: string
          class_levels?: string[] | null
          code?: string
          created_at?: string | null
          credits?: number | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          name?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      exam_results: {
        Row: {
          average_marks: number
          class_name: string | null
          comments: string | null
          date_entered: string | null
          exam_id: string | null
          exam_name: string | null
          grade: string
          id: string
          position: number | null
          student_id: string | null
          student_name: string | null
          subject_results: Json
          teacher: string | null
          total_marks: number
        }
        Insert: {
          average_marks: number
          class_name?: string | null
          comments?: string | null
          date_entered?: string | null
          exam_id?: string | null
          exam_name?: string | null
          grade: string
          id: string
          position?: number | null
          student_id?: string | null
          student_name?: string | null
          subject_results: Json
          teacher?: string | null
          total_marks: number
        }
        Update: {
          average_marks?: number
          class_name?: string | null
          comments?: string | null
          date_entered?: string | null
          exam_id?: string | null
          exam_name?: string | null
          grade?: string
          id?: string
          position?: number | null
          student_id?: string | null
          student_name?: string | null
          subject_results?: Json
          teacher?: string | null
          total_marks?: number
        }
        Relationships: [
          {
            foreignKeyName: "exam_results_exam_id_fkey"
            columns: ["exam_id"]
            isOneToOne: false
            referencedRelation: "exams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "exam_results_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      exams: {
        Row: {
          created_at: string | null
          end_date: string
          grade_scale: Json
          id: string
          is_active: boolean | null
          name: string
          start_date: string
          term: string
          updated_at: string | null
          year: string
        }
        Insert: {
          created_at?: string | null
          end_date: string
          grade_scale?: Json
          id: string
          is_active?: boolean | null
          name: string
          start_date: string
          term: string
          updated_at?: string | null
          year: string
        }
        Update: {
          created_at?: string | null
          end_date?: string
          grade_scale?: Json
          id?: string
          is_active?: boolean | null
          name?: string
          start_date?: string
          term?: string
          updated_at?: string | null
          year?: string
        }
        Relationships: []
      }
      fee_structure_classes: {
        Row: {
          class_id: string
          created_at: string | null
          fee_structure_id: string
          id: string
          updated_at: string | null
        }
        Insert: {
          class_id: string
          created_at?: string | null
          fee_structure_id: string
          id?: string
          updated_at?: string | null
        }
        Update: {
          class_id?: string
          created_at?: string | null
          fee_structure_id?: string
          id?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fee_structure_classes_class_id_fkey"
            columns: ["class_id"]
            isOneToOne: false
            referencedRelation: "class_streams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fee_structure_classes_fee_structure_id_fkey"
            columns: ["fee_structure_id"]
            isOneToOne: false
            referencedRelation: "fee_structures"
            referencedColumns: ["id"]
          },
        ]
      }
      fee_structures: {
        Row: {
          academic_term: string
          academic_year: string
          activity_fee: number | null
          boarding_fee: number | null
          boarding_status: string | null
          class_level: string | null
          computer_fee: number | null
          created_at: string | null
          day_fee: number | null
          development_fee: number | null
          exam_fee: number | null
          id: string
          is_default: boolean | null
          library_fee: number | null
          meal_fee: number | null
          medical_fee: number | null
          misc_fee: number | null
          name: string
          structure_group: string | null
          term: string | null
          total_fee: number | null
          transport_fee: number | null
          transport_required: boolean | null
          tuition_fee: number
          uniform_fee: number | null
          updated_at: string | null
          year: string | null
        }
        Insert: {
          academic_term: string
          academic_year: string
          activity_fee?: number | null
          boarding_fee?: number | null
          boarding_status?: string | null
          class_level?: string | null
          computer_fee?: number | null
          created_at?: string | null
          day_fee?: number | null
          development_fee?: number | null
          exam_fee?: number | null
          id?: string
          is_default?: boolean | null
          library_fee?: number | null
          meal_fee?: number | null
          medical_fee?: number | null
          misc_fee?: number | null
          name: string
          structure_group?: string | null
          term?: string | null
          total_fee?: number | null
          transport_fee?: number | null
          transport_required?: boolean | null
          tuition_fee?: number
          uniform_fee?: number | null
          updated_at?: string | null
          year?: string | null
        }
        Update: {
          academic_term?: string
          academic_year?: string
          activity_fee?: number | null
          boarding_fee?: number | null
          boarding_status?: string | null
          class_level?: string | null
          computer_fee?: number | null
          created_at?: string | null
          day_fee?: number | null
          development_fee?: number | null
          exam_fee?: number | null
          id?: string
          is_default?: boolean | null
          library_fee?: number | null
          meal_fee?: number | null
          medical_fee?: number | null
          misc_fee?: number | null
          name?: string
          structure_group?: string | null
          term?: string | null
          total_fee?: number | null
          transport_fee?: number | null
          transport_required?: boolean | null
          tuition_fee?: number
          uniform_fee?: number | null
          updated_at?: string | null
          year?: string | null
        }
        Relationships: []
      }
      fee_transactions: {
        Row: {
          academic_term: string
          academic_year: string
          amount: number
          created_at: string | null
          created_by: string | null
          id: string
          notes: string | null
          payment_date: string | null
          payment_method: string
          receipt_number: string | null
          status: string | null
          student_fee_id: string | null
          student_id: string | null
          transaction_type: string | null
        }
        Insert: {
          academic_term: string
          academic_year: string
          amount: number
          created_at?: string | null
          created_by?: string | null
          id?: string
          notes?: string | null
          payment_date?: string | null
          payment_method: string
          receipt_number?: string | null
          status?: string | null
          student_fee_id?: string | null
          student_id?: string | null
          transaction_type?: string | null
        }
        Update: {
          academic_term?: string
          academic_year?: string
          amount?: number
          created_at?: string | null
          created_by?: string | null
          id?: string
          notes?: string | null
          payment_date?: string | null
          payment_method?: string
          receipt_number?: string | null
          status?: string | null
          student_fee_id?: string | null
          student_id?: string | null
          transaction_type?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fee_transactions_student_fee_id_fkey"
            columns: ["student_fee_id"]
            isOneToOne: false
            referencedRelation: "student_fees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fee_transactions_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      fees_usage: {
        Row: {
          amount: number
          category: string
          created_at: string | null
          date: string
          id: string
          inventory_item_id: string | null
          notes: string | null
          title: string
          updated_at: string | null
        }
        Insert: {
          amount: number
          category: string
          created_at?: string | null
          date?: string
          id?: string
          inventory_item_id?: string | null
          notes?: string | null
          title: string
          updated_at?: string | null
        }
        Update: {
          amount?: number
          category?: string
          created_at?: string | null
          date?: string
          id?: string
          inventory_item_id?: string | null
          notes?: string | null
          title?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fees_usage_inventory_item_id_fkey"
            columns: ["inventory_item_id"]
            isOneToOne: false
            referencedRelation: "inventory_items"
            referencedColumns: ["id"]
          },
        ]
      }
      inventory_categories: {
        Row: {
          created_at: string | null
          description: string | null
          id: string
          name: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          id?: string
          name: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          id?: string
          name?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      inventory_items: {
        Row: {
          assigned_to: string | null
          brand: string | null
          category: Database["public"]["Enums"]["inventory_category"]
          category_id: string | null
          condition: Database["public"]["Enums"]["inventory_condition"] | null
          cost: number | null
          created_at: string | null
          created_by: string | null
          current_value: number | null
          date_purchased: string | null
          description: string | null
          enrollment_status: string | null
          google_device_id: string | null
          id: string
          location: string | null
          maintenance_schedule: string | null
          model: string | null
          name: string
          notes: string | null
          paid_from_fees: boolean | null
          purchase_cost: number | null
          purchase_date: string | null
          quantity: number | null
          serial_number: string | null
          status: Database["public"]["Enums"]["inventory_status"] | null
          updated_at: string | null
          updated_by: string | null
          warranty_expiry: string | null
        }
        Insert: {
          assigned_to?: string | null
          brand?: string | null
          category: Database["public"]["Enums"]["inventory_category"]
          category_id?: string | null
          condition?: Database["public"]["Enums"]["inventory_condition"] | null
          cost?: number | null
          created_at?: string | null
          created_by?: string | null
          current_value?: number | null
          date_purchased?: string | null
          description?: string | null
          enrollment_status?: string | null
          google_device_id?: string | null
          id?: string
          location?: string | null
          maintenance_schedule?: string | null
          model?: string | null
          name: string
          notes?: string | null
          paid_from_fees?: boolean | null
          purchase_cost?: number | null
          purchase_date?: string | null
          quantity?: number | null
          serial_number?: string | null
          status?: Database["public"]["Enums"]["inventory_status"] | null
          updated_at?: string | null
          updated_by?: string | null
          warranty_expiry?: string | null
        }
        Update: {
          assigned_to?: string | null
          brand?: string | null
          category?: Database["public"]["Enums"]["inventory_category"]
          category_id?: string | null
          condition?: Database["public"]["Enums"]["inventory_condition"] | null
          cost?: number | null
          created_at?: string | null
          created_by?: string | null
          current_value?: number | null
          date_purchased?: string | null
          description?: string | null
          enrollment_status?: string | null
          google_device_id?: string | null
          id?: string
          location?: string | null
          maintenance_schedule?: string | null
          model?: string | null
          name?: string
          notes?: string | null
          paid_from_fees?: boolean | null
          purchase_cost?: number | null
          purchase_date?: string | null
          quantity?: number | null
          serial_number?: string | null
          status?: Database["public"]["Enums"]["inventory_status"] | null
          updated_at?: string | null
          updated_by?: string | null
          warranty_expiry?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "inventory_items_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "inventory_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      inventory_transactions: {
        Row: {
          assigned_from: string | null
          assigned_to: string | null
          from_location: string | null
          id: string
          inventory_item_id: string | null
          notes: string | null
          performed_by: string
          to_location: string | null
          transaction_date: string | null
          transaction_type: string
        }
        Insert: {
          assigned_from?: string | null
          assigned_to?: string | null
          from_location?: string | null
          id?: string
          inventory_item_id?: string | null
          notes?: string | null
          performed_by: string
          to_location?: string | null
          transaction_date?: string | null
          transaction_type: string
        }
        Update: {
          assigned_from?: string | null
          assigned_to?: string | null
          from_location?: string | null
          id?: string
          inventory_item_id?: string | null
          notes?: string | null
          performed_by?: string
          to_location?: string | null
          transaction_date?: string | null
          transaction_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "inventory_transactions_inventory_item_id_fkey"
            columns: ["inventory_item_id"]
            isOneToOne: false
            referencedRelation: "inventory_items"
            referencedColumns: ["id"]
          },
        ]
      }
      message_logs: {
        Row: {
          channel: string
          cost_amount: number | null
          created_at: string
          delivery_time: string | null
          error_message: string | null
          id: string
          message_id: string | null
          provider_response: Json | null
          recipient_contact: string
          recipient_id: string
          status: string
        }
        Insert: {
          channel: string
          cost_amount?: number | null
          created_at?: string
          delivery_time?: string | null
          error_message?: string | null
          id?: string
          message_id?: string | null
          provider_response?: Json | null
          recipient_contact: string
          recipient_id: string
          status: string
        }
        Update: {
          channel?: string
          cost_amount?: number | null
          created_at?: string
          delivery_time?: string | null
          error_message?: string | null
          id?: string
          message_id?: string | null
          provider_response?: Json | null
          recipient_contact?: string
          recipient_id?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "message_logs_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "messages"
            referencedColumns: ["id"]
          },
        ]
      }
      message_queue: {
        Row: {
          attempt_count: number | null
          channel: string
          created_at: string | null
          error_message: string | null
          id: string
          message_content: string
          message_id: string | null
          provider_response: Json | null
          recipient_contact: string
          scheduled_at: string | null
          status: string
          subject: string | null
          updated_at: string | null
        }
        Insert: {
          attempt_count?: number | null
          channel: string
          created_at?: string | null
          error_message?: string | null
          id?: string
          message_content: string
          message_id?: string | null
          provider_response?: Json | null
          recipient_contact: string
          scheduled_at?: string | null
          status?: string
          subject?: string | null
          updated_at?: string | null
        }
        Update: {
          attempt_count?: number | null
          channel?: string
          created_at?: string | null
          error_message?: string | null
          id?: string
          message_content?: string
          message_id?: string | null
          provider_response?: Json | null
          recipient_contact?: string
          scheduled_at?: string | null
          status?: string
          subject?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "message_queue_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "messages"
            referencedColumns: ["id"]
          },
        ]
      }
      message_templates: {
        Row: {
          category: string
          channels: string[]
          content: string
          created_at: string
          id: string
          is_default: boolean | null
          name: string
          title: string
          updated_at: string
          variables: string[] | null
        }
        Insert: {
          category: string
          channels: string[]
          content: string
          created_at?: string
          id?: string
          is_default?: boolean | null
          name: string
          title: string
          updated_at?: string
          variables?: string[] | null
        }
        Update: {
          category?: string
          channels?: string[]
          content?: string
          created_at?: string
          id?: string
          is_default?: boolean | null
          name?: string
          title?: string
          updated_at?: string
          variables?: string[] | null
        }
        Relationships: []
      }
      message_triggers: {
        Row: {
          channels: string[]
          condition_criteria: Json
          created_at: string
          id: string
          is_active: boolean | null
          last_triggered_at: string | null
          name: string
          target_groups: string[] | null
          template_id: string | null
          trigger_type: string
          updated_at: string
        }
        Insert: {
          channels: string[]
          condition_criteria?: Json
          created_at?: string
          id?: string
          is_active?: boolean | null
          last_triggered_at?: string | null
          name: string
          target_groups?: string[] | null
          template_id?: string | null
          trigger_type: string
          updated_at?: string
        }
        Update: {
          channels?: string[]
          condition_criteria?: Json
          created_at?: string
          id?: string
          is_active?: boolean | null
          last_triggered_at?: string | null
          name?: string
          target_groups?: string[] | null
          template_id?: string | null
          trigger_type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "message_triggers_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "message_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      messages: {
        Row: {
          channel: string
          content: string
          created_at: string
          delivery_status: Json | null
          id: string
          metadata: Json | null
          recipient_ids: string[]
          recipient_type: string
          scheduled_at: string | null
          sender_id: string | null
          sent_at: string | null
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          channel: string
          content: string
          created_at?: string
          delivery_status?: Json | null
          id?: string
          metadata?: Json | null
          recipient_ids: string[]
          recipient_type: string
          scheduled_at?: string | null
          sender_id?: string | null
          sent_at?: string | null
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          channel?: string
          content?: string
          created_at?: string
          delivery_status?: Json | null
          id?: string
          metadata?: Json | null
          recipient_ids?: string[]
          recipient_type?: string
          scheduled_at?: string | null
          sender_id?: string | null
          sent_at?: string | null
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      payments: {
        Row: {
          academic_term: string | null
          academic_year: string | null
          amount: number
          created_at: string | null
          created_by: string | null
          date: string | null
          fee_breakdown: Json | null
          id: string
          method: string | null
          notes: string | null
          receipt_no: string | null
          student_id: string | null
          student_name: string | null
          updated_at: string | null
          updated_by: string | null
        }
        Insert: {
          academic_term?: string | null
          academic_year?: string | null
          amount: number
          created_at?: string | null
          created_by?: string | null
          date?: string | null
          fee_breakdown?: Json | null
          id?: string
          method?: string | null
          notes?: string | null
          receipt_no?: string | null
          student_id?: string | null
          student_name?: string | null
          updated_at?: string | null
          updated_by?: string | null
        }
        Update: {
          academic_term?: string | null
          academic_year?: string | null
          amount?: number
          created_at?: string | null
          created_by?: string | null
          date?: string | null
          fee_breakdown?: Json | null
          id?: string
          method?: string | null
          notes?: string | null
          receipt_no?: string | null
          student_id?: string | null
          student_name?: string | null
          updated_at?: string | null
          updated_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "payments_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      payroll_records: {
        Row: {
          allowances: number | null
          basic_salary: number
          created_at: string | null
          deductions: number | null
          id: string
          net_pay: number
          notes: string | null
          overtime_pay: number | null
          pay_date: string | null
          pay_period_end: string
          pay_period_start: string
          status: string | null
          tax_deductions: number | null
          teacher_id: string | null
          updated_at: string | null
        }
        Insert: {
          allowances?: number | null
          basic_salary: number
          created_at?: string | null
          deductions?: number | null
          id?: string
          net_pay: number
          notes?: string | null
          overtime_pay?: number | null
          pay_date?: string | null
          pay_period_end: string
          pay_period_start: string
          status?: string | null
          tax_deductions?: number | null
          teacher_id?: string | null
          updated_at?: string | null
        }
        Update: {
          allowances?: number | null
          basic_salary?: number
          created_at?: string | null
          deductions?: number | null
          id?: string
          net_pay?: number
          notes?: string | null
          overtime_pay?: number | null
          pay_date?: string | null
          pay_period_end?: string
          pay_period_start?: string
          status?: string | null
          tax_deductions?: number | null
          teacher_id?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "payroll_records_teacher_id_fkey"
            columns: ["teacher_id"]
            isOneToOne: false
            referencedRelation: "teachers"
            referencedColumns: ["id"]
          },
        ]
      }
      school_profile: {
        Row: {
          academic_year: string | null
          address: string | null
          city: string | null
          country: string | null
          created_at: string | null
          current_term: string | null
          email: string | null
          id: string
          logo_url: string | null
          motto: string | null
          name: string
          phone: string | null
          postal_code: string | null
          state: string | null
          term_end_date: string | null
          term_start_date: string | null
          updated_at: string | null
          website: string | null
        }
        Insert: {
          academic_year?: string | null
          address?: string | null
          city?: string | null
          country?: string | null
          created_at?: string | null
          current_term?: string | null
          email?: string | null
          id?: string
          logo_url?: string | null
          motto?: string | null
          name: string
          phone?: string | null
          postal_code?: string | null
          state?: string | null
          term_end_date?: string | null
          term_start_date?: string | null
          updated_at?: string | null
          website?: string | null
        }
        Update: {
          academic_year?: string | null
          address?: string | null
          city?: string | null
          country?: string | null
          created_at?: string | null
          current_term?: string | null
          email?: string | null
          id?: string
          logo_url?: string | null
          motto?: string | null
          name?: string
          phone?: string | null
          postal_code?: string | null
          state?: string | null
          term_end_date?: string | null
          term_start_date?: string | null
          updated_at?: string | null
          website?: string | null
        }
        Relationships: []
      }
      seat_assignments: {
        Row: {
          created_at: string | null
          id: string
          seat_layout_id: string | null
          seat_position: string
          student_id: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          seat_layout_id?: string | null
          seat_position: string
          student_id?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          seat_layout_id?: string | null
          seat_position?: string
          student_id?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "seat_assignments_seat_layout_id_fkey"
            columns: ["seat_layout_id"]
            isOneToOne: false
            referencedRelation: "seat_layouts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "seat_assignments_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      seat_layouts: {
        Row: {
          class_name: string
          columns: number
          created_at: string | null
          id: string
          rows: number
          updated_at: string | null
        }
        Insert: {
          class_name: string
          columns?: number
          created_at?: string | null
          id?: string
          rows?: number
          updated_at?: string | null
        }
        Update: {
          class_name?: string
          columns?: number
          created_at?: string | null
          id?: string
          rows?: number
          updated_at?: string | null
        }
        Relationships: []
      }
      security_settings: {
        Row: {
          audit_logging: boolean | null
          auto_logout_minutes: number | null
          created_at: string | null
          id: string
          log_retention_days: number | null
          password_policy: Json | null
          session_settings: Json | null
          two_factor_enabled: boolean | null
          updated_at: string | null
        }
        Insert: {
          audit_logging?: boolean | null
          auto_logout_minutes?: number | null
          created_at?: string | null
          id?: string
          log_retention_days?: number | null
          password_policy?: Json | null
          session_settings?: Json | null
          two_factor_enabled?: boolean | null
          updated_at?: string | null
        }
        Update: {
          audit_logging?: boolean | null
          auto_logout_minutes?: number | null
          created_at?: string | null
          id?: string
          log_retention_days?: number | null
          password_policy?: Json | null
          session_settings?: Json | null
          two_factor_enabled?: boolean | null
          updated_at?: string | null
        }
        Relationships: []
      }
      site_settings: {
        Row: {
          class_label_format: string | null
          created_at: string | null
          currency: string | null
          date_format: string | null
          id: number
          school_name: string | null
          theme: string | null
          updated_at: string | null
        }
        Insert: {
          class_label_format?: string | null
          created_at?: string | null
          currency?: string | null
          date_format?: string | null
          id?: number
          school_name?: string | null
          theme?: string | null
          updated_at?: string | null
        }
        Update: {
          class_label_format?: string | null
          created_at?: string | null
          currency?: string | null
          date_format?: string | null
          id?: number
          school_name?: string | null
          theme?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      staff_attendance: {
        Row: {
          check_in_time: string | null
          check_out_time: string | null
          created_at: string | null
          date: string
          hours_worked: number | null
          id: string
          notes: string | null
          status: string | null
          teacher_id: string | null
          updated_at: string | null
        }
        Insert: {
          check_in_time?: string | null
          check_out_time?: string | null
          created_at?: string | null
          date: string
          hours_worked?: number | null
          id?: string
          notes?: string | null
          status?: string | null
          teacher_id?: string | null
          updated_at?: string | null
        }
        Update: {
          check_in_time?: string | null
          check_out_time?: string | null
          created_at?: string | null
          date?: string
          hours_worked?: number | null
          id?: string
          notes?: string | null
          status?: string | null
          teacher_id?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "staff_attendance_teacher_id_fkey"
            columns: ["teacher_id"]
            isOneToOne: false
            referencedRelation: "teachers"
            referencedColumns: ["id"]
          },
        ]
      }
      staff_leave_requests: {
        Row: {
          approved_by: string | null
          approved_date: string | null
          created_at: string | null
          days_requested: number
          end_date: string
          id: string
          leave_type: Database["public"]["Enums"]["leave_type"]
          reason: string
          rejection_reason: string | null
          start_date: string
          status: Database["public"]["Enums"]["leave_status"] | null
          teacher_id: string | null
          updated_at: string | null
        }
        Insert: {
          approved_by?: string | null
          approved_date?: string | null
          created_at?: string | null
          days_requested: number
          end_date: string
          id?: string
          leave_type: Database["public"]["Enums"]["leave_type"]
          reason: string
          rejection_reason?: string | null
          start_date: string
          status?: Database["public"]["Enums"]["leave_status"] | null
          teacher_id?: string | null
          updated_at?: string | null
        }
        Update: {
          approved_by?: string | null
          approved_date?: string | null
          created_at?: string | null
          days_requested?: number
          end_date?: string
          id?: string
          leave_type?: Database["public"]["Enums"]["leave_type"]
          reason?: string
          rejection_reason?: string | null
          start_date?: string
          status?: Database["public"]["Enums"]["leave_status"] | null
          teacher_id?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "staff_leave_requests_teacher_id_fkey"
            columns: ["teacher_id"]
            isOneToOne: false
            referencedRelation: "teachers"
            referencedColumns: ["id"]
          },
        ]
      }
      student_assessment_summary: {
        Row: {
          academic_term: string
          academic_year: string
          average_percentage: number | null
          class_name: string
          completed_assessments: number | null
          created_at: string | null
          current_grade: string | null
          id: string
          last_updated: string | null
          student_id: string
          subject_id: string
          total_assessments: number | null
          updated_at: string | null
        }
        Insert: {
          academic_term: string
          academic_year: string
          average_percentage?: number | null
          class_name: string
          completed_assessments?: number | null
          created_at?: string | null
          current_grade?: string | null
          id?: string
          last_updated?: string | null
          student_id: string
          subject_id: string
          total_assessments?: number | null
          updated_at?: string | null
        }
        Update: {
          academic_term?: string
          academic_year?: string
          average_percentage?: number | null
          class_name?: string
          completed_assessments?: number | null
          created_at?: string | null
          current_grade?: string | null
          id?: string
          last_updated?: string | null
          student_id?: string
          subject_id?: string
          total_assessments?: number | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "student_assessment_summary_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "student_assessment_summary_subject_id_fkey"
            columns: ["subject_id"]
            isOneToOne: false
            referencedRelation: "enhanced_subjects"
            referencedColumns: ["id"]
          },
        ]
      }
      student_balances: {
        Row: {
          balance: number
          created_at: string | null
          fee_structure_id: string
          id: string
          student_id: string
          term: string
          total_paid: number
          total_required: number
          updated_at: string | null
          year: string
        }
        Insert: {
          balance?: number
          created_at?: string | null
          fee_structure_id: string
          id?: string
          student_id: string
          term: string
          total_paid?: number
          total_required?: number
          updated_at?: string | null
          year: string
        }
        Update: {
          balance?: number
          created_at?: string | null
          fee_structure_id?: string
          id?: string
          student_id?: string
          term?: string
          total_paid?: number
          total_required?: number
          updated_at?: string | null
          year?: string
        }
        Relationships: [
          {
            foreignKeyName: "student_balances_fee_structure_id_fkey"
            columns: ["fee_structure_id"]
            isOneToOne: false
            referencedRelation: "fee_structures"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "student_balances_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      student_fee_customizations: {
        Row: {
          academic_term: string
          academic_year: string
          amount_or_percentage: number | null
          applied_by: string | null
          created_at: string | null
          customization_type: string | null
          description: string | null
          fee_structure_id: string | null
          id: string
          is_percentage: boolean | null
          student_id: string
          updated_at: string | null
        }
        Insert: {
          academic_term: string
          academic_year: string
          amount_or_percentage?: number | null
          applied_by?: string | null
          created_at?: string | null
          customization_type?: string | null
          description?: string | null
          fee_structure_id?: string | null
          id?: string
          is_percentage?: boolean | null
          student_id: string
          updated_at?: string | null
        }
        Update: {
          academic_term?: string
          academic_year?: string
          amount_or_percentage?: number | null
          applied_by?: string | null
          created_at?: string | null
          customization_type?: string | null
          description?: string | null
          fee_structure_id?: string | null
          id?: string
          is_percentage?: boolean | null
          student_id?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "student_fee_customizations_fee_structure_id_fkey"
            columns: ["fee_structure_id"]
            isOneToOne: false
            referencedRelation: "fee_structures"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "student_fee_customizations_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      student_fees: {
        Row: {
          academic_term: string
          academic_year: string
          balance: number | null
          created_at: string | null
          fee_structure_id: string | null
          id: string
          payment_status: string | null
          student_id: string | null
          total_assigned_fees: number
          total_paid: number
          updated_at: string | null
        }
        Insert: {
          academic_term: string
          academic_year: string
          balance?: number | null
          created_at?: string | null
          fee_structure_id?: string | null
          id?: string
          payment_status?: string | null
          student_id?: string | null
          total_assigned_fees?: number
          total_paid?: number
          updated_at?: string | null
        }
        Update: {
          academic_term?: string
          academic_year?: string
          balance?: number | null
          created_at?: string | null
          fee_structure_id?: string | null
          id?: string
          payment_status?: string | null
          student_id?: string | null
          total_assigned_fees?: number
          total_paid?: number
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "student_fees_fee_structure_id_fkey"
            columns: ["fee_structure_id"]
            isOneToOne: false
            referencedRelation: "fee_structures"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "student_fees_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      students: {
        Row: {
          address: string | null
          best_color: string | null
          blood_group: string | null
          boarding_status: string | null
          class: string
          clubs_activities: string[] | null
          created_at: string | null
          date_of_birth: string | null
          email: string | null
          emergency_contact: string | null
          fee_status: string | null
          full_name: string
          gender: string | null
          id: string
          join_date: string | null
          medical_conditions: string | null
          parent_contact: string | null
          parent_name: string | null
          profile_image: string | null
          profile_image_url: string | null
          student_id: string
          transport: string | null
          updated_at: string | null
        }
        Insert: {
          address?: string | null
          best_color?: string | null
          blood_group?: string | null
          boarding_status?: string | null
          class: string
          clubs_activities?: string[] | null
          created_at?: string | null
          date_of_birth?: string | null
          email?: string | null
          emergency_contact?: string | null
          fee_status?: string | null
          full_name: string
          gender?: string | null
          id?: string
          join_date?: string | null
          medical_conditions?: string | null
          parent_contact?: string | null
          parent_name?: string | null
          profile_image?: string | null
          profile_image_url?: string | null
          student_id: string
          transport?: string | null
          updated_at?: string | null
        }
        Update: {
          address?: string | null
          best_color?: string | null
          blood_group?: string | null
          boarding_status?: string | null
          class?: string
          clubs_activities?: string[] | null
          created_at?: string | null
          date_of_birth?: string | null
          email?: string | null
          emergency_contact?: string | null
          fee_status?: string | null
          full_name?: string
          gender?: string | null
          id?: string
          join_date?: string | null
          medical_conditions?: string | null
          parent_contact?: string | null
          parent_name?: string | null
          profile_image?: string | null
          profile_image_url?: string | null
          student_id?: string
          transport?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      subject_teacher_assignments: {
        Row: {
          academic_term: string
          academic_year: string
          class_stream_id: string | null
          created_at: string | null
          id: string
          is_primary: boolean | null
          subject_id: string
          teacher_id: string
        }
        Insert: {
          academic_term: string
          academic_year: string
          class_stream_id?: string | null
          created_at?: string | null
          id?: string
          is_primary?: boolean | null
          subject_id: string
          teacher_id: string
        }
        Update: {
          academic_term?: string
          academic_year?: string
          class_stream_id?: string | null
          created_at?: string | null
          id?: string
          is_primary?: boolean | null
          subject_id?: string
          teacher_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "subject_teacher_assignments_class_stream_id_fkey"
            columns: ["class_stream_id"]
            isOneToOne: false
            referencedRelation: "class_streams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "subject_teacher_assignments_subject_id_fkey"
            columns: ["subject_id"]
            isOneToOne: false
            referencedRelation: "enhanced_subjects"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "subject_teacher_assignments_teacher_id_fkey"
            columns: ["teacher_id"]
            isOneToOne: false
            referencedRelation: "teachers"
            referencedColumns: ["id"]
          },
        ]
      }
      subjects: {
        Row: {
          code: string | null
          created_at: string | null
          description: string | null
          id: string
          name: string
          updated_at: string | null
        }
        Insert: {
          code?: string | null
          created_at?: string | null
          description?: string | null
          id?: string
          name: string
          updated_at?: string | null
        }
        Update: {
          code?: string | null
          created_at?: string | null
          description?: string | null
          id?: string
          name?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      system_backups: {
        Row: {
          backup_name: string
          backup_type: string | null
          created_at: string | null
          created_by: string | null
          file_path: string | null
          file_size: number | null
          id: string
          metadata: Json | null
          status: string | null
        }
        Insert: {
          backup_name: string
          backup_type?: string | null
          created_at?: string | null
          created_by?: string | null
          file_path?: string | null
          file_size?: number | null
          id?: string
          metadata?: Json | null
          status?: string | null
        }
        Update: {
          backup_name?: string
          backup_type?: string | null
          created_at?: string | null
          created_by?: string | null
          file_path?: string | null
          file_size?: number | null
          id?: string
          metadata?: Json | null
          status?: string | null
        }
        Relationships: []
      }
      teacher_salaries: {
        Row: {
          amount: number
          created_at: string | null
          id: string
          method: string
          month: string
          notes: string | null
          paid_on: string | null
          status: string
          teacher_id: string | null
          updated_at: string | null
        }
        Insert: {
          amount?: number
          created_at?: string | null
          id?: string
          method?: string
          month: string
          notes?: string | null
          paid_on?: string | null
          status?: string
          teacher_id?: string | null
          updated_at?: string | null
        }
        Update: {
          amount?: number
          created_at?: string | null
          id?: string
          method?: string
          month?: string
          notes?: string | null
          paid_on?: string | null
          status?: string
          teacher_id?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "teacher_salaries_teacher_id_fkey"
            columns: ["teacher_id"]
            isOneToOne: false
            referencedRelation: "teachers"
            referencedColumns: ["id"]
          },
        ]
      }
      teacher_subjects: {
        Row: {
          class_stream_id: string | null
          created_at: string | null
          id: string
          subject_id: string | null
          teacher_id: string | null
        }
        Insert: {
          class_stream_id?: string | null
          created_at?: string | null
          id?: string
          subject_id?: string | null
          teacher_id?: string | null
        }
        Update: {
          class_stream_id?: string | null
          created_at?: string | null
          id?: string
          subject_id?: string | null
          teacher_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "teacher_subjects_class_stream_id_fkey"
            columns: ["class_stream_id"]
            isOneToOne: false
            referencedRelation: "class_streams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "teacher_subjects_subject_id_fkey"
            columns: ["subject_id"]
            isOneToOne: false
            referencedRelation: "subjects"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "teacher_subjects_teacher_id_fkey"
            columns: ["teacher_id"]
            isOneToOne: false
            referencedRelation: "teachers"
            referencedColumns: ["id"]
          },
        ]
      }
      teachers: {
        Row: {
          address: string | null
          biography: string | null
          class_teacher_for: string | null
          created_at: string | null
          date_of_birth: string | null
          email: string | null
          emergency_contact: string | null
          employee_id: string | null
          experience_years: number | null
          gender: string | null
          hire_date: string | null
          id: string
          join_date: string | null
          name: string
          phone: string | null
          profile_image: string | null
          profile_image_url: string | null
          qualification: string | null
          salary: number | null
          specialization: string | null
          status: string | null
          subjects: string[] | null
          updated_at: string | null
        }
        Insert: {
          address?: string | null
          biography?: string | null
          class_teacher_for?: string | null
          created_at?: string | null
          date_of_birth?: string | null
          email?: string | null
          emergency_contact?: string | null
          employee_id?: string | null
          experience_years?: number | null
          gender?: string | null
          hire_date?: string | null
          id?: string
          join_date?: string | null
          name: string
          phone?: string | null
          profile_image?: string | null
          profile_image_url?: string | null
          qualification?: string | null
          salary?: number | null
          specialization?: string | null
          status?: string | null
          subjects?: string[] | null
          updated_at?: string | null
        }
        Update: {
          address?: string | null
          biography?: string | null
          class_teacher_for?: string | null
          created_at?: string | null
          date_of_birth?: string | null
          email?: string | null
          emergency_contact?: string | null
          employee_id?: string | null
          experience_years?: number | null
          gender?: string | null
          hire_date?: string | null
          id?: string
          join_date?: string | null
          name?: string
          phone?: string | null
          profile_image?: string | null
          profile_image_url?: string | null
          qualification?: string | null
          salary?: number | null
          specialization?: string | null
          status?: string | null
          subjects?: string[] | null
          updated_at?: string | null
        }
        Relationships: []
      }
      timetable: {
        Row: {
          class_name: string
          created_at: string | null
          day_of_week: number
          end_time: string
          id: string
          period_number: number
          room: string | null
          start_time: string
          subject_id: string | null
          teacher_id: string | null
          updated_at: string | null
        }
        Insert: {
          class_name: string
          created_at?: string | null
          day_of_week: number
          end_time: string
          id?: string
          period_number: number
          room?: string | null
          start_time: string
          subject_id?: string | null
          teacher_id?: string | null
          updated_at?: string | null
        }
        Update: {
          class_name?: string
          created_at?: string | null
          day_of_week?: number
          end_time?: string
          id?: string
          period_number?: number
          room?: string | null
          start_time?: string
          subject_id?: string | null
          teacher_id?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "timetable_subject_id_fkey"
            columns: ["subject_id"]
            isOneToOne: false
            referencedRelation: "subjects"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "timetable_teacher_id_fkey"
            columns: ["teacher_id"]
            isOneToOne: false
            referencedRelation: "teachers"
            referencedColumns: ["id"]
          },
        ]
      }
      transport_routes: {
        Row: {
          created_at: string | null
          fee_amount: number | null
          id: string
          route_name: string
          schedule: Json | null
          stops: Json | null
          updated_at: string | null
          vehicle_id: string | null
        }
        Insert: {
          created_at?: string | null
          fee_amount?: number | null
          id?: string
          route_name: string
          schedule?: Json | null
          stops?: Json | null
          updated_at?: string | null
          vehicle_id?: string | null
        }
        Update: {
          created_at?: string | null
          fee_amount?: number | null
          id?: string
          route_name?: string
          schedule?: Json | null
          stops?: Json | null
          updated_at?: string | null
          vehicle_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "transport_routes_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "transport_vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      transport_vehicles: {
        Row: {
          capacity: number | null
          created_at: string | null
          driver_name: string | null
          driver_phone: string | null
          id: string
          maintenance_schedule: Json | null
          route_name: string | null
          status: Database["public"]["Enums"]["transport_status"] | null
          updated_at: string | null
          vehicle_number: string
        }
        Insert: {
          capacity?: number | null
          created_at?: string | null
          driver_name?: string | null
          driver_phone?: string | null
          id?: string
          maintenance_schedule?: Json | null
          route_name?: string | null
          status?: Database["public"]["Enums"]["transport_status"] | null
          updated_at?: string | null
          vehicle_number: string
        }
        Update: {
          capacity?: number | null
          created_at?: string | null
          driver_name?: string | null
          driver_phone?: string | null
          id?: string
          maintenance_schedule?: Json | null
          route_name?: string | null
          status?: Database["public"]["Enums"]["transport_status"] | null
          updated_at?: string | null
          vehicle_number?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string | null
          id: string
          permissions: Json | null
          role: Database["public"]["Enums"]["user_role_type"]
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          permissions?: Json | null
          role: Database["public"]["Enums"]["user_role_type"]
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          permissions?: Json | null
          role?: Database["public"]["Enums"]["user_role_type"]
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      available_classes: {
        Row: {
          class_id: string | null
          class_name: string | null
          student_count: number | null
        }
        Relationships: []
      }
    }
    Functions: {
      assign_fees_to_students: { Args: never; Returns: undefined }
    }
    Enums: {
      assessment_type:
        | "exam"
        | "assignment"
        | "test"
        | "quiz"
        | "project"
        | "presentation"
        | "practical"
        | "homework"
        | "classwork"
        | "other"
      attendance_policy_type: "strict" | "flexible" | "custom"
      boarding_status: "day" | "boarding" | "mixed"
      inventory_category:
        | "computers"
        | "furniture"
        | "lab_equipment"
        | "sports_equipment"
        | "books"
        | "vehicles"
        | "electronics"
        | "office_supplies"
        | "other"
      inventory_condition:
        | "excellent"
        | "good"
        | "fair"
        | "poor"
        | "damaged"
        | "obsolete"
      inventory_status:
        | "available"
        | "in_use"
        | "maintenance"
        | "retired"
        | "lost"
        | "stolen"
      leave_status: "pending" | "approved" | "rejected" | "cancelled"
      leave_type:
        | "annual"
        | "sick"
        | "maternity"
        | "paternity"
        | "emergency"
        | "study"
        | "unpaid"
        | "compassionate"
      transport_status: "active" | "inactive" | "maintenance"
      user_role_type: "owner" | "admin" | "teacher" | "student" | "parent"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      assessment_type: [
        "exam",
        "assignment",
        "test",
        "quiz",
        "project",
        "presentation",
        "practical",
        "homework",
        "classwork",
        "other",
      ],
      attendance_policy_type: ["strict", "flexible", "custom"],
      boarding_status: ["day", "boarding", "mixed"],
      inventory_category: [
        "computers",
        "furniture",
        "lab_equipment",
        "sports_equipment",
        "books",
        "vehicles",
        "electronics",
        "office_supplies",
        "other",
      ],
      inventory_condition: [
        "excellent",
        "good",
        "fair",
        "poor",
        "damaged",
        "obsolete",
      ],
      inventory_status: [
        "available",
        "in_use",
        "maintenance",
        "retired",
        "lost",
        "stolen",
      ],
      leave_status: ["pending", "approved", "rejected", "cancelled"],
      leave_type: [
        "annual",
        "sick",
        "maternity",
        "paternity",
        "emergency",
        "study",
        "unpaid",
        "compassionate",
      ],
      transport_status: ["active", "inactive", "maintenance"],
      user_role_type: ["owner", "admin", "teacher", "student", "parent"],
    },
  },
} as const
