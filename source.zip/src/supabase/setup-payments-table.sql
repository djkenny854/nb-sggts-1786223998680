
-- Create the payments table
CREATE TABLE IF NOT EXISTS payments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id UUID NOT NULL,
  student_name TEXT,
  amount NUMERIC NOT NULL,
  method TEXT NOT NULL,
  description TEXT NOT NULL,
  received_by TEXT NOT NULL,
  academic_term TEXT NOT NULL,
  academic_year TEXT NOT NULL,
  receipt_number TEXT UNIQUE,
  payment_date TIMESTAMPTZ DEFAULT NOW(),
  fee_type TEXT, -- e.g., 'tuition', 'transport', 'boarding', etc.
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ
);

-- Add RLS policies
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

-- Development policies - Everyone can select, only authenticated users can insert/update
CREATE POLICY payments_select_policy ON payments
  FOR SELECT USING (true);

CREATE POLICY payments_insert_policy ON payments
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY payments_update_policy ON payments
  FOR UPDATE TO authenticated USING (true);

-- Example production policies (commented out by default)
-- Only allow students to view their own payments
-- CREATE POLICY payments_select_own_policy ON payments
--   FOR SELECT TO authenticated
--   USING (auth.uid()::text = student_id::text);

-- Create index on student_id for faster lookups
CREATE INDEX IF NOT EXISTS payments_student_id_idx ON payments(student_id);
CREATE INDEX IF NOT EXISTS payments_academic_term_idx ON payments(academic_term);
CREATE INDEX IF NOT EXISTS payments_academic_year_idx ON payments(academic_year);

-- Add foreign key to students table
ALTER TABLE payments 
  ADD CONSTRAINT payments_student_id_fkey 
  FOREIGN KEY (student_id) 
  REFERENCES students(id)
  ON DELETE CASCADE;

-- Create trigger to update the updated_at timestamp
CREATE TRIGGER update_payments_updated_at
BEFORE UPDATE ON payments
FOR EACH ROW
EXECUTE PROCEDURE update_updated_at_column();
