
import { supabase } from "@/lib/supabase";
import { format } from "date-fns";

export type AttendanceStatus = 'present' | 'absent' | 'late' | 'excused';

export type AttendanceRecord = {
  id?: string;
  date: string;
  student_id: string;
  status: AttendanceStatus;
  notes?: string | null;
};

export type AttendanceSummary = {
  date: string;
  className: string;
  present: number;
  absent: number;
  late: number;
  excused: number;
  total: number;
};

/**
 * Fetch attendance records for a specific date and class
 */
export const fetchAttendanceByDateAndClass = async (date: Date, className: string) => {
  const formattedDate = format(date, 'yyyy-MM-dd');
  
  try {
    // First get student IDs for the class
    const { data: students, error: studentsError } = await supabase
      .from('students')
      .select('id')
      .eq('class', className);
      
    if (studentsError) throw studentsError;
    
    if (students?.length === 0) {
      return [];
    }
      
    // Then get attendance records for those students on the specified date
    const { data, error } = await supabase
      .from('attendance_records')
      .select('*')
      .eq('date', formattedDate)
      .in('student_id', students.map(s => s.id));
      
    if (error) throw error;
    
    return data || [];
  } catch (error) {
    console.error('Error fetching attendance:', error);
    throw error;
  }
};

/**
 * Save multiple attendance records
 */
export const saveAttendanceRecords = async (records: AttendanceRecord[]) => {
  try {
    // Group records by date
    const recordsByDate = records.reduce<Record<string, AttendanceRecord[]>>((acc, record) => {
      if (!acc[record.date]) {
        acc[record.date] = [];
      }
      acc[record.date].push(record);
      return acc;
    }, {});
    
    // For each date, delete existing records and insert new ones
    for (const [date, dateRecords] of Object.entries(recordsByDate)) {
      const studentIds = dateRecords.map(r => r.student_id);
      
      // Delete existing records
      await supabase
        .from('attendance_records')
        .delete()
        .eq('date', date)
        .in('student_id', studentIds);
        
      // Insert new records
      const { error } = await supabase
        .from('attendance_records')
        .insert(dateRecords);
        
      if (error) throw error;
    }
    
    return true;
  } catch (error) {
    console.error('Error saving attendance records:', error);
    throw error;
  }
};

/**
 * Get attendance summary by date range
 */
export const getAttendanceSummary = async (startDate: Date, endDate: Date) => {
  const formattedStartDate = format(startDate, 'yyyy-MM-dd');
  const formattedEndDate = format(endDate, 'yyyy-MM-dd');
  
  try {
    // Get all attendance records in the date range
    const { data, error } = await supabase
      .from('attendance_records')
      .select(`
        date,
        status,
        students!inner(
          class
        )
      `)
      .gte('date', formattedStartDate)
      .lte('date', formattedEndDate);
      
    if (error) throw error;
    
    if (!data || data.length === 0) {
      return [];
    }
    
    // Define the type for the record from the query
    type AttendanceQueryRecord = {
      date: string;
      status: AttendanceStatus;
      students: {
        class: string;
      };
    };

    // Group by date and class
    const summaryMap = (data as AttendanceQueryRecord[]).reduce<Record<string, {
      present: number;
      absent: number;
      late: number;
      excused: number;
      total: number;
    }>>((acc, record) => {
      const { date, status, students } = record;
      const className = students.class;
      
      const key = `${date}_${className}`;
      
      if (!acc[key]) {
        acc[key] = {
          present: 0,
          absent: 0,
          late: 0,
          excused: 0,
          total: 0,
        };
      }
      
      // Safely increment the count for the specific status
      if (status === 'present') {
        acc[key].present += 1;
      } else if (status === 'absent') {
        acc[key].absent += 1;
      } else if (status === 'late') {
        acc[key].late += 1;
      } else if (status === 'excused') {
        acc[key].excused += 1;
      }
      
      acc[key].total += 1;
      
      return acc;
    }, {});
    
    // Convert to array
    return Object.entries(summaryMap).map(([key, stats]) => {
      const [date, className] = key.split('_');
      
      return {
        date,
        className,
        ...stats,
      };
    });
    
  } catch (error) {
    console.error('Error getting attendance summary:', error);
    throw error;
  }
};
