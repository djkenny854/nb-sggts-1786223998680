
import { supabase } from '@/lib/supabase';

export interface FeesStructure {
  tuition: number;
  transport: number;
  boarding: number;
  activities: number;
  total: number;
}

export const getDefaultFeesStructure = async (): Promise<FeesStructure> => {
  try {
    // Get settings from database
    const { data: settings, error } = await supabase
      .from('site_settings')
      .select('*')
      .single();

    if (error) {
      console.warn('Error fetching settings for fees:', error);
    }

    // Default fees structure (can be configured from settings later)
    const defaultFees: FeesStructure = {
      tuition: 500000, // UGX 500,000
      transport: 50000, // UGX 50,000
      boarding: 300000, // UGX 300,000
      activities: 25000, // UGX 25,000
      total: 0
    };

    // Override with settings if available
    if (settings) {
      // You can add fee settings to the site_settings table later
      // defaultFees.tuition = settings.tuition_fee || defaultFees.tuition;
    }

    // Calculate total fees based on student's selections
    defaultFees.total = defaultFees.tuition + defaultFees.activities;

    return defaultFees;
  } catch (error) {
    console.error('Error getting fees structure:', error);
    return {
      tuition: 500000,
      transport: 50000,
      boarding: 300000,
      activities: 25000,
      total: 525000
    };
  }
};

export const calculateStudentFees = (
  feesStructure: FeesStructure,
  boardingStatus: 'Boarding' | 'Day',
  transportUse: 'Yes' | 'No'
): number => {
  let totalFees = feesStructure.tuition + feesStructure.activities;

  if (boardingStatus === 'Boarding') {
    totalFees += feesStructure.boarding;
  }

  if (transportUse === 'Yes') {
    totalFees += feesStructure.transport;
  }

  return totalFees;
};

export const calculateFeesBreakdown = (
  feesStructure: FeesStructure,
  boardingStatus: 'Boarding' | 'Day',
  transportUse: 'Yes' | 'No'
) => {
  const breakdown = {
    tuition: feesStructure.tuition,
    activities: feesStructure.activities,
    boarding: boardingStatus === 'Boarding' ? feesStructure.boarding : 0,
    transport: transportUse === 'Yes' ? feesStructure.transport : 0,
  };

  const total = Object.values(breakdown).reduce((sum, amount) => sum + amount, 0);

  return {
    ...breakdown,
    total
  };
};

// Calculate correct fees for a student based on their selections
export const calculateCorrectStudentBalance = async (
  student: { 
    boardingStatus?: 'Boarding' | 'Day', 
    transportUse?: 'Yes' | 'No',
    payments?: Array<{ amount: number }>
  }
) => {
  const feesStructure = await getDefaultFeesStructure();
  const totalExpectedFees = calculateStudentFees(
    feesStructure,
    student.boardingStatus || 'Day',
    student.transportUse || 'No'
  );
  
  const totalPaid = student.payments?.reduce((sum, payment) => sum + payment.amount, 0) || 0;
  const balance = Math.max(0, totalExpectedFees - totalPaid);
  
  return {
    totalExpected: totalExpectedFees,
    totalPaid,
    balance
  };
};

// Update student fees when they are promoted or their status changes
export const updateStudentFees = async (
  studentId: string,
  boardingStatus: 'Boarding' | 'Day',
  transportUse: 'Yes' | 'No',
  currentPaid: number = 0
) => {
  try {
    const feesStructure = await getDefaultFeesStructure();
    const newTotalFees = calculateStudentFees(feesStructure, boardingStatus, transportUse);
    
    // Calculate new balance due
    const newDue = Math.max(0, newTotalFees - currentPaid);
    
    return {
      paid: currentPaid,
      due: newDue,
      lastPaymentDate: null // Keep existing last payment date
    };
  } catch (error) {
    console.error('Error updating student fees:', error);
    throw error;
  }
};
