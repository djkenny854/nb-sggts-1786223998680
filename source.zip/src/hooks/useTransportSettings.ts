
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface TransportVehicle {
  id: string;
  vehicle_number: string;
  driver_name: string | null;
  driver_phone: string | null;
  route_name: string | null;
  capacity: number | null;
  status: 'active' | 'inactive' | 'maintenance';
  maintenance_schedule: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export interface TransportRoute {
  id: string;
  route_name: string;
  stops: string[];
  vehicle_id: string | null;
  schedule: Record<string, any>;
  fee_amount: number | null;
  created_at: string;
  updated_at: string;
}

export interface BoardingFacility {
  id: string;
  facility_name: string;
  facility_type: string | null;
  capacity: number | null;
  supervisor_name: string | null;
  supervisor_phone: string | null;
  rules: Record<string, any>;
  fee_amount: number | null;
  created_at: string;
  updated_at: string;
}

export const useTransportSettings = () => {
  const [vehicles, setVehicles] = useState<TransportVehicle[]>([]);
  const [routes, setRoutes] = useState<TransportRoute[]>([]);
  const [facilities, setFacilities] = useState<BoardingFacility[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const [vehiclesRes, routesRes, facilitiesRes] = await Promise.all([
        supabase.from('transport_vehicles').select('*'),
        supabase.from('transport_routes').select('*'),
        supabase.from('boarding_facilities').select('*')
      ]);

      if (vehiclesRes.data) {
        const transformedVehicles = vehiclesRes.data.map(vehicle => ({
          ...vehicle,
          maintenance_schedule: (vehicle.maintenance_schedule as Record<string, any>) || {}
        }));
        setVehicles(transformedVehicles);
      }

      if (routesRes.data) {
        const transformedRoutes = routesRes.data.map(route => ({
          ...route,
          stops: Array.isArray(route.stops) ? 
            (route.stops as any[]).map(stop => typeof stop === 'string' ? stop : String(stop)) : 
            [],
          schedule: (route.schedule as Record<string, any>) || {}
        }));
        setRoutes(transformedRoutes);
      }

      if (facilitiesRes.data) {
        const transformedFacilities = facilitiesRes.data.map(facility => ({
          ...facility,
          rules: (facility.rules as Record<string, any>) || {}
        }));
        setFacilities(transformedFacilities);
      }
    } catch (error) {
      console.error('Error fetching transport data:', error);
      toast.error('Failed to load transport settings');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const addVehicle = async (vehicleData: Partial<TransportVehicle>) => {
    try {
      // Ensure required fields are present
      if (!vehicleData.vehicle_number) {
        throw new Error('Vehicle number is required');
      }

      const dataToInsert = {
        vehicle_number: vehicleData.vehicle_number,
        driver_name: vehicleData.driver_name || null,
        driver_phone: vehicleData.driver_phone || null,
        route_name: vehicleData.route_name || null,
        capacity: vehicleData.capacity || null,
        status: vehicleData.status || 'active' as const,
        maintenance_schedule: vehicleData.maintenance_schedule || {}
      };

      const { data, error } = await supabase
        .from('transport_vehicles')
        .insert(dataToInsert)
        .select()
        .single();

      if (error) throw error;

      const transformedVehicle = {
        ...data,
        maintenance_schedule: (data.maintenance_schedule as Record<string, any>) || {}
      };

      setVehicles(prev => [...prev, transformedVehicle]);
      toast.success('Vehicle added successfully');
    } catch (error) {
      console.error('Error adding vehicle:', error);
      toast.error('Failed to add vehicle');
    }
  };

  const addRoute = async (routeData: Partial<TransportRoute>) => {
    try {
      // Ensure required fields are present
      if (!routeData.route_name) {
        throw new Error('Route name is required');
      }

      const dataToInsert = {
        route_name: routeData.route_name,
        stops: routeData.stops || [],
        vehicle_id: routeData.vehicle_id || null,
        schedule: routeData.schedule || {},
        fee_amount: routeData.fee_amount || null
      };

      const { data, error } = await supabase
        .from('transport_routes')
        .insert(dataToInsert)
        .select()
        .single();

      if (error) throw error;

      const transformedRoute = {
        ...data,
        stops: Array.isArray(data.stops) ? 
          (data.stops as any[]).map(stop => typeof stop === 'string' ? stop : String(stop)) : 
          [],
        schedule: (data.schedule as Record<string, any>) || {}
      };

      setRoutes(prev => [...prev, transformedRoute]);
      toast.success('Route added successfully');
    } catch (error) {
      console.error('Error adding route:', error);
      toast.error('Failed to add route');
    }
  };

  const addFacility = async (facilityData: Partial<BoardingFacility>) => {
    try {
      // Ensure required fields are present
      if (!facilityData.facility_name) {
        throw new Error('Facility name is required');
      }

      const dataToInsert = {
        facility_name: facilityData.facility_name,
        facility_type: facilityData.facility_type || null,
        capacity: facilityData.capacity || null,
        supervisor_name: facilityData.supervisor_name || null,
        supervisor_phone: facilityData.supervisor_phone || null,
        rules: facilityData.rules || {},
        fee_amount: facilityData.fee_amount || null
      };

      const { data, error } = await supabase
        .from('boarding_facilities')
        .insert(dataToInsert)
        .select()
        .single();

      if (error) throw error;

      const transformedFacility = {
        ...data,
        rules: (data.rules as Record<string, any>) || {}
      };

      setFacilities(prev => [...prev, transformedFacility]);
      toast.success('Facility added successfully');
    } catch (error) {
      console.error('Error adding facility:', error);
      toast.error('Failed to add facility');
    }
  };

  return {
    vehicles,
    routes,
    facilities,
    loading,
    addVehicle,
    addRoute,
    addFacility,
    refetch: fetchData
  };
};
