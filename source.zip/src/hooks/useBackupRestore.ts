
import { useState } from 'react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { useData } from '@/context/DataSyncContext';

interface BackupData {
  students: any[];
  teachers: any[];
  classes: any[];
  payments: any[];
  feeStructures: any[];
  subjects: any[];
  examResults: any[];
  attendance: any[];
  exportedAt: string;
  version: string;
}

export const useBackupRestore = () => {
  const [isCreatingBackup, setIsCreatingBackup] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const { students, teachers, classes, payments, refreshData } = useData();

  const createBackup = async (): Promise<void> => {
    setIsCreatingBackup(true);
    try {
      // Fetch all data from Supabase
      const [
        studentsData,
        teachersData,
        classesData,
        paymentsData,
        feeStructuresData,
        subjectsData,
        examResultsData,
        attendanceData
      ] = await Promise.all([
        supabase.from('students').select('*'),
        supabase.from('teachers').select('*'),
        supabase.from('class_streams').select('*'),
        supabase.from('payments').select('*'),
        supabase.from('fee_structures').select('*'),
        supabase.from('subjects').select('*'),
        supabase.from('exam_results').select('*'),
        supabase.from('attendance').select('*')
      ]);

      const backupData: BackupData = {
        students: studentsData.data || [],
        teachers: teachersData.data || [],
        classes: classesData.data || [],
        payments: paymentsData.data || [],
        feeStructures: feeStructuresData.data || [],
        subjects: subjectsData.data || [],
        examResults: examResultsData.data || [],
        attendance: attendanceData.data || [],
        exportedAt: new Date().toISOString(),
        version: '1.0'
      };

      // Create and download backup file
      const blob = new Blob([JSON.stringify(backupData, null, 2)], {
        type: 'application/json'
      });
      
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `classpilot-backup-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast.success('Backup created successfully');
    } catch (error) {
      console.error('Error creating backup:', error);
      toast.error('Failed to create backup');
    } finally {
      setIsCreatingBackup(false);
    }
  };

  const restoreFromBackup = async (file: File): Promise<void> => {
    setIsRestoring(true);
    try {
      const text = await file.text();
      const backupData: BackupData = JSON.parse(text);

      // Validate backup structure
      if (!backupData.version || !backupData.exportedAt) {
        throw new Error('Invalid backup file format');
      }

      // Show confirmation dialog
      const confirmed = window.confirm(
        `This will replace ALL current data with data from ${new Date(backupData.exportedAt).toLocaleDateString()}. This action cannot be undone. Are you sure?`
      );

      if (!confirmed) {
        setIsRestoring(false);
        return;
      }

      // Clear existing data and restore from backup
      await Promise.all([
        supabase.from('attendance').delete().neq('id', '00000000-0000-0000-0000-000000000000'),
        supabase.from('exam_results').delete().neq('id', '00000000-0000-0000-0000-000000000000'),
        supabase.from('payments').delete().neq('id', '00000000-0000-0000-0000-000000000000'),
        supabase.from('students').delete().neq('id', '00000000-0000-0000-0000-000000000000'),
        supabase.from('teachers').delete().neq('id', '00000000-0000-0000-0000-000000000000')
      ]);

      // Insert backup data
      if (backupData.students.length > 0) {
        await supabase.from('students').insert(backupData.students);
      }
      if (backupData.teachers.length > 0) {
        await supabase.from('teachers').insert(backupData.teachers);
      }
      if (backupData.payments.length > 0) {
        await supabase.from('payments').insert(backupData.payments);
      }
      if (backupData.attendance.length > 0) {
        await supabase.from('attendance').insert(backupData.attendance);
      }
      if (backupData.examResults.length > 0) {
        await supabase.from('exam_results').insert(backupData.examResults);
      }

      await refreshData();
      toast.success('Data restored successfully');
    } catch (error) {
      console.error('Error restoring backup:', error);
      toast.error('Failed to restore backup. Please check the file format.');
    } finally {
      setIsRestoring(false);
    }
  };

  return {
    createBackup,
    restoreFromBackup,
    isCreatingBackup,
    isRestoring
  };
};
