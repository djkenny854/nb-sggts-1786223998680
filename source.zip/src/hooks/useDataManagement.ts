
import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export const useDataManagement = () => {
  const [isProcessing, setIsProcessing] = useState(false);

  const resetTermYear = async (newTerm: string, newYear: string) => {
    setIsProcessing(true);
    try {
      // Update all relevant tables with new term/year
      const updates = [
        supabase.from('student_fees').update({ academic_term: newTerm, academic_year: newYear }),
        supabase.from('attendance').update({ created_at: new Date().toISOString() }),
        supabase.from('exams').update({ term: newTerm, year: newYear }),
        supabase.from('fee_structures').update({ academic_term: newTerm, academic_year: newYear }),
      ];

      await Promise.all(updates);
      toast.success(`Successfully reset to ${newTerm} ${newYear}`);
    } catch (error) {
      console.error('Error resetting term/year:', error);
      toast.error('Failed to reset term/year');
    } finally {
      setIsProcessing(false);
    }
  };

  const clearTestData = async () => {
    setIsProcessing(true);
    try {
      // Define tables to clear (only test/demo data)
      const tablesToClear = [
        'fee_transactions',
        'student_fees',
        'attendance',
        'exam_results',
      ];

      // Clear each table
      for (const table of tablesToClear) {
        const { error } = await supabase
          .from(table as any)
          .delete()
          .neq('id', ''); // Delete all records
        
        if (error) {
          console.error(`Error clearing ${table}:`, error);
        }
      }

      toast.success('Test data cleared successfully');
    } catch (error) {
      console.error('Error clearing test data:', error);
      toast.error('Failed to clear test data');
    } finally {
      setIsProcessing(false);
    }
  };

  const exportData = async (type: 'students' | 'teachers' | 'fees' | 'grades') => {
    setIsProcessing(true);
    try {
      let data;
      let filename;

      switch (type) {
        case 'students':
          const { data: studentsData } = await supabase
            .from('students')
            .select('*');
          data = studentsData;
          filename = 'students_export.csv';
          break;
        case 'teachers':
          const { data: teachersData } = await supabase
            .from('teachers')
            .select('*');
          data = teachersData;
          filename = 'teachers_export.csv';
          break;
        case 'fees':
          const { data: feesData } = await supabase
            .from('student_fees')
            .select('*');
          data = feesData;
          filename = 'fees_export.csv';
          break;
        case 'grades':
          const { data: gradesData } = await supabase
            .from('exam_results')
            .select('*');
          data = gradesData;
          filename = 'grades_export.csv';
          break;
        default:
          throw new Error('Invalid export type');
      }

      if (data) {
        // Convert to CSV
        const csv = convertToCSV(data);
        downloadCSV(csv, filename);
        toast.success(`${type} data exported successfully`);
      }
    } catch (error) {
      console.error('Error exporting data:', error);
      toast.error('Failed to export data');
    } finally {
      setIsProcessing(false);
    }
  };

  const importData = async (file: File, type: 'students' | 'teachers' | 'fees' | 'grades') => {
    setIsProcessing(true);
    try {
      const text = await file.text();
      const data = parseCSV(text);
      
      if (data.length === 0) {
        toast.error('No data found in file');
        return;
      }

      // Map type to correct table name
      let tableName: string;
      switch (type) {
        case 'students':
          tableName = 'students';
          break;
        case 'teachers':
          tableName = 'teachers';
          break;
        case 'fees':
          tableName = 'student_fees';
          break;
        case 'grades':
          tableName = 'exam_results';
          break;
        default:
          throw new Error('Invalid import type');
      }

      // Import to appropriate table
      const { error } = await supabase
        .from(tableName as any)
        .insert(data);

      if (error) {
        console.error('Import error:', error);
        toast.error('Failed to import data');
      } else {
        toast.success(`${data.length} ${type} records imported successfully`);
      }
    } catch (error) {
      console.error('Error importing data:', error);
      toast.error('Failed to import data');
    } finally {
      setIsProcessing(false);
    }
  };

  const convertToCSV = (data: any[]) => {
    if (!data || data.length === 0) return '';
    
    const headers = Object.keys(data[0]);
    const csvRows = [headers.join(',')];
    
    for (const row of data) {
      const values = headers.map(header => {
        const value = row[header];
        return typeof value === 'string' ? `"${value}"` : value;
      });
      csvRows.push(values.join(','));
    }
    
    return csvRows.join('\n');
  };

  const parseCSV = (text: string) => {
    const lines = text.split('\n');
    if (lines.length < 2) return [];
    
    const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
    const rows = [];
    
    for (let i = 1; i < lines.length; i++) {
      if (lines[i].trim() === '') continue;
      
      const values = lines[i].split(',').map(v => v.trim().replace(/"/g, ''));
      const row: any = {};
      
      headers.forEach((header, index) => {
        row[header] = values[index] || '';
      });
      
      rows.push(row);
    }
    
    return rows;
  };

  const downloadCSV = (csv: string, filename: string) => {
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return {
    isProcessing,
    resetTermYear,
    clearTestData,
    exportData,
    importData,
  };
};
