
export type ExamType = {
  id: string;
  name: string;
  term: string;
  year: string;
  startDate: string;
  endDate: string;
  isActive: boolean;
  gradeScale: GradeScale;
};

export type ExamResult = {
  id: string;
  studentId: string;
  studentName?: string;
  examId: string;
  examName?: string;
  className?: string;
  subjectResults: SubjectResult[];
  totalMarks: number;
  averageMarks: number;
  grade: string;
  position?: number;
  comments?: string;
  teacher?: string;
  dateEntered: string;
};

export type SubjectResult = {
  subjectId: string;
  subjectName: string;
  marks: number;
  outOf: number;
  grade: string;
  teacherComment?: string;
};

export type GradeScale = {
  A: { min: number; max: number; comment: string };
  B: { min: number; max: number; comment: string };
  C: { min: number; max: number; comment: string };
  D: { min: number; max: number; comment: string };
  F: { min: number; max: number; comment: string };
};

export type PerformanceStats = {
  totalStudents: number;
  highestScore: number;
  lowestScore: number;
  averageScore: number;
  passRate: number;
  gradeDistribution: {
    A: number;
    B: number;
    C: number;
    D: number;
    F: number;
  };
};
