
export interface Message {
  id: string;
  title: string;
  content: string;
  channel: 'sms' | 'email' | 'whatsapp';
  sender_id?: string;
  recipient_type: 'individual' | 'group' | 'broadcast';
  recipient_ids: string[];
  status: 'pending' | 'sent' | 'delivered' | 'failed' | 'cancelled';
  scheduled_at?: string;
  sent_at?: string;
  delivery_status: Record<string, any>;
  metadata: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export interface MessageTemplate {
  id: string;
  name: string;
  category: 'fee_reminder' | 'attendance_alert' | 'exam_result' | 'event_reminder' | 'announcement' | 'custom';
  title: string;
  content: string;
  variables: string[];
  channels: string[];
  is_default: boolean;
  created_at: string;
  updated_at: string;
}

export interface CommunicationSettings {
  id: string;
  setting_type: 'email_provider' | 'sms_provider' | 'whatsapp_config' | 'general';
  provider_name?: string;
  configuration: Record<string, any>;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface MessageLog {
  id: string;
  message_id: string;
  recipient_id: string;
  recipient_contact: string;
  channel: string;
  status: 'queued' | 'sent' | 'delivered' | 'failed' | 'bounced';
  provider_response: Record<string, any>;
  delivery_time?: string;
  error_message?: string;
  cost_amount: number;
  created_at: string;
}

export interface ContactGroup {
  id: string;
  name: string;
  description?: string;
  group_type: 'class' | 'custom' | 'all_parents' | 'all_teachers' | 'fee_defaulters';
  criteria: Record<string, any>;
  member_ids: string[];
  is_dynamic: boolean;
  created_at: string;
  updated_at: string;
}

export interface MessageTrigger {
  id: string;
  name: string;
  trigger_type: 'fee_overdue' | 'attendance_absent' | 'exam_result' | 'scheduled' | 'event_reminder';
  condition_criteria: Record<string, any>;
  template_id?: string;
  channels: string[];
  target_groups: string[];
  is_active: boolean;
  last_triggered_at?: string;
  created_at: string;
  updated_at: string;
}
