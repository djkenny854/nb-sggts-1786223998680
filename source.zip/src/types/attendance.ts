
export interface AttendanceSettingsData {
  attendancePeriod: string;
  allowFutureAttendance: boolean;
  lockAfterHours: number;
  absentThreshold: number;
  notifyParentsOnAbsence: boolean;
  requireAbsenceExplanation: boolean;
  monthlyReport: string;
  enableDisciplineTracking: boolean;
  escalationLevels: number;
  notifyParentsForDisciplinary: boolean;
  requireAdminApproval: boolean;
  defaultAction: string;
  allowCustomTypes: boolean;
}

// Extend the Window interface to include our attendance settings
declare global {
  interface Window {
    attendanceSettings?: AttendanceSettingsData;
  }
}
