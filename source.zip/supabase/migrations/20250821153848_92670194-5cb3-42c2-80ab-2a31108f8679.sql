
-- Fix the balance column issue by making it a generated column properly
-- and update the fee assignment functions

-- First, let's modify the student_fees table to make balance a proper generated column
ALTER TABLE student_fees 
DROP COLUMN IF EXISTS balance;

-- Add balance back as a generated column
ALTER TABLE student_fees 
ADD COLUMN balance NUMERIC GENERATED ALWAYS AS (total_assigned_fees - total_paid) STORED;

-- Update the create_student_fees_record function to not include balance
CREATE OR REPLACE FUNCTION create_student_fees_record()
RETURNS TRIGGER AS $$
DECLARE
  current_year TEXT := EXTRACT(YEAR FROM NOW())::TEXT;
  current_term TEXT := 'Term 1';
  fee_amount NUMERIC := 0;
BEGIN
  -- Calculate fees based on student status
  fee_amount := 500000; -- Base tuition
  
  -- Add boarding fee if applicable
  IF NEW.boarding_status = 'Boarding' THEN
    fee_amount := fee_amount + 300000;
  END IF;
  
  -- Add transport fee if applicable  
  IF NEW.transport = 'Yes' THEN
    fee_amount := fee_amount + 50000;
  END IF;
  
  -- Add activity fees
  fee_amount := fee_amount + 25000;
  
  -- Create student_fees record (balance will be auto-generated)
  INSERT INTO student_fees (
    student_id,
    total_assigned_fees,
    total_paid,
    academic_year,
    academic_term,
    payment_status
  ) VALUES (
    NEW.id,
    fee_amount,
    0,
    current_year,
    current_term,
    'Unpaid'
  ) ON CONFLICT (student_id, academic_year, academic_term) 
  DO UPDATE SET
    total_assigned_fees = fee_amount,
    total_paid = 0,
    updated_at = NOW();
    
  -- Update student fee_status
  UPDATE students 
  SET fee_status = 'Unpaid'
  WHERE id = NEW.id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Update the transaction trigger function
CREATE OR REPLACE FUNCTION update_student_fees_on_transaction()
RETURNS TRIGGER AS $$
BEGIN
  -- Update student_fees table with new totals (balance will auto-update)
  UPDATE student_fees 
  SET 
    total_paid = (
      SELECT COALESCE(SUM(amount), 0) 
      FROM fee_transactions 
      WHERE student_id = NEW.student_id 
      AND academic_year = NEW.academic_year 
      AND academic_term = NEW.academic_term
      AND status = 'completed'
    ),
    payment_status = CASE 
      WHEN (
        SELECT COALESCE(SUM(amount), 0) 
        FROM fee_transactions 
        WHERE student_id = NEW.student_id 
        AND academic_year = NEW.academic_year 
        AND academic_term = NEW.academic_term
        AND status = 'completed'
      ) >= total_assigned_fees THEN 'Paid'
      WHEN (
        SELECT COALESCE(SUM(amount), 0) 
        FROM fee_transactions 
        WHERE student_id = NEW.student_id 
        AND academic_year = NEW.academic_year 
        AND academic_term = NEW.academic_term
        AND status = 'completed'
      ) > 0 THEN 'Partial'
      ELSE 'Unpaid'
    END,
    updated_at = NOW()
  WHERE student_id = NEW.student_id 
  AND academic_year = NEW.academic_year 
  AND academic_term = NEW.academic_term;
  
  -- Update student fee_status for quick reference
  UPDATE students 
  SET fee_status = (
    SELECT payment_status 
    FROM student_fees 
    WHERE student_id = NEW.student_id 
    AND academic_year = NEW.academic_year 
    AND academic_term = NEW.academic_term
    LIMIT 1
  )
  WHERE id = NEW.student_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create a function to manually assign fees to existing students
CREATE OR REPLACE FUNCTION assign_fees_to_students()
RETURNS void AS $$
DECLARE
  student_record RECORD;
  fee_amount NUMERIC;
  current_year TEXT := EXTRACT(YEAR FROM NOW())::TEXT;
  current_term TEXT := 'Term 1';
BEGIN
  -- Loop through all students who don't have fees assigned
  FOR student_record IN 
    SELECT s.* 
    FROM students s
    WHERE NOT EXISTS (
      SELECT 1 FROM student_fees sf 
      WHERE sf.student_id = s.id 
      AND sf.academic_year = current_year 
      AND sf.academic_term = current_term
    )
  LOOP
    -- Calculate fees for this student
    fee_amount := 500000; -- Base tuition
    
    IF student_record.boarding_status = 'Boarding' THEN
      fee_amount := fee_amount + 300000;
    END IF;
    
    IF student_record.transport = 'Yes' THEN
      fee_amount := fee_amount + 50000;
    END IF;
    
    fee_amount := fee_amount + 25000; -- Activities
    
    -- Insert fee record
    INSERT INTO student_fees (
      student_id,
      total_assigned_fees,
      total_paid,
      academic_year,
      academic_term,
      payment_status
    ) VALUES (
      student_record.id,
      fee_amount,
      0,
      current_year,
      current_term,
      'Unpaid'
    );
    
    -- Update student status
    UPDATE students 
    SET fee_status = 'Unpaid'
    WHERE id = student_record.id;
    
  END LOOP;
  
  RAISE NOTICE 'Fees assigned to all students for % %', current_year, current_term;
END;
$$ LANGUAGE plpgsql;

-- Run the function to assign fees to existing students
SELECT assign_fees_to_students();
