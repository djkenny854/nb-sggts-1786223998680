
-- Create missing messaging-related tables and functions

-- Create message_queue table for processing messages
CREATE TABLE IF NOT EXISTS public.message_queue (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  message_id UUID REFERENCES public.messages(id) ON DELETE CASCADE,
  recipient_id TEXT NOT NULL,
  recipient_contact TEXT NOT NULL,
  channel TEXT NOT NULL,
  status TEXT DEFAULT 'queued' CHECK (status IN ('queued', 'processing', 'sent', 'failed', 'retry')),
  attempts INTEGER DEFAULT 0,
  max_attempts INTEGER DEFAULT 3,
  scheduled_for TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  processed_at TIMESTAMP WITH TIME ZONE,
  error_message TEXT,
  provider_response JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on message_queue
ALTER TABLE public.message_queue ENABLE ROW LEVEL SECURITY;

-- Create policy for message_queue
CREATE POLICY "Allow all operations on message_queue" 
ON public.message_queue 
FOR ALL 
USING (true) 
WITH CHECK (true);

-- Create message_analytics table for tracking
CREATE TABLE IF NOT EXISTS public.message_analytics (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  message_id UUID REFERENCES public.messages(id) ON DELETE CASCADE,
  channel TEXT NOT NULL,
  recipient_count INTEGER DEFAULT 0,
  sent_count INTEGER DEFAULT 0,
  delivered_count INTEGER DEFAULT 0,
  failed_count INTEGER DEFAULT 0,
  open_rate DECIMAL(5,2) DEFAULT 0,
  click_rate DECIMAL(5,2) DEFAULT 0,
  total_cost DECIMAL(10,2) DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on message_analytics
ALTER TABLE public.message_analytics ENABLE ROW LEVEL SECURITY;

-- Create policy for message_analytics
CREATE POLICY "Allow all operations on message_analytics" 
ON public.message_analytics 
FOR ALL 
USING (true) 
WITH CHECK (true);

-- Create ai_message_suggestions table for AI-generated content
CREATE TABLE IF NOT EXISTS public.ai_message_suggestions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  category TEXT NOT NULL,
  suggestion_type TEXT NOT NULL CHECK (suggestion_type IN ('subject', 'content', 'template')),
  content TEXT NOT NULL,
  context JSONB DEFAULT '{}',
  usage_count INTEGER DEFAULT 0,
  rating DECIMAL(3,2) DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on ai_message_suggestions
ALTER TABLE public.ai_message_suggestions ENABLE ROW LEVEL SECURITY;

-- Create policy for ai_message_suggestions
CREATE POLICY "Allow all operations on ai_message_suggestions" 
ON public.ai_message_suggestions 
FOR ALL 
USING (true) 
WITH CHECK (true);

-- Create function to process message queue
CREATE OR REPLACE FUNCTION public.process_message_queue()
RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  queue_item RECORD;
BEGIN
  -- Process queued messages that are ready to be sent
  FOR queue_item IN 
    SELECT * FROM public.message_queue 
    WHERE status = 'queued' 
    AND scheduled_for <= NOW()
    AND attempts < max_attempts
    ORDER BY scheduled_for ASC
    LIMIT 10
  LOOP
    -- Update status to processing
    UPDATE public.message_queue 
    SET status = 'processing', 
        attempts = attempts + 1,
        updated_at = NOW()
    WHERE id = queue_item.id;
    
    -- Here we would call the edge function to actually send the message
    -- For now, we'll just mark it as sent for demonstration
    UPDATE public.message_queue 
    SET status = 'sent', 
        processed_at = NOW(),
        updated_at = NOW()
    WHERE id = queue_item.id;
  END LOOP;
END;
$$;

-- Create function to expand contact groups
CREATE OR REPLACE FUNCTION public.expand_contact_group(group_id UUID)
RETURNS TEXT[]
LANGUAGE plpgsql
AS $$
DECLARE
  group_record RECORD;
  result TEXT[] := '{}';
BEGIN
  SELECT * INTO group_record FROM public.contact_groups WHERE id = group_id;
  
  IF NOT FOUND THEN
    RETURN result;
  END IF;
  
  -- Handle different group types
  CASE group_record.group_type
    WHEN 'all_parents' THEN
      SELECT ARRAY_AGG(parent_contact) INTO result 
      FROM public.students 
      WHERE parent_contact IS NOT NULL AND parent_contact != '';
      
    WHEN 'all_teachers' THEN
      SELECT ARRAY_AGG(email) INTO result 
      FROM public.teachers 
      WHERE email IS NOT NULL AND email != '';
      
    WHEN 'class' THEN
      SELECT ARRAY_AGG(parent_contact) INTO result 
      FROM public.students 
      WHERE class = (group_record.criteria->>'class_name')
      AND parent_contact IS NOT NULL AND parent_contact != '';
      
    WHEN 'fee_defaulters' THEN
      SELECT ARRAY_AGG(s.parent_contact) INTO result 
      FROM public.students s
      JOIN public.student_fees sf ON s.id = sf.student_id
      WHERE sf.payment_status IN ('Unpaid', 'Partial')
      AND s.parent_contact IS NOT NULL AND s.parent_contact != '';
      
    WHEN 'custom' THEN
      result := group_record.member_ids;
      
    ELSE
      result := '{}';
  END CASE;
  
  RETURN COALESCE(result, '{}');
END;
$$;

-- Create trigger to auto-create message queue items when message is created
CREATE OR REPLACE FUNCTION public.create_message_queue_items()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  recipient TEXT;
  expanded_recipients TEXT[];
BEGIN
  -- Expand recipient groups if needed
  IF NEW.recipient_type = 'group' THEN
    -- For now, use the recipient_ids as is
    expanded_recipients := NEW.recipient_ids;
  ELSE
    expanded_recipients := NEW.recipient_ids;
  END IF;
  
  -- Create queue items for each recipient
  FOREACH recipient IN ARRAY expanded_recipients
  LOOP
    INSERT INTO public.message_queue (
      message_id,
      recipient_id,
      recipient_contact,
      channel,
      scheduled_for
    ) VALUES (
      NEW.id,
      recipient,
      recipient, -- For now, assume recipient_id is the contact
      NEW.channel,
      COALESCE(NEW.scheduled_at, NOW())
    );
  END LOOP;
  
  -- Create analytics record
  INSERT INTO public.message_analytics (
    message_id,
    channel,
    recipient_count
  ) VALUES (
    NEW.id,
    NEW.channel,
    array_length(expanded_recipients, 1)
  );
  
  RETURN NEW;
END;
$$;

-- Create trigger
DROP TRIGGER IF EXISTS create_message_queue_items_trigger ON public.messages;
CREATE TRIGGER create_message_queue_items_trigger
  AFTER INSERT ON public.messages
  FOR EACH ROW
  EXECUTE FUNCTION public.create_message_queue_items();

-- Insert default AI message suggestions
INSERT INTO public.ai_message_suggestions (category, suggestion_type, content, context) VALUES
('fee_reminder', 'subject', 'Fee Payment Reminder - {{student_name}}', '{"variables": ["student_name"]}'),
('fee_reminder', 'content', 'Dear {{parent_name}}, this is a friendly reminder that {{student_name}}''s school fees of UGX {{amount}} are due. Please make payment at your earliest convenience.', '{"variables": ["parent_name", "student_name", "amount"]}'),
('attendance_alert', 'subject', 'Attendance Alert - {{student_name}}', '{"variables": ["student_name"]}'),
('attendance_alert', 'content', 'Dear {{parent_name}}, {{student_name}} was marked absent today ({{date}}). Please contact the school if this is unexpected.', '{"variables": ["parent_name", "student_name", "date"]}'),
('exam_result', 'subject', 'Exam Results Available - {{student_name}}', '{"variables": ["student_name"]}'),
('exam_result', 'content', 'Dear {{parent_name}}, {{student_name}}''s {{exam_name}} results are now available. Overall grade: {{grade}}. Please log in to view detailed results.', '{"variables": ["parent_name", "student_name", "exam_name", "grade"]}'),
('event_reminder', 'subject', 'Upcoming Event: {{event_name}}', '{"variables": ["event_name"]}'),
('event_reminder', 'content', 'Dear parents, this is a reminder about the upcoming {{event_name}} on {{date}} at {{time}}. Please ensure your child is prepared.', '{"variables": ["event_name", "date", "time"]}')
ON CONFLICT DO NOTHING;

-- Create default message templates if they don't exist
INSERT INTO public.message_templates (name, category, title, content, variables, channels, is_default) VALUES
('Default Fee Reminder', 'fee_reminder', 'Fee Payment Due - {{student_name}}', 'Dear {{parent_name}}, your child {{student_name}} has an outstanding fee balance of UGX {{balance}}. Please make payment by {{due_date}} to avoid any inconvenience. Thank you.', '["parent_name", "student_name", "balance", "due_date"]', '["sms", "email"]', true),
('Attendance Alert', 'attendance_alert', 'Attendance Notification - {{student_name}}', 'Dear {{parent_name}}, {{student_name}} was absent from school today ({{date}}). If this absence was unplanned, please contact the school immediately.', '["parent_name", "student_name", "date"]', '["sms", "email"]', true),
('Exam Results', 'exam_result', 'Exam Results - {{student_name}}', 'Dear {{parent_name}}, {{student_name}}''s {{exam_name}} results are ready. Grade: {{grade}}, Position: {{position}}. Congratulations on the achievement!', '["parent_name", "student_name", "exam_name", "grade", "position"]', '["sms", "email"]', true),
('Event Reminder', 'event_reminder', 'School Event: {{event_name}}', 'Dear parents, reminder about {{event_name}} scheduled for {{date}} at {{time}}. {{additional_info}}', '["event_name", "date", "time", "additional_info"]', '["sms", "email", "whatsapp"]', true)
ON CONFLICT DO NOTHING;

-- Create default contact groups
INSERT INTO public.contact_groups (name, description, group_type, criteria, is_dynamic) VALUES
('All Parents', 'All student parents in the school', 'all_parents', '{}', true),
('All Teachers', 'All teaching staff', 'all_teachers', '{}', true),
('Fee Defaulters', 'Students with outstanding fee balances', 'fee_defaulters', '{}', true)
ON CONFLICT DO NOTHING;
