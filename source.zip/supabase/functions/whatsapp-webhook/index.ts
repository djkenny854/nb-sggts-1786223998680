import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    )

    // GET request - Webhook verification
    if (req.method === 'GET') {
      const url = new URL(req.url)
      const mode = url.searchParams.get('hub.mode')
      const token = url.searchParams.get('hub.verify_token')
      const challenge = url.searchParams.get('hub.challenge')

      console.log('Webhook verification:', { mode, token, challenge })

      // Get verify token from database
      const { data: settings } = await supabase
        .from('communication_settings')
        .select('*')
        .eq('setting_type', 'whatsapp_config')
        .eq('is_active', true)
        .single()

      if (!settings) {
        console.error('WhatsApp settings not found')
        return new Response('Forbidden', { status: 403 })
      }

      const config = settings.configuration
      const expectedToken = config.webhook_verify_token

      // Verify the token and mode
      if (mode === 'subscribe' && token === expectedToken) {
        console.log('Webhook verified successfully')
        return new Response(challenge, { 
          status: 200,
          headers: { 'Content-Type': 'text/plain' }
        })
      } else {
        console.error('Webhook verification failed:', { expectedToken, receivedToken: token })
        return new Response('Forbidden', { status: 403 })
      }
    }

    // POST request - Webhook events
    if (req.method === 'POST') {
      const body = await req.json()
      console.log('Webhook received:', JSON.stringify(body, null, 2))

      // Process webhook events
      if (body.entry && Array.isArray(body.entry)) {
        for (const entry of body.entry) {
          if (entry.changes && Array.isArray(entry.changes)) {
            for (const change of entry.changes) {
              if (change.field === 'messages') {
                const value = change.value

                // Handle message status updates
                if (value.statuses && Array.isArray(value.statuses)) {
                  for (const status of value.statuses) {
                    await handleMessageStatus(supabase, status)
                  }
                }

                // Handle incoming messages
                if (value.messages && Array.isArray(value.messages)) {
                  for (const message of value.messages) {
                    await handleIncomingMessage(supabase, message, value.contacts)
                  }
                }
              }
            }
          }
        }
      }

      return new Response(
        JSON.stringify({ success: true }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    return new Response('Method not allowed', { status: 405 })

  } catch (error) {
    console.error('Webhook error:', error)
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error' 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500
      }
    )
  }
})

async function handleMessageStatus(supabase: any, status: any) {
  try {
    console.log('Processing message status:', status)

    // Update message log with delivery status
    const { error } = await supabase
      .from('message_logs')
      .update({
        delivery_status: status.status,
        updated_at: new Date().toISOString()
      })
      .eq('external_id', status.id)

    if (error) {
      console.error('Error updating message status:', error)
    } else {
      console.log('Message status updated successfully:', status.id)
    }
  } catch (error) {
    console.error('Error handling message status:', error)
  }
}

async function handleIncomingMessage(supabase: any, message: any, contacts: any[]) {
  try {
    console.log('Processing incoming message:', message)

    // Find contact info
    const contact = contacts?.find(c => c.wa_id === message.from)
    const contactName = contact?.profile?.name || message.from

    // Save incoming message to database
    const { error } = await supabase
      .from('message_logs')
      .insert({
        message_id: crypto.randomUUID(),
        channel: 'whatsapp',
        recipient: message.from,
        content: message.text?.body || message.type,
        status: 'received',
        direction: 'inbound',
        external_id: message.id,
        metadata: {
          contact_name: contactName,
          message_type: message.type,
          timestamp: message.timestamp
        }
      })

    if (error) {
      console.error('Error saving incoming message:', error)
    } else {
      console.log('Incoming message saved successfully')
    }

    // You can add additional logic here to:
    // - Auto-reply to certain messages
    // - Notify staff of new messages
    // - Process specific commands or keywords

  } catch (error) {
    console.error('Error handling incoming message:', error)
  }
}