import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.nativebridge.app',
  appName: 'sggts',
  webDir: 'dist'
};

export default config;
